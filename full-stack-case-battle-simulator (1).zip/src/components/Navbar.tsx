import { useEffect, useState } from 'react';
import { getCurrentUser, getOnlineCount, logout, setLang, useStore } from '../lib/store';
import { useT, useLang } from '../lib/useT';
import { clickSound, isMuted, toggleMute } from '../lib/sound';

type Page = 'cases' | 'battles' | 'mines' | 'upgrade' | 'contracts' | 'giveaways' | 'profile' | 'admin';

export function Navbar({
  page, onNav, onAuth,
}: { page: Page; onNav: (p: Page) => void; onAuth: () => void }) {
  const t = useT();
  const lang = useLang();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [online, setOnline] = useState(getOnlineCount());
  const [, force] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setOnline(getOnlineCount() + Math.floor(Math.random() * 40 - 20)), 4000);
    return () => clearInterval(id);
  }, []);

  const link = (p: Page, label: string, icon: string) => (
    <button
      key={p}
      onClick={() => { clickSound(); onNav(p); }}
      className={[
        'group flex flex-col items-center justify-center px-3 sm:px-4 h-full text-[11px] font-semibold tracking-wide uppercase transition-colors',
        page === p ? 'text-[#FF6B1A]' : 'text-white/55 hover:text-white',
      ].join(' ')}
    >
      <div className="text-[20px] leading-none">{icon}</div>
      <div className="mt-1 hidden sm:block">{label}</div>
      {page === p && <div className="absolute top-0 h-[2px] w-10 bg-[#FF6B1A] rounded-b" />}
    </button>
  );

  return (
    <header className="sticky top-0 z-40 bg-[#11192a] border-b border-[#1f2a3d] h-[70px] flex items-center">
      {/* Logo */}
      <div className="w-[180px] sm:w-[230px] h-full flex items-center justify-center bg-[#0F1923] border-r border-[#1f2a3d]">
        <button onClick={() => onNav('cases')} className="flex flex-col items-center group">
          <div className="flex items-center gap-1.5">
            <span className="text-white font-black text-[15px] sm:text-[17px] tracking-tight">CASE</span>
            <span className="px-1.5 py-0.5 bg-[#FF6B1A] text-white text-[12px] font-black rounded">📦</span>
            <span className="text-white font-black text-[15px] sm:text-[17px] tracking-tight">BATTLE</span>
          </div>
          <div className="text-[8px] text-[#FF6B1A] tracking-[0.2em] font-bold mt-0.5">{t('tagline')}</div>
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 flex items-center h-full pl-1 sm:pl-3 relative">
        <div className="flex items-stretch h-full relative">
          {link('cases', t('nav_cases'), '📦')}
          {link('battles', t('nav_battles'), '⚔️')}
          {link('mines', 'Mines', '💣')}
          {link('upgrade', t('nav_upgrade'), '⬆️')}
          {link('contracts', t('nav_contracts'), '📝')}
          {link('giveaways', t('nav_giveaways'), '🎁')}
          {user?.role === 'admin' && link('admin', t('nav_admin'), '🛡️')}
        </div>
        <div className="ml-4 hidden md:flex items-center gap-1.5 text-[12px] text-emerald-400 font-bold">
          <span className="inline-flex items-center justify-center w-7 h-7 rounded-full bg-[#0F1923]">👥</span>
          <span>{online.toLocaleString('ru-RU')}</span>
        </div>
      </nav>

      {/* Right side */}
      <div className="flex items-center gap-2 pr-2 sm:pr-4 h-full">
        {/* Lang toggle */}
        <div className="hidden sm:flex items-center bg-[#0F1923] rounded overflow-hidden border border-[#22324a]">
          {(['ru','en'] as const).map(l => (
            <button
              key={l}
              onClick={() => { setLang(l); clickSound(); force(x => x+1); }}
              className={['px-2 py-1 text-[11px] font-bold', lang === l ? 'bg-[#FF6B1A] text-white' : 'text-white/50 hover:text-white'].join(' ')}
            >{l.toUpperCase()}</button>
          ))}
        </div>

        {/* Mute */}
        <button
          onClick={() => { toggleMute(); force(x => x+1); }}
          className="w-9 h-9 rounded bg-[#0F1923] border border-[#22324a] text-white/70 hover:text-[#FF6B1A] hover:border-[#FF6B1A]/50"
          title={isMuted() ? 'Sound off' : 'Sound on'}
        >{isMuted() ? '🔇' : '🔊'}</button>

        {user ? (
          <button
            onClick={() => onNav('profile')}
            className="flex items-center gap-2 sm:gap-3 pl-1 pr-2 sm:pr-3 py-1 rounded hover:bg-[#0F1923] transition-colors group"
          >
            <div className="text-right hidden sm:block">
              <div className="text-[11px] text-white/55 leading-tight">Привет,</div>
              <div className="text-[12px] font-bold text-white leading-tight max-w-[120px] truncate">{user.username}</div>
              <div className="text-[10px] text-[#FF6B1A] font-bold">{t('balance')}: {user.balance.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
            </div>
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#FF6B1A] to-[#8b3700] flex items-center justify-center text-xl border-2 border-[#FF6B1A]/40 group-hover:border-[#FF6B1A]">
              {user.avatar}
            </div>
          </button>
        ) : (
          <button
            onClick={() => { clickSound(); onAuth(); }}
            className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold text-sm"
          >{t('login')}</button>
        )}

        {user && (
          <button
            onClick={() => { logout(); }}
            className="hidden sm:block px-2 py-1 text-[11px] text-white/40 hover:text-white"
            title={t('logout')}
          >⎋</button>
        )}
      </div>
    </header>
  );
}

export { getCurrentUser };
