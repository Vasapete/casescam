import { useMemo } from 'react';
import { motion } from 'framer-motion';
import type { CaseDef } from '../lib/types';
import { clickSound } from '../lib/sound';
import { generateCaseArt } from '../lib/caseArt';

export function CaseCard({
  def, onClick, active,
}: { def: CaseDef; onClick: () => void; active?: boolean }) {
  const itemCount = def.items.length;
  const artSrc = useMemo(() => generateCaseArt(def.name, def.image), [def.name, def.image]);

  return (
    <motion.button
      onClick={() => { clickSound(); onClick(); }}
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: 'spring', stiffness: 320, damping: 22 }}
      className={[
        'group relative text-left rounded-lg overflow-hidden',
        'bg-[#152030] border border-[#22324a]',
        'hover:border-[#FF6B1A]/70 transition-colors',
        active ? 'ring-2 ring-[#FF6B1A]' : '',
      ].join(' ')}
    >
      <div className="px-3 pt-3 pb-1">
        <div className="text-[12px] font-bold tracking-wide text-white/90 truncate flex items-center gap-2">
          <span>{def.name}</span>
          {def.is_new && (
            <span className="text-[9px] font-black px-1.5 py-[1px] bg-[#FF6B1A] text-white rounded-sm">NEW</span>
          )}
        </div>
        <div className="text-[11px] text-white/40">{itemCount} предметов</div>
      </div>

      <div className="relative h-[150px] mx-3 my-2 rounded-md overflow-hidden">
        <img src={artSrc} alt={def.name} className="w-full h-full object-cover rounded-md" draggable={false} />
        {/* shine sweep */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -inset-y-4 -left-1/3 w-1/3 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12 opacity-0 group-hover:opacity-100 group-hover:translate-x-[400%] transition-all duration-700" />
        </div>
      </div>

      <div className="px-3 pb-3">
        <div className="w-full text-center py-1.5 rounded text-[13px] font-bold bg-[#0F1923] border border-[#FF6B1A]/40 text-[#FF6B1A] group-hover:bg-[#FF6B1A] group-hover:text-white transition-colors">
          {def.price === 0 ? 'БЕСПЛАТНО' : `${def.price.toLocaleString('ru-RU')} ₽`}
        </div>
      </div>
    </motion.button>
  );
}
