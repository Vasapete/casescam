import { useEffect, useRef, useState, useSyncExternalStore } from 'react';
import type { Skin } from '../lib/types';
import { resolveSkinIcon, fallbackIcon, subscribeIcons, getIconVersion } from '../lib/skinData';

export function SkinIcon({ skin, className = '', alt }: { skin: Skin; className?: string; alt?: string }) {
  // Re-render whenever the icon map version bumps (i.e. CSGO-API finishes loading).
  const version = useSyncExternalStore(subscribeIcons, getIconVersion, getIconVersion);

  const [src, setSrc] = useState(() => resolveSkinIcon(skin));
  const erroredRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    const resolved = resolveSkinIcon(skin);
    if (resolved !== src && !erroredRef.current.has(resolved)) {
      setSrc(resolved);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [skin.id, version]);

  return (
    <img
      src={src}
      alt={alt ?? skin.market_hash_name}
      loading="lazy"
      onError={() => {
        erroredRef.current.add(src);
        const fb = fallbackIcon(skin);
        if (src !== fb) setSrc(fb);
      }}
      className={'object-contain ' + className}
      draggable={false}
    />
  );
}
