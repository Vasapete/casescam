import { useState } from 'react';
import { AVATAR_LIST, loginUser, registerUser } from '../lib/store';
import { useT } from '../lib/useT';
import { clickSound, errorSound, successSound } from '../lib/sound';
import { motion, AnimatePresence } from 'framer-motion';

export function AuthModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [u, setU] = useState('');
  const [p, setP] = useState('');
  const [avatar, setAvatar] = useState(AVATAR_LIST[0]);
  const [err, setErr] = useState<string | null>(null);

  const submit = () => {
    setErr(null);
    if (mode === 'login') {
      const r = loginUser(u, p);
      if (r.ok) { successSound(); onClose(); }
      else { errorSound(); setErr(r.error); }
    } else {
      const r = registerUser(u, p, avatar);
      if (r.ok) { successSound(); onClose(); }
      else { errorSound(); setErr(r.error); }
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.92, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.95 }}
            onClick={e => e.stopPropagation()}
            className="relative w-full max-w-md bg-[#152030] border border-[#22324a] rounded-xl p-6 shadow-2xl"
          >
            <button onClick={onClose} className="absolute top-3 right-3 w-8 h-8 rounded text-white/40 hover:text-white hover:bg-[#0F1923]">✕</button>

            <div className="text-center mb-5">
              <div className="text-white font-black text-2xl tracking-tight">
                CASE <span className="text-[#FF6B1A]">BATTLE</span> SIM
              </div>
              <div className="text-[10px] text-[#FF6B1A] tracking-[0.2em] font-bold">{t('welcome')}</div>
            </div>

            <div className="flex bg-[#0F1923] rounded mb-4 p-1">
              {(['login','register'] as const).map(m => (
                <button
                  key={m}
                  onClick={() => { setMode(m); clickSound(); setErr(null); }}
                  className={['flex-1 py-2 text-sm font-bold rounded', mode === m ? 'bg-[#FF6B1A] text-white' : 'text-white/50 hover:text-white'].join(' ')}
                >{m === 'login' ? t('login') : t('register')}</button>
              ))}
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-white/55 uppercase tracking-wider">{t('username')}</label>
                <input
                  value={u} onChange={e => setU(e.target.value)}
                  className="w-full mt-1 bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white"
                  placeholder={mode === 'login' ? 'Ваш логин' : 'Придумайте логин'}
                />
              </div>
              <div>
                <label className="text-[11px] text-white/55 uppercase tracking-wider">{t('password')}</label>
                <input
                  type="password" value={p} onChange={e => setP(e.target.value)}
                  className="w-full mt-1 bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white"
                  placeholder="••••••••"
                />
              </div>

              {mode === 'register' && (
                <div>
                  <label className="text-[11px] text-white/55 uppercase tracking-wider">{t('pick_avatar')}</label>
                  <div className="grid grid-cols-10 gap-1.5 mt-1">
                    {AVATAR_LIST.map(a => (
                      <button
                        key={a}
                        onClick={() => { setAvatar(a); clickSound(); }}
                        className={['w-8 h-8 rounded flex items-center justify-center text-lg', avatar === a ? 'bg-[#FF6B1A] ring-2 ring-[#FF6B1A]/60' : 'bg-[#0F1923] hover:bg-[#1f2a3d]'].join(' ')}
                      >{a}</button>
                    ))}
                  </div>
                </div>
              )}

              {err && <div className="text-red-400 text-sm bg-red-500/10 border border-red-500/30 rounded px-3 py-2">{err}</div>}

              <button
                onClick={submit}
                className="w-full py-2.5 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold tracking-wide"
              >{mode === 'login' ? t('login') : t('register')}</button>

              <div className="text-[11px] text-white/35 text-center pt-1">
                Аккаунт хранится локально в браузере · нет реальных денег
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
