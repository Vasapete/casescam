import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, useAnimationControls } from 'framer-motion';
import type { CaseDef, Skin } from '../lib/types';
import { rollFromCase } from '../lib/cases';
import { getSkin, isLuckyHour } from '../lib/store';
import { RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from './SkinIcon';
import { dropSound, spinStartSound, successSound, tickSound } from '../lib/sound';

// Cell layout (matches the .reel-cell class below)
const CELL_WIDTH = 160;
const CELL_GAP = 12;          // margin-x equivalent
const CELL_STRIDE = CELL_WIDTH + CELL_GAP; // distance between cell centers
const REEL_LENGTH = 90;
const WIN_INDEX = 60;         // winner slot

export type OpenResult = { skin: Skin };

export function CaseOpener({
  caseDef, count, quick, onDone, onClose,
}: {
  caseDef: CaseDef;
  count: number;             // 1, 2, 3 or 5
  quick: boolean;
  onDone: (results: OpenResult[]) => void;
  onClose: () => void;
}) {
  // Pre-roll all winners ONCE
  const winners = useMemo(() => {
    const lucky = isLuckyHour();
    return Array.from({ length: count }, () => getSkin(rollFromCase(caseDef, lucky))!);
  }, [caseDef.id, count]);

  const [shown, setShown] = useState(false);
  const [shake, setShake] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const completedRef = useRef(0);
  const doneRef = useRef(false);

  function finalize() {
    if (doneRef.current) return;
    doneRef.current = true;
    const top = winners.reduce((a, b) => a.price > b.price ? a : b);
    if (top.rarity === 'ancient' || top.rarity === 'immortal') {
      setShake(true);
      setFlash(RARITY_COLORS[top.rarity].hex);
      successSound();
      setTimeout(() => setFlash(null), 1400);
      setTimeout(() => setShake(false), 800);
    }
    setShown(true);
  }

  // Quick mode: instantly play drop sounds and show results
  useEffect(() => {
    if (quick) {
      // play one bundled sound
      winners.forEach((w, i) => setTimeout(() => dropSound(w.rarity), i * 90));
      // schedule auto-finalize after a tiny moment for the modal flash
      setTimeout(() => {
        finalize();
        setTimeout(() => onDone(winners.map(w => ({ skin: w }))), 450);
      }, Math.min(700, 100 + winners.length * 90));
      return;
    }
    spinStartSound();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleReelComplete() {
    completedRef.current += 1;
    if (completedRef.current === winners.length) {
      finalize();
      setTimeout(() => onDone(winners.map(w => ({ skin: w }))), 1500);
    }
  }

  // Quick mode renders a static result grid (no reels)
  if (quick) {
    return (
      <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center px-4">
        {flash && (
          <div className="pointer-events-none absolute inset-0 flash" style={{ background: `radial-gradient(circle at center, ${flash}88, transparent 60%)` }} />
        )}
        <div className={['w-full max-w-5xl', shake ? 'shake' : ''].join(' ')}>
          <div className="text-center mb-4">
            <div className="text-[12px] uppercase tracking-[0.3em] text-white/40">⚡ Быстрое открытие</div>
            <div className="text-white font-black text-2xl">{caseDef.name}</div>
          </div>
          <div className={[
            'grid gap-3 mx-auto',
            winners.length === 1 ? 'grid-cols-1 max-w-xs' :
            winners.length === 2 ? 'grid-cols-2 max-w-2xl' :
            winners.length === 3 ? 'grid-cols-3 max-w-3xl' :
            'grid-cols-2 sm:grid-cols-5 max-w-5xl',
          ].join(' ')}>
            {winners.map((w, i) => {
              const col = RARITY_COLORS[w.rarity].hex;
              return (
                <motion.div key={i}
                  initial={{ scale: 0.6, opacity: 0, y: 20 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.09, type: 'spring', stiffness: 280, damping: 22 }}
                  className="bg-[#0F1923] rounded-lg p-3 flex flex-col items-center"
                  style={{ borderBottom: `3px solid ${col}`, boxShadow: `0 0 28px ${col}66` }}
                >
                  <SkinIcon skin={w} className="h-[90px] my-2" />
                  <div className="text-[12px] font-bold text-white truncate w-full text-center">{w.name}</div>
                  <div className="text-[11px] text-white/55 truncate w-full text-center">{w.skin_name}</div>
                  <div className="text-[14px] font-black mt-1" style={{ color: col }}>
                    {w.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center px-2 overflow-y-auto py-6">
      {flash && (
        <div className="pointer-events-none absolute inset-0 flash" style={{ background: `radial-gradient(circle at center, ${flash}88, transparent 60%)` }} />
      )}
      <div className={['w-full max-w-5xl my-auto', shake ? 'shake' : ''].join(' ')}>
        <div className="text-center mb-3">
          <div className="text-[12px] uppercase tracking-[0.3em] text-white/40">Открываем кейс</div>
          <div className="text-white font-black text-2xl">{caseDef.name}</div>
        </div>

        <div className="space-y-2">
          {winners.map((winner, i) => (
            <Reel
              key={i}
              caseDef={caseDef}
              winner={winner}
              onComplete={handleReelComplete}
              durationMs={3800 + i * 250}
            />
          ))}
        </div>

        {shown && (
          <motion.div
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="flex justify-center gap-3 mt-4"
          >
            <button onClick={onClose}
              className="px-6 py-2.5 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">
              Забрать
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function Reel({
  caseDef, winner, onComplete, durationMs,
}: {
  caseDef: CaseDef; winner: Skin; onComplete: () => void; durationMs: number;
}) {
  const controls = useAnimationControls();
  const containerRef = useRef<HTMLDivElement | null>(null);
  const tickRef = useRef<number | null>(null);
  const completedRef = useRef(false);
  const [highlighted, setHighlighted] = useState(false);

  // Stable items list — DO NOT regenerate on re-renders
  const items = useMemo<Skin[]>(() => {
    const pool = caseDef.items.map(it => getSkin(it.skinId)!).filter(Boolean);
    const arr: Skin[] = [];
    for (let i = 0; i < REEL_LENGTH; i++) {
      arr.push(pool[Math.floor(Math.random() * pool.length)]);
    }
    arr[WIN_INDEX] = winner;
    // Also place a few "near-misses" — same rarity neighbors for vibe
    return arr;
  }, [caseDef.id, winner.id]);

  useEffect(() => {
    if (!items.length || !containerRef.current) return;

    const containerWidth = containerRef.current.offsetWidth;
    // The winning cell's left edge is at: WIN_INDEX * CELL_STRIDE + CELL_GAP/2
    // Its center is at:                   WIN_INDEX * CELL_STRIDE + CELL_GAP/2 + CELL_WIDTH/2
    const winnerCenterX = WIN_INDEX * CELL_STRIDE + CELL_GAP / 2 + CELL_WIDTH / 2;
    // We want the winner's center to land at containerWidth/2.
    // Add small randomized jitter (±35% of cell) so it doesn't always center perfectly.
    const jitter = (Math.random() - 0.5) * CELL_WIDTH * 0.7;
    const targetX = -(winnerCenterX - containerWidth / 2) + jitter;

    controls.set({ x: 0 });
    controls.start({
      x: targetX,
      transition: { duration: durationMs / 1000, ease: [0.16, 0.93, 0.18, 1] },
    }).then(() => {
      if (completedRef.current) return;
      completedRef.current = true;
      setHighlighted(true);
      dropSound(winner.rarity);
      if (tickRef.current) { clearTimeout(tickRef.current); tickRef.current = null; }
      onComplete();
    });

    // tick sounds — decelerate to match the easing
    const startTime = performance.now();
    const tickLoop = () => {
      const t = performance.now() - startTime;
      if (t >= durationMs - 150) return;
      tickSound();
      // ease: start fast (40ms) → end slow (220ms)
      const progress = t / durationMs;
      const interval = 40 + Math.pow(progress, 2.2) * 200;
      tickRef.current = window.setTimeout(tickLoop, interval);
    };
    tickRef.current = window.setTimeout(tickLoop, 40);

    return () => { if (tickRef.current) clearTimeout(tickRef.current); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items]);

  return (
    <div ref={containerRef} className="relative h-[170px] bg-[#0c1521] border border-[#22324a] rounded-lg overflow-hidden">
      {/* Center indicator */}
      <div className="pointer-events-none absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-[3px] bg-[#FF6B1A] z-20 shadow-[0_0_18px_#FF6B1A]" />
      <div className="pointer-events-none absolute left-1/2 -translate-x-1/2 top-0 z-20"
        style={{ borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderTop: '10px solid #FF6B1A' }} />
      <div className="pointer-events-none absolute left-1/2 -translate-x-1/2 bottom-0 z-20"
        style={{ borderLeft: '8px solid transparent', borderRight: '8px solid transparent', borderBottom: '10px solid #FF6B1A' }} />
      {/* Fade edges */}
      <div className="pointer-events-none absolute inset-y-0 left-0 w-32 bg-gradient-to-r from-[#0c1521] to-transparent z-10" />
      <div className="pointer-events-none absolute inset-y-0 right-0 w-32 bg-gradient-to-l from-[#0c1521] to-transparent z-10" />

      <motion.div animate={controls} className="absolute top-0 left-0 h-full flex items-center will-change-transform">
        {items.map((s, i) => (
          <ReelCell key={i} skin={s} winning={highlighted && i === WIN_INDEX} />
        ))}
      </motion.div>
    </div>
  );
}

function ReelCell({ skin, winning }: { skin: Skin; winning: boolean }) {
  const col = RARITY_COLORS[skin.rarity].hex;
  return (
    <div
      className={['reel-cell relative shrink-0 h-[150px] rounded-md flex flex-col items-center justify-center px-2',
        winning ? 'scale-110' : ''].join(' ')}
      style={{
        width: CELL_WIDTH,
        marginLeft: CELL_GAP / 2,
        marginRight: CELL_GAP / 2,
        background: `linear-gradient(180deg, ${col}22 0%, ${col}05 100%)`,
        borderBottom: `3px solid ${col}`,
        boxShadow: winning ? `0 0 30px ${col}` : `inset 0 -10px 20px -10px ${col}55`,
        transition: 'transform .25s ease',
      }}
    >
      <SkinIcon skin={skin} className="max-h-[80px] max-w-full" />
      <div className="text-[10px] text-white/80 font-bold truncate w-full text-center mt-1">{skin.name}</div>
      <div className="text-[9px] text-white/45 truncate w-full text-center">{skin.skin_name}</div>
      <div className="text-[10px] font-bold mt-0.5" style={{ color: col }}>
        {skin.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽
      </div>
    </div>
  );
}
