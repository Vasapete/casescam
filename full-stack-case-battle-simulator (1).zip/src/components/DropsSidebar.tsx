import { useEffect } from 'react';
import { useStore, pushDropFeed, getSkin } from '../lib/store';
import { SKINS, RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from './SkinIcon';
import { motion, AnimatePresence } from 'framer-motion';

const FAKE_USERS: { name: string; av: string }[] = [
  { name: 'FireFly',       av: '🦊' },
  { name: 'iceberg',       av: '🐺' },
  { name: 'Vapor',         av: '👻' },
  { name: 'Phoenix#01',    av: '🔥' },
  { name: 'NoMercy',       av: '⚔️' },
  { name: 'quins3',        av: '😈' },
  { name: 'БамБолдик',     av: '🐻' },
  { name: 'BulletHail',    av: '💀' },
  { name: 'xD',            av: '😎' },
  { name: 'konewya',       av: '🐱' },
  { name: 'VortexGG',      av: '🌀' },
  { name: 'PixelPanda',    av: '🐼' },
  { name: 'Salamandra',    av: '🦎' },
  { name: '★zLoY★',        av: '🥷' },
  { name: 'мерч_2007',     av: '🎮' },
  { name: 'кеша♥',         av: '💖' },
  { name: 'хочу_нож',      av: '🗡️' },
  { name: '★m1ka',         av: '🌸' },
];
const FAKE_CASES = ['ХОУМЛЕНДЕР','ИМПЕРАТОР','НОЖ МЕЧТЫ','AK-47 ВСЕМ','AWP ВСЕМ','ДРАКОН','ФЕНИКС','ГАЛАКТИКА','ПАЦАНЫ','RESIDENT EVIL','ВИКТОР ГИДЕОН'];

// Weighted random for fake drops — bias toward higher rarities (drama)
function pickFakeSkin() {
  const r = Math.random();
  let rarities: string[];
  if (r < 0.0015) rarities = ['immortal'];                    // jackpot moments
  else if (r < 0.012) rarities = ['ancient'];                 // reds
  else if (r < 0.10) rarities = ['legendary'];                // pinks (often)
  else if (r < 0.45) rarities = ['mythical'];                 // purples (most common feed entry)
  else                rarities = ['rare', 'mythical'];        // blues + purples
  const pool = SKINS.filter(s => rarities.includes(s.rarity));
  return pool[Math.floor(Math.random() * pool.length)];
}

export function DropsSidebar() {
  const feed = useStore(s => s.dropFeed);
  const currentUsername = useStore(s => s.currentUserId ? s.users[s.currentUserId]?.username : null);

  useEffect(() => {
    let alive = true;
    const tick = () => {
      if (!alive) return;
      const skin = pickFakeSkin();
      if (skin) {
        const user = FAKE_USERS[Math.floor(Math.random() * FAKE_USERS.length)];
        pushDropFeed({
          username: user.name,
          avatar: user.av,
          skinId: skin.id,
          caseName: FAKE_CASES[Math.floor(Math.random() * FAKE_CASES.length)],
        });
      }
      // Faster cadence for high rarities, slower for low
      setTimeout(tick, 3500 + Math.random() * 5000);
    };
    const id = setTimeout(tick, 3000);
    return () => { alive = false; clearTimeout(id); };
  }, []);

  return (
    <aside className="hidden lg:block w-[150px] bg-[#0c1521] border-r border-[#1f2a3d] sticky top-[70px] h-[calc(100vh-70px)] overflow-y-auto no-scrollbar">
      <div className="px-2 py-2 border-b border-[#15212f] text-[10px] uppercase tracking-wider text-white/45 font-bold text-center">
        🔥 Лучшие дропы
      </div>
      <AnimatePresence initial={false}>
        {feed.slice(0, 18).map(d => {
          const skin = getSkin(d.skinId);
          if (!skin) return null;
          const col = RARITY_COLORS[skin.rarity].hex;
          const isMe = !!currentUsername && d.username === currentUsername;
          const isBig = skin.rarity === 'ancient' || skin.rarity === 'immortal';
          return (
            <motion.div
              key={d.id}
              initial={{ opacity: 0, y: -30, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className={[
                'relative px-2 py-2 border-b border-[#15212f] group',
                isMe ? 'bg-[#FF6B1A]/10' : '',
                isBig ? 'bg-gradient-to-r from-transparent via-' + (skin.rarity === 'immortal' ? 'yellow' : 'red') + '-500/5 to-transparent' : '',
              ].join(' ')}
              style={{ borderLeft: `3px solid ${col}`, boxShadow: isBig ? `inset 0 0 18px ${col}33` : undefined }}
            >
              {isMe && (
                <div className="absolute top-0.5 right-0.5 text-[8px] bg-[#FF6B1A] text-white font-black px-1 rounded">YOU</div>
              )}
              <div className="h-[60px] flex items-center justify-center">
                <SkinIcon skin={skin} className="max-h-[56px] max-w-full" />
              </div>
              <div className="flex items-center gap-1 mt-0.5">
                <span className="text-[10px]">{d.avatar}</span>
                <span className="text-[9px] text-white/60 truncate flex-1" title={d.username}>{d.username}</span>
              </div>
              <div className="text-[10px] font-bold text-white/85 text-center truncate">{skin.name}</div>
              <div className="text-[9px] text-white/45 text-center truncate">{skin.skin_name}</div>
              <div className="text-[10px] font-black text-center mt-0.5" style={{ color: col }}>
                {skin.price.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽
              </div>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </aside>
  );
}
