import { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { DropsSidebar } from './components/DropsSidebar';
import { AuthModal } from './components/AuthModal';
import { CasesPage } from './pages/CasesPage';
import { CaseDetailPage } from './pages/CaseDetailPage';
import { ProfilePage } from './pages/ProfilePage';
import { UpgradePage } from './pages/UpgradePage';
import { ContractsPage } from './pages/ContractsPage';
import { GiveawaysPage } from './pages/GiveawaysPage';
import { BattlesPage } from './pages/BattlesPage';
import { MinesPage } from './pages/MinesPage';
import { AdminPage } from './pages/AdminPage';
import { loadIconMap } from './lib/skinData';
import type { CaseDef } from './lib/types';
import { useStore } from './lib/store';

type Page = 'cases' | 'battles' | 'mines' | 'upgrade' | 'contracts' | 'giveaways' | 'profile' | 'admin';

export default function App() {
  const [page, setPage] = useState<Page>('cases');
  const [selectedCase, setSelectedCase] = useState<CaseDef | null>(null);
  const [authOpen, setAuthOpen] = useState(false);
  const [iconsLoaded, setIconsLoaded] = useState(false);
  const lang = useStore(s => s.lang);

  useEffect(() => { document.documentElement.lang = lang; }, [lang]);

  useEffect(() => {
    loadIconMap().then(() => setIconsLoaded(true));
  }, []);

  function nav(p: Page) {
    setPage(p);
    setSelectedCase(null);
  }

  return (
    <div className="min-h-screen bg-[#0F1923] text-white">
      <Navbar page={page} onNav={nav} onAuth={() => setAuthOpen(true)} />

      <div className="flex">
        {page !== 'admin' && <DropsSidebar />}
        <main className="flex-1 min-w-0">
          {!iconsLoaded && (
            <div className="text-center py-1 bg-[#152030] border-b border-[#22324a] text-[11px] text-white/45">
              Загружаем иконки скинов...
            </div>
          )}

          {page === 'cases' && !selectedCase && (
            <CasesPage onPick={setSelectedCase} />
          )}
          {page === 'cases' && selectedCase && (
            <CaseDetailPage
              caseDef={selectedCase}
              onBack={() => setSelectedCase(null)}
              onLogin={() => setAuthOpen(true)}
            />
          )}
          {page === 'battles' && <BattlesPage onLogin={() => setAuthOpen(true)} />}
          {page === 'mines' && <MinesPage onLogin={() => setAuthOpen(true)} />}
          {page === 'upgrade' && <UpgradePage onLogin={() => setAuthOpen(true)} />}
          {page === 'contracts' && <ContractsPage onLogin={() => setAuthOpen(true)} />}
          {page === 'giveaways' && <GiveawaysPage onLogin={() => setAuthOpen(true)} />}
          {page === 'profile' && <ProfilePage onLogin={() => setAuthOpen(true)} />}
          {page === 'admin' && <AdminPage onLogin={() => setAuthOpen(true)} />}
        </main>
      </div>

      <footer className="border-t border-[#1f2a3d] mt-10 py-6 px-6 text-[11px] text-white/35">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center gap-x-6 gap-y-2 justify-between">
          <div>CASE-BATTLE SIM © 2026 — fun demo · no real money</div>
          <div className="flex gap-4">
            <span>Техподдержка</span>
            <span>Правила</span>
            <span>Промокоды: WELCOME500 · COMET-14</span>
          </div>
        </div>
      </footer>

      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
    </div>
  );
}
