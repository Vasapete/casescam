// Synthesized sound effects via WebAudio — no asset files needed.
// Beefier than before: layered oscillators, noise bursts, filters.

let ctx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let muted = false;
const MUTE_KEY = 'cbsim_muted';
try { muted = localStorage.getItem(MUTE_KEY) === '1'; } catch {}

export function isMuted() { return muted; }
export function toggleMute() {
  muted = !muted;
  try { localStorage.setItem(MUTE_KEY, muted ? '1' : '0'); } catch {}
}

function getCtx(): AudioContext | null {
  if (muted) return null;
  if (!ctx) {
    try {
      ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      masterGain = ctx.createGain();
      masterGain.gain.value = 0.55;
      masterGain.connect(ctx.destination);
    } catch { return null; }
  }
  if (ctx.state === 'suspended') ctx.resume().catch(() => {});
  return ctx;
}

function dest(): AudioNode | null {
  const c = getCtx(); if (!c || !masterGain) return null;
  return masterGain;
}

// ---------- Primitives ----------
function tone(opts: {
  freq: number; dur: number; type?: OscillatorType; vol?: number; at?: number;
  toFreq?: number; // sweep target
  attack?: number; decay?: number;
}) {
  const c = getCtx(); const out = dest(); if (!c || !out) return;
  const t0 = c.currentTime + (opts.at ?? 0);
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = opts.type ?? 'sine';
  osc.frequency.setValueAtTime(opts.freq, t0);
  if (opts.toFreq) osc.frequency.exponentialRampToValueAtTime(Math.max(1, opts.toFreq), t0 + opts.dur);
  const attack = opts.attack ?? 0.005;
  const decay = opts.decay ?? opts.dur;
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(opts.vol ?? 0.15, t0 + attack);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + decay);
  osc.connect(g); g.connect(out);
  osc.start(t0); osc.stop(t0 + opts.dur + 0.05);
}

function noise(opts: { dur: number; vol?: number; at?: number; filterFreq?: number; q?: number; sweepTo?: number }) {
  const c = getCtx(); const out = dest(); if (!c || !out) return;
  const t0 = c.currentTime + (opts.at ?? 0);
  const buf = c.createBuffer(1, Math.max(1, Math.floor(c.sampleRate * opts.dur)), c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  const src = c.createBufferSource();
  src.buffer = buf;
  const filter = c.createBiquadFilter();
  filter.type = 'bandpass';
  filter.frequency.setValueAtTime(opts.filterFreq ?? 1200, t0);
  if (opts.sweepTo) filter.frequency.exponentialRampToValueAtTime(opts.sweepTo, t0 + opts.dur);
  filter.Q.value = opts.q ?? 1.2;
  const g = c.createGain();
  g.gain.setValueAtTime(opts.vol ?? 0.12, t0);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + opts.dur);
  src.connect(filter); filter.connect(g); g.connect(out);
  src.start(t0); src.stop(t0 + opts.dur + 0.05);
}

// ---------- Sounds ----------
export function clickSound() {
  tone({ freq: 800, dur: 0.04, type: 'square', vol: 0.08, attack: 0.001 });
  tone({ freq: 1400, dur: 0.025, type: 'sine', vol: 0.05, attack: 0.001 });
}

export function tickSound() {
  // mechanical clack — short noise burst with metallic pitch
  noise({ dur: 0.03, vol: 0.18, filterFreq: 2400, q: 6 });
  tone({ freq: 1800 + Math.random() * 600, dur: 0.025, type: 'square', vol: 0.06, attack: 0.001 });
}

export function spinStartSound() {
  // building riser
  tone({ freq: 110, toFreq: 440, dur: 0.45, type: 'sawtooth', vol: 0.12, attack: 0.02 });
  tone({ freq: 220, toFreq: 880, dur: 0.45, type: 'triangle', vol: 0.08, attack: 0.02, at: 0.05 });
  noise({ dur: 0.4, vol: 0.06, filterFreq: 500, sweepTo: 3000, q: 1.5 });
}

export function dropSound(rarity: string) {
  const c = getCtx(); if (!c) return;
  if (rarity === 'immortal') {
    // GOLD: massive layered fanfare + sparkle
    tone({ freq: 80, dur: 0.6, type: 'sine', vol: 0.25 });               // sub bass
    [523, 659, 784, 1047, 1318].forEach((f, i) =>
      tone({ freq: f, dur: 0.5 - i * 0.05, type: 'triangle', vol: 0.16, at: i * 0.07 })
    );
    [1568, 2093, 2637].forEach((f, i) =>
      tone({ freq: f, dur: 0.4, type: 'sine', vol: 0.08, at: 0.35 + i * 0.08 })
    );
    noise({ dur: 0.8, vol: 0.05, filterFreq: 6000, q: 0.5 });
  } else if (rarity === 'ancient') {
    // RED: big punch + chord
    tone({ freq: 100, dur: 0.4, type: 'sine', vol: 0.22 });
    [440, 554, 659, 880].forEach((f, i) =>
      tone({ freq: f, dur: 0.4, type: 'triangle', vol: 0.14, at: i * 0.06 })
    );
    noise({ dur: 0.3, vol: 0.08, filterFreq: 1800, sweepTo: 800, q: 1 });
  } else if (rarity === 'legendary') {
    // PINK: bright chord
    [523, 659, 784].forEach((f, i) =>
      tone({ freq: f, dur: 0.3, type: 'triangle', vol: 0.14, at: i * 0.06 })
    );
    tone({ freq: 1568, dur: 0.25, type: 'sine', vol: 0.08, at: 0.18 });
  } else if (rarity === 'mythical') {
    // PURPLE: two-tone
    tone({ freq: 440, dur: 0.18, type: 'triangle', vol: 0.13 });
    tone({ freq: 659, dur: 0.22, type: 'triangle', vol: 0.13, at: 0.08 });
  } else if (rarity === 'rare') {
    tone({ freq: 523, dur: 0.16, type: 'sine', vol: 0.12 });
    tone({ freq: 784, dur: 0.18, type: 'sine', vol: 0.09, at: 0.05 });
  } else {
    // common/uncommon: soft tick
    tone({ freq: 440, dur: 0.1, type: 'sine', vol: 0.08 });
  }
}

export function successSound() {
  tone({ freq: 523, dur: 0.12, type: 'triangle', vol: 0.14 });
  tone({ freq: 659, dur: 0.12, type: 'triangle', vol: 0.14, at: 0.08 });
  tone({ freq: 784, dur: 0.2, type: 'triangle', vol: 0.14, at: 0.16 });
}

export function failSound() {
  tone({ freq: 330, toFreq: 110, dur: 0.4, type: 'sawtooth', vol: 0.18 });
  noise({ dur: 0.25, vol: 0.08, filterFreq: 600, q: 1 });
}

export function errorSound() {
  tone({ freq: 220, dur: 0.12, type: 'square', vol: 0.12 });
  tone({ freq: 180, dur: 0.12, type: 'square', vol: 0.12, at: 0.08 });
}

export function coinSound() {
  // satisfying coin pickup
  tone({ freq: 988, dur: 0.08, type: 'triangle', vol: 0.16 });
  tone({ freq: 1319, dur: 0.18, type: 'triangle', vol: 0.14, at: 0.05 });
}

export function explodeSound() {
  // mines: boom
  tone({ freq: 80, toFreq: 30, dur: 0.5, type: 'sawtooth', vol: 0.3 });
  noise({ dur: 0.6, vol: 0.25, filterFreq: 2400, sweepTo: 200, q: 0.5 });
}

export function revealSound() {
  // mines: safe reveal
  tone({ freq: 660, dur: 0.08, type: 'sine', vol: 0.12 });
  tone({ freq: 990, dur: 0.12, type: 'sine', vol: 0.09, at: 0.04 });
}
