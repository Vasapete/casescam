import { useStore } from './store';
import { STRINGS, type TKey } from './i18n';

export function useT() {
  const lang = useStore(s => s.lang);
  return (key: TKey) => STRINGS[lang][key];
}

export function useLang() {
  return useStore(s => s.lang);
}
