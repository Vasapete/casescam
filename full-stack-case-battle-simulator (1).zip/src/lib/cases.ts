import type { CaseDef, CaseCategory, Rarity, Skin } from './types';
import { SKINS, SKIN_BY_ID } from './skinData';

// ===========================================================================
// Case generation — TIER-AWARE
// ===========================================================================
// Each case has a target price. We:
//   1) Build the item pool from skins whose price is sensible for that tier
//      (lower bound stops $4 junk in a 4000₽ case; upper bound stops a
//      Dragon Lore from showing up in a 50₽ case).
//   2) Assign drop weights so EV ≈ price * (1 - houseEdge).
//   3) Always include 1-2 "jackpot" trophies (top-rarity for the tier) at
//      tiny probability to provide the dopamine hook.
// ===========================================================================

const HOUSE_EDGE = 0.25; // EV ≈ 75% of price (typical case-opening site)

// Returns [minPrice, maxPrice] window for a case of given price.
function priceWindow(casePrice: number): [number, number] {
  if (casePrice === 0) return [0.5, 200];        // free cases: cheapest
  if (casePrice < 80)  return [casePrice * 0.06, casePrice * 12];
  if (casePrice < 250) return [casePrice * 0.05, casePrice * 18];
  if (casePrice < 800) return [casePrice * 0.10, casePrice * 25];
  if (casePrice < 2000) return [casePrice * 0.15, casePrice * 40];
  return [casePrice * 0.18, casePrice * 80]; // big cases: real jackpot ceiling
}

// Top rarity available for the tier (used to determine "jackpot" pool).
function topRarityFor(casePrice: number): Rarity {
  if (casePrice === 0) return 'rare';
  if (casePrice < 100) return 'legendary';
  if (casePrice < 400) return 'ancient';
  return 'immortal';
}

// Pick base "common" tier for the case (i.e., the floor rarity).
function floorRarityFor(casePrice: number): Rarity {
  if (casePrice === 0) return 'common';
  if (casePrice < 200) return 'uncommon';
  if (casePrice < 800) return 'rare';
  if (casePrice < 2500) return 'mythical';
  return 'legendary';
}

// Deterministic seeded shuffle so cases are stable between reloads
function seededShuffle<T>(arr: T[], seed: string): T[] {
  let h = 0; for (let i = 0; i < seed.length; i++) h = (h * 31 + seed.charCodeAt(i)) | 0;
  const rand = () => { h = (h * 1664525 + 1013904223) | 0; return ((h >>> 0) % 10000) / 10000; };
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const RARITY_ORDER: Record<Rarity, number> = {
  common: 0, uncommon: 1, rare: 2, mythical: 3, legendary: 4, ancient: 5, immortal: 6,
};

function buildCaseItems(casePrice: number, seedKey: string): { skinId: string; weight: number }[] {
  const [minP, maxP] = priceWindow(casePrice);
  const top = topRarityFor(casePrice);
  const floor = floorRarityFor(casePrice);

  // Pool of candidates: in price window and rarity in [floor, top]
  let pool = SKINS.filter(s =>
    s.price >= minP && s.price <= maxP &&
    RARITY_ORDER[s.rarity] >= RARITY_ORDER[floor] &&
    RARITY_ORDER[s.rarity] <= RARITY_ORDER[top]
  );

  // If too small, relax constraints
  if (pool.length < 15) {
    pool = SKINS.filter(s =>
      s.price >= minP * 0.5 && s.price <= maxP * 1.2 &&
      RARITY_ORDER[s.rarity] >= RARITY_ORDER[floor]
    );
  }
  if (pool.length < 10) {
    pool = SKINS.filter(s => s.price <= maxP * 2);
  }

  // Deterministic subset — use seed+hash to pick a UNIQUE slice of the pool
  // by rotating the start offset so similar-priced cases get different skins.
  const targetSize = casePrice === 0 ? 28 : Math.min(44, Math.max(28, Math.round(28 + casePrice / 400)));
  const shuffled = seededShuffle(pool, seedKey + '_v3');
  // Extra diversity: skip first N items based on name hash so each case slices a different window
  const nameHash = seedKey.split('').reduce((a, c) => ((a * 31 + c.charCodeAt(0)) | 0) >>> 0, 0);
  const skipOffset = nameHash % Math.max(1, shuffled.length - targetSize);
  let chosen = shuffled.slice(skipOffset, skipOffset + targetSize);
  // If we wrapped around or got too few, just take from start
  if (chosen.length < targetSize) {
    chosen = shuffled.slice(0, targetSize);
  }

  // Guarantee at least one jackpot of `top` rarity (if available in DB)
  const topPool = SKINS.filter(s => s.rarity === top);
  if (topPool.length > 0 && casePrice > 0) {
    const seedTop = seededShuffle(topPool, seedKey + '_top').slice(0, 2);
    for (const t of seedTop) {
      if (!chosen.find(c => c.id === t.id)) chosen.push(t);
    }
  }

  // Compute weights so EV ≈ casePrice * (1 - HOUSE_EDGE)
  const targetEV = casePrice === 0 ? 35 : casePrice * (1 - HOUSE_EDGE);

  // Initial weights: inversely proportional to price^0.85 within rarity
  // (cheaper skins drop more often, expensive ones rarely).
  // Multiplied by a rarity-tier modifier that ensures jackpots are very rare.
  const rarityMul: Record<Rarity, number> = {
    common: 1, uncommon: 1, rare: 0.55, mythical: 0.18, legendary: 0.045, ancient: 0.011, immortal: 0.0025,
  };

  const raw = chosen.map(s => {
    const base = 1 / Math.pow(Math.max(1, s.price), 0.85);
    return { skin: s, w: base * rarityMul[s.rarity] };
  });
  // Normalize so sum=1
  const sum = raw.reduce((a, b) => a + b.w, 0) || 1;
  raw.forEach(r => { r.w = r.w / sum; });

  // Adjust to match targetEV by scaling cheap-vs-expensive distribution.
  // Iterative: if EV too high → bias toward cheaper. If too low → bias toward
  // more expensive. We multiply weight of skins above median by k or 1/k.
  const median = [...raw].sort((a, b) => a.skin.price - b.skin.price)[Math.floor(raw.length / 2)].skin.price;
  let lo = 0.05, hi = 20;
  for (let iter = 0; iter < 24; iter++) {
    const k = Math.sqrt(lo * hi);
    const adj = raw.map(r => ({ ...r, w: r.skin.price > median ? r.w * k : r.w / k }));
    const totalW = adj.reduce((a, b) => a + b.w, 0);
    const ev = adj.reduce((a, b) => a + (b.w / totalW) * b.skin.price, 0);
    if (Math.abs(ev - targetEV) / targetEV < 0.03) {
      return adj.map(r => ({ skinId: r.skin.id, weight: r.w / totalW }));
    }
    if (ev > targetEV) hi = k; else lo = k;
  }

  // Fallback: return normalized weights
  const totalW = raw.reduce((a, b) => a + b.w, 0);
  return raw.map(r => ({ skinId: r.skin.id, weight: r.w / totalW }));
}

// ============================== CASE SEEDS ==============================
const GRADIENTS = [
  'from-orange-600 via-red-700 to-purple-900',
  'from-cyan-500 via-blue-700 to-indigo-900',
  'from-pink-500 via-purple-700 to-indigo-900',
  'from-emerald-500 via-teal-700 to-slate-900',
  'from-amber-500 via-orange-700 to-rose-900',
  'from-fuchsia-500 via-purple-700 to-blue-900',
  'from-red-600 via-rose-800 to-slate-900',
  'from-lime-500 via-emerald-700 to-cyan-900',
  'from-sky-500 via-blue-700 to-violet-900',
  'from-yellow-500 via-orange-700 to-red-900',
];

type SeedDef = { name: string; price: number; cat: CaseCategory; isNew?: boolean; emoji: string };

const SERIAL: SeedDef[] = [
  { name: 'ЛЕОН КЕННЕДИ',      price: 39,   cat: 'serial', emoji: '🧟' },
  { name: 'ГРЕЙС ЭШКРОФТ',     price: 119,  cat: 'serial', isNew: true, emoji: '🌸' },
  { name: 'ВИКТОР ГИДЕОН',     price: 359,  cat: 'serial', isNew: true, emoji: '🧪' },
  { name: 'RACOON CORPORATION',price: 899,  cat: 'serial', isNew: true, emoji: '🏢' },
  { name: 'RESIDENT EVIL',     price: 2699, cat: 'serial', isNew: true, emoji: '🧬' },
  { name: 'ХЬЮИ КЭМПБЕЛЛ',     price: 55,   cat: 'serial', emoji: '🎬' },
  { name: 'ФРАНЦУЗИК',         price: 111,  cat: 'serial', emoji: '🥐' },
  { name: 'СОЛДАТИК',          price: 444,  cat: 'serial', emoji: '🎖️' },
  { name: 'ХОУМЛЕНДЕР',        price: 999,  cat: 'serial', emoji: '🦸' },
  { name: 'ПАЦАНЫ',            price: 4444, cat: 'serial', emoji: '🩸' },
  { name: 'НИНДЗЯ',            price: 69,   cat: 'serial', emoji: '🥷' },
  { name: 'САМУРАЙ',           price: 169,  cat: 'serial', emoji: '⚔️' },
  { name: 'РОНИН',             price: 299,  cat: 'serial', emoji: '🗡️' },
  { name: 'СЁГУН',             price: 699,  cat: 'serial', emoji: '🏯' },
  { name: 'ИМПЕРАТОР',         price: 1999, cat: 'serial', emoji: '👑' },
  { name: 'ДУНКАН ВЫСОКИЙ',    price: 249,  cat: 'serial', emoji: '🏔️' },
  { name: 'ВЕСТЛЕНД',          price: 379,  cat: 'serial', emoji: '🏜️' },
  { name: 'ТОКИО ДРИФТ',       price: 549,  cat: 'serial', emoji: '🏎️' },
  { name: 'НЕОН СИТИ',         price: 799,  cat: 'serial', emoji: '🌃' },
  { name: 'АПОКАЛИПСИС',       price: 1499, cat: 'serial', emoji: '☢️' },
];

const BRAND: SeedDef[] = [
  { name: 'AK-47 ВСЕМ',          price: 349, cat: 'brand', emoji: '🔫' },
  { name: 'M4A1-S ВСЕМ',         price: 379, cat: 'brand', emoji: '🔫' },
  { name: 'M4A4 ВСЕМ',           price: 329, cat: 'brand', emoji: '🔫' },
  { name: 'AWP ВСЕМ',            price: 799, cat: 'brand', emoji: '🎯' },
  { name: 'DESERT EAGLE ВСЕМ',   price: 269, cat: 'brand', emoji: '🦅' },
  { name: 'USP-S ВСЕМ',          price: 219, cat: 'brand', emoji: '🎯' },
  { name: 'GLOCK-18 ВСЕМ',       price: 159, cat: 'brand', emoji: '🔫' },
  { name: 'P250 ВСЕМ',           price: 139, cat: 'brand', emoji: '🔫' },
  { name: 'FAMAS ВСЕМ',          price: 129, cat: 'brand', emoji: '🔫' },
  { name: 'AUG ВСЕМ',            price: 189, cat: 'brand', emoji: '🔫' },
  { name: 'SSG 08 ВСЕМ',         price: 169, cat: 'brand', emoji: '🎯' },
  { name: 'P90 ВСЕМ',            price: 149, cat: 'brand', emoji: '🔫' },
  { name: 'MAC-10 ВСЕМ',         price: 119, cat: 'brand', emoji: '🔫' },
  { name: 'NOVA ВСЕМ',           price: 99,  cat: 'brand', emoji: '🔫' },
  { name: 'XM1014 ВСЕМ',         price: 109, cat: 'brand', emoji: '🔫' },
];

const PREMIUM: SeedDef[] = [
  { name: 'НОЖ МЕЧТЫ',          price: 3499, cat: 'premium', emoji: '🗡️', isNew: true },
  { name: 'ПЕРЧАТКИ ЛЕГЕНДЫ',   price: 2999, cat: 'premium', emoji: '🧤' },
  { name: 'ДРАКОН',             price: 1899, cat: 'premium', emoji: '🐉' },
  { name: 'ФЕНИКС',             price: 1599, cat: 'premium', emoji: '🔥' },
  { name: 'КОБРА',              price: 1399, cat: 'premium', emoji: '🐍' },
  { name: 'ВОЛК',               price: 1199, cat: 'premium', emoji: '🐺' },
  { name: 'ОРЁЛ',               price: 999,  cat: 'premium', emoji: '🦅' },
  { name: 'ТИГР',               price: 1799, cat: 'premium', emoji: '🐯' },
  { name: 'ЧЕРЕП',              price: 2499, cat: 'premium', emoji: '💀' },
  { name: 'ГАЛАКТИКА',          price: 4999, cat: 'premium', emoji: '🌌', isNew: true },
];

// Only ONE free case (claim every 4 hours).
const FREE: SeedDef[] = [
  { name: 'БЕСПЛАТНЫЙ КЕЙС',    price: 0, cat: 'free', emoji: '🎁' },
];

let _cases: CaseDef[] | null = null;
export function getCases(): CaseDef[] {
  if (_cases) return _cases;
  const all: CaseDef[] = [];
  const push = (s: SeedDef, idx: number) => {
    const items = buildCaseItems(s.price, s.name);
    all.push({
      id: `case_${s.cat}_${idx}`,
      name: s.name,
      image: s.emoji,
      price: s.price,
      category: s.cat,
      is_new: s.isNew,
      items,
      accent: GRADIENTS[(idx + s.name.length) % GRADIENTS.length],
    });
  };
  SERIAL.forEach((s, i) => push(s, i));
  BRAND.forEach((s, i) => push(s, 100 + i));
  PREMIUM.forEach((s, i) => push(s, 200 + i));
  FREE.forEach((s, i) => push(s, 300 + i));
  _cases = all;
  return all;
}

export function rollFromCase(c: CaseDef, luckyHour = false): string {
  let items = c.items;
  if (luckyHour) {
    items = items.map(it => {
      const s = SKIN_BY_ID.get(it.skinId)!;
      const boost = (s.rarity === 'ancient' || s.rarity === 'immortal' || s.rarity === 'legendary') ? 2 : 1;
      return { ...it, weight: it.weight * boost };
    });
  }
  const total = items.reduce((a, b) => a + b.weight, 0);
  let r = Math.random() * total;
  for (const it of items) {
    r -= it.weight;
    if (r <= 0) return it.skinId;
  }
  return items[items.length - 1].skinId;
}

export function caseExpectedValue(c: CaseDef): number {
  const total = c.items.reduce((a, b) => a + b.weight, 0);
  let ev = 0;
  for (const it of c.items) {
    const s = SKIN_BY_ID.get(it.skinId)!;
    ev += (it.weight / total) * s.price;
  }
  return ev;
}

export function topSkinsInCase(c: CaseDef, n = 3): Skin[] {
  return c.items
    .map(it => SKIN_BY_ID.get(it.skinId)!)
    .filter(Boolean)
    .sort((a, b) => b.price - a.price)
    .slice(0, n);
}
