// Generates unique SVG case images so every case looks different
// Uses deterministic seeding from the case name

function hashStr(s: string): number {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return h >>> 0;
}

function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) | 0;
    return (s >>> 0) / 4294967296;
  };
}

const PALETTES = [
  ['#FF6B1A', '#D32F2F', '#7B1FA2'],
  ['#00BCD4', '#1565C0', '#283593'],
  ['#E91E63', '#9C27B0', '#4A148C'],
  ['#4CAF50', '#00796B', '#004D40'],
  ['#FF9800', '#E65100', '#BF360C'],
  ['#E040FB', '#7C4DFF', '#304FFE'],
  ['#F44336', '#C62828', '#1A237E'],
  ['#76FF03', '#00C853', '#006064'],
  ['#40C4FF', '#2962FF', '#6200EA'],
  ['#FFD600', '#FF6D00', '#D50000'],
  ['#18FFFF', '#00B0FF', '#651FFF'],
  ['#FF1744', '#D500F9', '#3D5AFE'],
  ['#69F0AE', '#00BFA5', '#304FFE'],
  ['#FFAB00', '#FF3D00', '#AA00FF'],
];

const PATTERNS = ['lines', 'circles', 'diamonds', 'grid', 'waves', 'hex', 'cross', 'dots'];

export function generateCaseArt(name: string, _emoji?: string): string {
  const h = hashStr(name);
  const r = seededRandom(h);
  const pal = PALETTES[h % PALETTES.length];
  const pattern = PATTERNS[Math.floor(r() * PATTERNS.length)];
  const rot = Math.floor(r() * 360);
  const scale = 0.8 + r() * 0.4;

  let patternSvg = '';
  switch (pattern) {
    case 'lines':
      for (let i = 0; i < 8; i++) {
        const y = 20 + i * 22;
        const op = 0.08 + r() * 0.12;
        patternSvg += `<line x1="0" y1="${y}" x2="200" y2="${y + (r() - 0.5) * 30}" stroke="${pal[1]}" stroke-width="${1 + r() * 2}" opacity="${op}"/>`;
      }
      break;
    case 'circles':
      for (let i = 0; i < 5; i++) {
        const cx = 30 + r() * 140; const cy = 20 + r() * 130;
        patternSvg += `<circle cx="${cx}" cy="${cy}" r="${10 + r() * 30}" stroke="${pal[Math.floor(r() * 3)]}" fill="none" stroke-width="1.5" opacity="${0.1 + r() * 0.15}"/>`;
      }
      break;
    case 'diamonds':
      for (let i = 0; i < 6; i++) {
        const cx = 40 + r() * 120; const cy = 30 + r() * 110; const s = 12 + r() * 20;
        patternSvg += `<rect x="${cx - s/2}" y="${cy - s/2}" width="${s}" height="${s}" transform="rotate(45 ${cx} ${cy})" stroke="${pal[1]}" fill="none" stroke-width="1" opacity="${0.1 + r() * 0.12}"/>`;
      }
      break;
    case 'grid':
      for (let x = 15; x < 200; x += 25 + r() * 15) {
        patternSvg += `<line x1="${x}" y1="0" x2="${x}" y2="180" stroke="${pal[2]}" stroke-width="0.5" opacity="0.08"/>`;
      }
      for (let y = 15; y < 180; y += 25 + r() * 15) {
        patternSvg += `<line x1="0" y1="${y}" x2="200" y2="${y}" stroke="${pal[2]}" stroke-width="0.5" opacity="0.08"/>`;
      }
      break;
    case 'waves':
      for (let i = 0; i < 4; i++) {
        const y = 30 + i * 35; const a = 8 + r() * 16;
        patternSvg += `<path d="M0,${y} Q50,${y - a} 100,${y} T200,${y}" stroke="${pal[i % 3]}" fill="none" stroke-width="1.5" opacity="${0.1 + r() * 0.1}"/>`;
      }
      break;
    case 'hex':
      for (let i = 0; i < 7; i++) {
        const cx = 30 + r() * 140; const cy = 20 + r() * 140; const s = 10 + r() * 18;
        const pts = Array.from({ length: 6 }, (_, j) => {
          const a = (j * 60 - 30) * Math.PI / 180;
          return `${cx + s * Math.cos(a)},${cy + s * Math.sin(a)}`;
        }).join(' ');
        patternSvg += `<polygon points="${pts}" stroke="${pal[1]}" fill="none" stroke-width="1" opacity="${0.1 + r() * 0.12}"/>`;
      }
      break;
    case 'cross':
      for (let i = 0; i < 5; i++) {
        const cx = 30 + r() * 140; const cy = 25 + r() * 130; const s = 8 + r() * 15;
        patternSvg += `<line x1="${cx - s}" y1="${cy}" x2="${cx + s}" y2="${cy}" stroke="${pal[2]}" stroke-width="1.5" opacity="${0.12}"/>`;
        patternSvg += `<line x1="${cx}" y1="${cy - s}" x2="${cx}" y2="${cy + s}" stroke="${pal[2]}" stroke-width="1.5" opacity="${0.12}"/>`;
      }
      break;
    case 'dots':
      for (let i = 0; i < 20; i++) {
        const cx = 10 + r() * 180; const cy = 10 + r() * 160;
        patternSvg += `<circle cx="${cx}" cy="${cy}" r="${1 + r() * 3}" fill="${pal[Math.floor(r() * 3)]}" opacity="${0.15 + r() * 0.2}"/>`;
      }
      break;
  }

  // weapon silhouette shapes
  const silhouettes = [
    'M30,90 L50,80 L90,82 L110,75 L150,78 L170,85 L170,95 L150,92 L120,95 L80,93 L50,95 Z',
    'M25,88 L45,78 L100,80 L130,72 L175,80 L175,92 L130,88 L100,92 L45,94 Z',
    'M35,85 L60,75 L85,78 L120,70 L165,78 L168,90 L120,86 L85,90 L60,88 Z',
    'M40,92 L55,82 L80,80 L140,76 L170,82 L172,92 L140,88 L80,90 Z',
    'M20,90 L40,72 L80,70 L120,68 L170,75 L175,88 L120,84 L80,85 L40,88 Z',
  ];
  const sil = silhouettes[Math.floor(r() * silhouettes.length)];

  return `data:image/svg+xml;utf8,${encodeURIComponent(`<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 180'>
    <defs>
      <linearGradient id='bg' x1='0' y1='0' x2='${0.5 + r() * 0.5}' y2='1'>
        <stop offset='0' stop-color='${pal[0]}' stop-opacity='0.95'/>
        <stop offset='0.5' stop-color='${pal[1]}' stop-opacity='0.85'/>
        <stop offset='1' stop-color='${pal[2]}' stop-opacity='0.95'/>
      </linearGradient>
      <radialGradient id='glow'>
        <stop offset='0' stop-color='white' stop-opacity='0.22'/>
        <stop offset='1' stop-color='white' stop-opacity='0'/>
      </radialGradient>
      <filter id='blur'><feGaussianBlur stdDeviation='3'/></filter>
    </defs>
    <rect width='200' height='180' rx='8' fill='url(#bg)'/>
    <g transform='rotate(${rot} 100 90) scale(${scale.toFixed(2)})' transform-origin='100 90'>
      ${patternSvg}
    </g>
    <ellipse cx='100' cy='90' rx='65' ry='50' fill='url(#glow)'/>
    <path d='${sil}' fill='white' opacity='0.18' filter='url(#blur)'/>
    <path d='${sil}' fill='white' opacity='0.28'/>
    <rect x='15' y='148' width='170' height='22' rx='4' fill='black' opacity='0.55'/>
    <text x='100' y='163' font-family='Arial,sans-serif' font-size='10' font-weight='900'
      fill='white' text-anchor='middle' letter-spacing='3' opacity='0.85'>CASE-BATTLE</text>
  </svg>`)}`;
}
