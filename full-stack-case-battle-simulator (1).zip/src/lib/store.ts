import { useSyncExternalStore } from 'react';
import type {
  User, InventoryItem, Quest, PromoCode, DropFeedEntry, Transaction, Skin,
} from './types';
import type { Lang } from './i18n';
import { SKIN_BY_ID, SKINS } from './skinData';

const LS_KEY = 'cbsim_state_v3';

type State = {
  users: Record<string, User>;          // by id
  usernameIndex: Record<string, string>; // username (lower) -> id
  currentUserId: string | null;
  nextNumericId: number;
  promoCodes: PromoCode[];
  transactions: Transaction[];
  dropFeed: DropFeedEntry[];
  lang: Lang;
  bonusBoost14: boolean; // popup hook
};

const AVATARS = [
  '🦊','🐺','🐱','🐯','🦁','🐻','🐼','🐸','🐧','🦅',
  '👻','🤖','👾','🥷','🧙','🧛','🦸','🧑‍🚀','😎','💀',
];

export const AVATAR_LIST = AVATARS;

function makeAdmin(): User {
  const now = Date.now();
  return {
    id: '#00001',
    username: 'Admin123',
    password_hash: hash('414141K'),
    avatar: '🦊',
    balance: 100000,
    role: 'admin',
    created_at: now,
    last_login: now,
    last_bonus_claim: 0,
    last_daily_claim: 0,
    daily_streak: 0,
    last_free_case: 0,
    inventory: [],
    quests: makeFreshQuests(now),
    redeemedCodes: [],
    stats: { casesOpened: 0, battlesWon: 0, upgradesAttempted: 0, upgradesWon: 0, bestDrop: 0 },
  };
}

// Tiny non-cryptographic hash for demo purposes only (NOT real bcrypt — this is frontend-only).
export function hash(s: string): string {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h) + s.charCodeAt(i);
  return 'h_' + (h >>> 0).toString(36) + '_' + s.length;
}

export function makeFreshQuests(now: number): Quest[] {
  const refreshAt = nextMidnightUTC(now);
  return [
    { id: 'q_open5', type: 'open_cases', progress: 0, target: 5,   reward: 200,  claimed: false, refreshAt },
    { id: 'q_winb',  type: 'win_battle', progress: 0, target: 1,   reward: 500,  claimed: false, refreshAt },
    { id: 'q_upg',   type: 'upgrade',    progress: 0, target: 1,   reward: 150,  claimed: false, refreshAt },
    { id: 'q_big',   type: 'big_drop',   progress: 0, target: 1,   reward: 1000, claimed: false, refreshAt },
  ];
}

function nextMidnightUTC(now: number): number {
  const d = new Date(now);
  d.setUTCHours(24, 0, 0, 0);
  return d.getTime();
}

function defaultState(): State {
  const admin = makeAdmin();
  const promo: PromoCode = {
    id: 'pc_welcome',
    code: 'WELCOME500',
    amount: 500,
    max_uses: 9999,
    used_count: 0,
    expires_at: Date.now() + 1000 * 60 * 60 * 24 * 365,
    redeemedBy: [],
  };
  const promo2: PromoCode = {
    id: 'pc_comet',
    code: 'COMET-14',
    amount: 1400,
    max_uses: 100,
    used_count: 0,
    expires_at: Date.now() + 1000 * 60 * 60 * 24 * 30,
    redeemedBy: [],
  };
  return {
    users: { [admin.id]: admin },
    usernameIndex: { admin123: admin.id },
    currentUserId: null,
    nextNumericId: 2,
    promoCodes: [promo, promo2],
    transactions: [],
    dropFeed: seedDropFeed(),
    lang: 'ru',
    bonusBoost14: Math.random() < 0.5,
  };
}

const FAKE_USERNAMES = [
  '午夜星空的隂影','FireFly','Salamandra#peek','kvas sex excort','xD','глоточек пива',
  'how i want to','__zLoY__','mra3ota','я??????','внiз','konewya','★КаПиБаРа★','merkurilunar',
  'D0K70P Livsi','Monсы','w4ck','NoMercy','7 X 7 = 49','БамБолдик','quins3','ФυеномФ',
  'BulletHail','SilentStorm','Phoenix#01','VortexGG','iceberg','Vapor','PixelPanda',
];
const FAKE_AVATARS = ['🦊','🐺','🐱','🐯','🦁','🐻','🐼','🐸','🐧','🦅','👻','🤖','👾','🥷','🧙','🧛','🦸','🧑‍🚀','😎','💀'];

function seedDropFeed(): DropFeedEntry[] {
  const feed: DropFeedEntry[] = [];
  // pick random higher-rarity skins for vibe
  const pool = SKINS.filter(s => ['mythical','legendary','ancient','immortal','rare'].includes(s.rarity));
  for (let i = 0; i < 18; i++) {
    const s = pool[Math.floor(Math.random() * pool.length)];
    feed.push({
      id: 'df_' + i + '_' + Math.random().toString(36).slice(2,6),
      username: FAKE_USERNAMES[Math.floor(Math.random() * FAKE_USERNAMES.length)],
      avatar: FAKE_AVATARS[Math.floor(Math.random() * FAKE_AVATARS.length)],
      skinId: s.id,
      caseName: ['ХОУМЛЕНДЕР','ИМПЕРАТОР','НОЖ МЕЧТЫ','AK-47 ВСЕМ','AWP ВСЕМ','ДРАКОН'][i % 6],
      ts: Date.now() - i * 60_000,
    });
  }
  return feed;
}

// ---- Persistence ----
function load(): State {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw) as State;
    // refresh drop feed if old
    if (!parsed.dropFeed || parsed.dropFeed.length === 0) parsed.dropFeed = seedDropFeed();
    return parsed;
  } catch {
    return defaultState();
  }
}

function save(s: State) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(s)); } catch {}
}

let state: State = load();
const listeners = new Set<() => void>();

function emit() {
  save(state);
  listeners.forEach(l => l());
}

export function subscribe(l: () => void) {
  listeners.add(l);
  return () => { listeners.delete(l); };
}

export function getState(): State { return state; }

export function setState(updater: (s: State) => State) {
  state = updater(state);
  emit();
}

export function useStore<T>(selector: (s: State) => T): T {
  return useSyncExternalStore(subscribe, () => selector(state), () => selector(state));
}

// ---- Helpers ----
export function getCurrentUser(): User | null {
  if (!state.currentUserId) return null;
  return state.users[state.currentUserId] ?? null;
}

export function logTransaction(userId: string, type: Transaction['type'], amount: number, description: string) {
  setState(s => ({
    ...s,
    transactions: [{
      id: 't_' + Math.random().toString(36).slice(2, 10),
      userId, type, amount, description, created_at: Date.now(),
    }, ...s.transactions].slice(0, 500),
  }));
}

// ---- Auth ----
export function registerUser(username: string, password: string, avatar: string): { ok: true; user: User } | { ok: false; error: string } {
  username = username.trim();
  if (username.length < 3) return { ok: false, error: 'Логин слишком короткий' };
  if (password.length < 3) return { ok: false, error: 'Пароль слишком короткий' };
  const key = username.toLowerCase();
  if (state.usernameIndex[key]) return { ok: false, error: 'Логин уже занят' };
  const numericId = state.nextNumericId;
  const id = '#' + String(numericId).padStart(5, '0');
  const now = Date.now();
  const user: User = {
    id, username, avatar,
    password_hash: hash(password),
    balance: 1000,
    role: 'user',
    created_at: now,
    last_login: now,
    last_bonus_claim: 0,
    last_daily_claim: 0,
    daily_streak: 0,
    last_free_case: 0,
    inventory: [],
    quests: makeFreshQuests(now),
    redeemedCodes: [],
    stats: { casesOpened: 0, battlesWon: 0, upgradesAttempted: 0, upgradesWon: 0, bestDrop: 0 },
  };
  setState(s => ({
    ...s,
    users: { ...s.users, [id]: user },
    usernameIndex: { ...s.usernameIndex, [key]: id },
    currentUserId: id,
    nextNumericId: s.nextNumericId + 1,
  }));
  logTransaction(id, 'admin', 1000, 'Welcome bonus');
  return { ok: true, user };
}

export function loginUser(username: string, password: string): { ok: true; user: User } | { ok: false; error: string } {
  const key = username.trim().toLowerCase();
  const id = state.usernameIndex[key];
  if (!id) return { ok: false, error: 'Пользователь не найден' };
  const user = state.users[id];
  if (user.password_hash !== hash(password)) return { ok: false, error: 'Неверный пароль' };
  setState(s => ({
    ...s,
    currentUserId: id,
    users: { ...s.users, [id]: { ...user, last_login: Date.now() } },
  }));
  return { ok: true, user };
}

export function logout() {
  setState(s => ({ ...s, currentUserId: null }));
}

// ---- User mutations ----
export function updateUser(userId: string, patch: Partial<User> | ((u: User) => Partial<User>)) {
  setState(s => {
    const u = s.users[userId];
    if (!u) return s;
    const p = typeof patch === 'function' ? patch(u) : patch;
    return { ...s, users: { ...s.users, [userId]: { ...u, ...p } } };
  });
}

export function addToBalance(userId: string, delta: number, type: Transaction['type'], desc: string) {
  updateUser(userId, u => ({ balance: Math.max(0, Math.round((u.balance + delta) * 100) / 100) }));
  logTransaction(userId, type, delta, desc);
}

export function addItemToInventory(userId: string, skinId: string): InventoryItem {
  const it: InventoryItem = {
    uid: 'inv_' + Math.random().toString(36).slice(2, 10),
    skinId,
    acquired_at: Date.now(),
  };
  updateUser(userId, u => ({ inventory: [it, ...u.inventory] }));
  // best drop stat
  const s = SKIN_BY_ID.get(skinId);
  if (s) {
    updateUser(userId, u => ({ stats: { ...u.stats, bestDrop: Math.max(u.stats.bestDrop, s.price) } }));
  }
  return it;
}

export function removeItemsFromInventory(userId: string, uids: string[]) {
  updateUser(userId, u => ({ inventory: u.inventory.filter(i => !uids.includes(i.uid)) }));
}

export function sellItems(userId: string, uids: string[]): number {
  const u = state.users[userId];
  if (!u) return 0;
  let total = 0;
  const set = new Set(uids);
  for (const it of u.inventory) {
    if (set.has(it.uid)) {
      const s = SKIN_BY_ID.get(it.skinId);
      if (s) total += s.price;
    }
  }
  removeItemsFromInventory(userId, uids);
  addToBalance(userId, total, 'sell', `Sold ${uids.length} item(s)`);
  return total;
}

export function toggleFavorite(userId: string, uid: string) {
  updateUser(userId, u => ({
    inventory: u.inventory.map(i => i.uid === uid ? { ...i, is_favorited: !i.is_favorited } : i),
  }));
}

// ---- Bonuses ----
export const BONUS_INTERVAL = 30 * 60 * 1000;
export const FREE_CASE_INTERVAL = 4 * 60 * 60 * 1000;
export const BONUS_AMOUNT = 50;

export function claimBonus(userId: string): { ok: boolean; amount?: number; nextIn?: number } {
  const u = state.users[userId]; if (!u) return { ok: false };
  const elapsed = Date.now() - u.last_bonus_claim;
  if (elapsed < BONUS_INTERVAL) return { ok: false, nextIn: BONUS_INTERVAL - elapsed };
  let amt = BONUS_AMOUNT;
  if (state.bonusBoost14) amt = Math.round(amt * 1.14);
  addToBalance(userId, amt, 'bonus', '30-min bonus');
  updateUser(userId, { last_bonus_claim: Date.now() });
  // toggle the boost popup chance
  setState(s => ({ ...s, bonusBoost14: Math.random() < 0.45 }));
  return { ok: true, amount: amt };
}

export function claimDaily(userId: string): { ok: boolean; amount?: number; streak?: number; nextIn?: number } {
  const u = state.users[userId]; if (!u) return { ok: false };
  const last = new Date(u.last_daily_claim);
  const now = new Date();
  const sameUTCday = u.last_daily_claim && last.getUTCFullYear() === now.getUTCFullYear()
    && last.getUTCMonth() === now.getUTCMonth() && last.getUTCDate() === now.getUTCDate();
  if (sameUTCday) {
    const next = new Date(now); next.setUTCHours(24, 0, 0, 0);
    return { ok: false, nextIn: next.getTime() - now.getTime() };
  }
  // streak: increment if last claim was yesterday, else reset
  const yesterday = new Date(now); yesterday.setUTCDate(yesterday.getUTCDate() - 1);
  const wasYesterday = u.last_daily_claim &&
    last.getUTCFullYear() === yesterday.getUTCFullYear() &&
    last.getUTCMonth() === yesterday.getUTCMonth() &&
    last.getUTCDate() === yesterday.getUTCDate();
  const newStreak = wasYesterday ? u.daily_streak + 1 : 1;
  let amt = 500;
  if (newStreak === 7) amt += 5000; // weekly bonus
  addToBalance(userId, amt, 'daily', `Daily bonus (streak ${newStreak})`);
  updateUser(userId, { last_daily_claim: Date.now(), daily_streak: newStreak });
  return { ok: true, amount: amt, streak: newStreak };
}

// ---- Promo ----
export function redeemPromo(userId: string, code: string): { ok: boolean; amount?: number; error?: string } {
  const c = state.promoCodes.find(p => p.code.toLowerCase() === code.trim().toLowerCase());
  if (!c) return { ok: false, error: 'Код не найден' };
  if (c.used_count >= c.max_uses) return { ok: false, error: 'Лимит исчерпан' };
  if (c.expires_at < Date.now()) return { ok: false, error: 'Код истёк' };
  if (c.redeemedBy.includes(userId)) return { ok: false, error: 'Уже использован' };
  setState(s => ({
    ...s,
    promoCodes: s.promoCodes.map(p => p.id === c.id ? { ...p, used_count: p.used_count + 1, redeemedBy: [...p.redeemedBy, userId] } : p),
    users: { ...s.users, [userId]: { ...s.users[userId], redeemedCodes: [...s.users[userId].redeemedCodes, c.code] } },
  }));
  addToBalance(userId, c.amount, 'promo', `Promo: ${c.code}`);
  return { ok: true, amount: c.amount };
}

// ---- Quests ----
export function questsRefreshIfNeeded(userId: string) {
  const u = state.users[userId]; if (!u) return;
  const now = Date.now();
  if (u.quests.length === 0 || u.quests[0].refreshAt < now) {
    updateUser(userId, { quests: makeFreshQuests(now) });
  }
}

export function progressQuest(userId: string, type: Quest['type'], amount = 1) {
  updateUser(userId, u => ({
    quests: u.quests.map(q => q.type === type && !q.claimed ? { ...q, progress: Math.min(q.target, q.progress + amount) } : q),
  }));
}

export function claimQuest(userId: string, qid: string): { ok: boolean; amount?: number } {
  const u = state.users[userId]; if (!u) return { ok: false };
  const q = u.quests.find(q => q.id === qid);
  if (!q || q.claimed || q.progress < q.target) return { ok: false };
  updateUser(userId, { quests: u.quests.map(qq => qq.id === qid ? { ...qq, claimed: true } : qq) });
  addToBalance(userId, q.reward, 'admin', `Quest reward: ${q.id}`);
  return { ok: true, amount: q.reward };
}

// ---- Drop feed ----
export function pushDropFeed(entry: Omit<DropFeedEntry, 'id' | 'ts'>) {
  const e: DropFeedEntry = { ...entry, id: 'df_' + Math.random().toString(36).slice(2,8), ts: Date.now() };
  setState(s => ({ ...s, dropFeed: [e, ...s.dropFeed].slice(0, 30) }));
}

// Lucky hour: random per-day per-user hour, here we randomize globally
export function isLuckyHour(): boolean {
  const h = new Date().getUTCHours();
  // pseudo-random hour seeded by date
  const day = Math.floor(Date.now() / (1000*60*60*24));
  const luckyHourOfDay = ((day * 2654435761) >>> 0) % 24;
  return h === luckyHourOfDay;
}

// Online counter (fluctuating)
export function getOnlineCount(): number {
  const day = Math.floor(Date.now() / (1000 * 60));
  const seed = (day * 9301 + 49297) % 233280;
  const base = 9000 + Math.floor((seed / 233280) * 500);
  return base;
}

// ---- Lang ----
export function setLang(lang: Lang) {
  setState(s => ({ ...s, lang }));
}

// ---- Admin: skin override (price) ----
const SKIN_PRICE_OVERRIDES_KEY = 'cbsim_skin_overrides_v1';
let overrides: Record<string, number> = {};
try { overrides = JSON.parse(localStorage.getItem(SKIN_PRICE_OVERRIDES_KEY) || '{}'); } catch {}
export function setSkinPriceOverride(skinId: string, price: number) {
  overrides[skinId] = price;
  localStorage.setItem(SKIN_PRICE_OVERRIDES_KEY, JSON.stringify(overrides));
  const s = SKIN_BY_ID.get(skinId);
  if (s) s.price = price;
  emit();
}
export function applyOverridesOnLoad() {
  for (const [id, p] of Object.entries(overrides)) {
    const s = SKIN_BY_ID.get(id);
    if (s) s.price = p;
  }
}
applyOverridesOnLoad();

// ---- Skin lookup helper ----
export function getSkin(id: string): Skin | undefined { return SKIN_BY_ID.get(id); }
