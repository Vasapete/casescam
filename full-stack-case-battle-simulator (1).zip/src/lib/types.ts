export type Rarity = 'common' | 'uncommon' | 'rare' | 'mythical' | 'legendary' | 'ancient' | 'immortal';

export type Skin = {
  id: string;
  name: string;           // weapon (e.g. "AK-47")
  skin_name: string;      // skin (e.g. "Redline")
  market_hash_name: string;
  image_url: string;
  price: number;          // in CB ₽
  rarity: Rarity;
  weapon_type: string;
  stattrak?: boolean;
};

export type CaseCategory = 'serial' | 'brand' | 'event' | 'premium' | 'free';

export type CaseItem = {
  skinId: string;
  weight: number; // 0..1 weight
};

export type CaseDef = {
  id: string;
  name: string;
  image: string; // emoji/gradient seed
  price: number;
  category: CaseCategory;
  is_new?: boolean;
  is_promo?: boolean;
  items: CaseItem[];
  accent: string; // gradient
};

export type InventoryItem = {
  uid: string;       // unique inventory id
  skinId: string;
  acquired_at: number;
  is_favorited?: boolean;
};

export type User = {
  id: string;            // #00001
  username: string;
  password_hash: string; // demo: plain hash placeholder
  avatar: string;
  balance: number;
  role: 'user' | 'admin';
  created_at: number;
  last_login: number;
  last_bonus_claim: number;     // 30-min claim
  last_daily_claim: number;     // daily 500
  daily_streak: number;
  last_free_case: number;       // 4h free case
  inventory: InventoryItem[];
  quests: Quest[];
  redeemedCodes: string[];
  stats: {
    casesOpened: number;
    battlesWon: number;
    upgradesAttempted: number;
    upgradesWon: number;
    bestDrop: number;
  };
};

export type Quest = {
  id: string;
  type: 'open_cases' | 'win_battle' | 'upgrade' | 'big_drop';
  progress: number;
  target: number;
  reward: number;
  claimed: boolean;
  refreshAt: number;
};

export type Transaction = {
  id: string;
  userId: string;
  type: 'bonus' | 'daily' | 'promo' | 'open' | 'sell' | 'upgrade' | 'battle' | 'admin' | 'contract';
  amount: number;
  description: string;
  created_at: number;
};

export type PromoCode = {
  id: string;
  code: string;
  amount: number;
  max_uses: number;
  used_count: number;
  expires_at: number;
  redeemedBy: string[];
};

export type DropFeedEntry = {
  id: string;
  username: string;
  avatar: string;
  skinId: string;
  caseName: string;
  ts: number;
};

export type Battle = {
  id: string;
  mode: '1v1' | '1v1v1' | '2v2' | 'ffa4';
  cases: string[]; // caseId array (with multiplicity)
  crazy: boolean;
  status: 'lobby' | 'rolling' | 'finished';
  players: BattlePlayer[];
  created_by: string;
  created_at: number;
  winnerIds?: string[];
};

export type BattlePlayer = {
  userId: string;     // or bot id
  username: string;
  avatar: string;
  team: number;
  isBot: boolean;
  rolls: { skinId: string; value: number }[];
  total: number;
};
