// Curated CS2 skin database with realistic RUB pricing and correct rarities.
// Icons resolved at runtime from CSGO-API (bymykel) with SVG fallback.

import type { Skin, Rarity } from './types';

type SkinSeed = {
  weapon: string;
  skin: string;
  price: number;        // ₽ approx
  rarity: Rarity;
  type: string;         // weapon category
  st?: boolean;         // stattrak
};

const SEEDS: SkinSeed[] = [
  // ===== Immortal (gold) — Knives & Gloves =====
  { weapon: '★ Karambit', skin: 'Doppler', price: 95000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Karambit', skin: 'Fade', price: 120000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Karambit', skin: 'Marble Fade', price: 78000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Karambit', skin: 'Tiger Tooth', price: 68000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ M9 Bayonet', skin: 'Tiger Tooth', price: 65000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ M9 Bayonet', skin: 'Doppler', price: 72000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Butterfly Knife', skin: 'Marble Fade', price: 88000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Butterfly Knife', skin: 'Fade', price: 96000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Bayonet', skin: 'Crimson Web', price: 35000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Bayonet', skin: 'Slaughter', price: 22000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Flip Knife', skin: 'Slaughter', price: 22000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Flip Knife', skin: 'Doppler', price: 28000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Huntsman Knife', skin: 'Lore', price: 18500, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Huntsman Knife', skin: 'Fade', price: 24000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Falchion Knife', skin: 'Autotronic', price: 12000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Stiletto Knife', skin: 'Night Stripe', price: 9800, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Stiletto Knife', skin: 'Marble Fade', price: 32000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Talon Knife', skin: 'Damascus Steel', price: 14500, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Talon Knife', skin: 'Crimson Web', price: 38000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Navaja Knife', skin: 'Forest DDPAT', price: 7200, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Shadow Daggers', skin: 'Slaughter', price: 6300, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Classic Knife', skin: 'Black Laminate', price: 8900, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Skeleton Knife', skin: 'Boreal Forest', price: 9100, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Skeleton Knife', skin: 'Crimson Web', price: 42000, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Paracord Knife', skin: 'Forest DDPAT', price: 4800, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Ursus Knife', skin: 'Vanilla', price: 7600, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Nomad Knife', skin: 'Crimson Web', price: 11200, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Survival Knife', skin: 'Blue Steel', price: 5400, rarity: 'immortal', type: 'Knife' },
  { weapon: '★ Kukri Knife', skin: 'Damascus Steel', price: 6800, rarity: 'immortal', type: 'Knife' },

  { weapon: '★ Sport Gloves', skin: 'Pandora\'s Box', price: 89000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Sport Gloves', skin: 'Vice', price: 76000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Sport Gloves', skin: 'Hedge Maze', price: 38000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Specialist Gloves', skin: 'Crimson Kimono', price: 64000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Driver Gloves', skin: 'King Snake', price: 42000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Driver Gloves', skin: 'Imperial Plaid', price: 38000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Moto Gloves', skin: 'Spearmint', price: 28000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Moto Gloves', skin: 'Cool Mint', price: 32000, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Hand Wraps', skin: 'Cobalt Skulls', price: 19500, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Hand Wraps', skin: 'Slaughter', price: 14500, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Hydra Gloves', skin: 'Case Hardened', price: 8200, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Bloodhound Gloves', skin: 'Charred', price: 6900, rarity: 'immortal', type: 'Gloves' },
  { weapon: '★ Broken Fang Gloves', skin: 'Jade', price: 11500, rarity: 'immortal', type: 'Gloves' },

  // ===== Ancient (red / Covert) — the "red drops" =====
  { weapon: 'AWP', skin: 'Dragon Lore', price: 380000, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Gungnir', price: 290000, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Medusa', price: 145000, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'The Prince', price: 95000, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Lightning Strike', price: 18500, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Asiimov', price: 6800, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Hyper Beast', price: 5400, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Wildfire', price: 7900, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Containment Breach', price: 6200, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Neo-Noir', price: 4800, rarity: 'ancient', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Fade', price: 14500, rarity: 'ancient', type: 'Sniper' },

  { weapon: 'AK-47', skin: 'Wild Lotus', price: 195000, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Fire Serpent', price: 85000, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Vulcan', price: 9400, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Asiimov', price: 6800, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Bloodsport', price: 7150, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'The Empress', price: 5600, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Neon Rider', price: 4980, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Head Shot', price: 4200, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Inheritance', price: 5850, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Nightwish', price: 4400, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Gold Arabesque', price: 65000, rarity: 'ancient', type: 'Rifle' },

  { weapon: 'M4A4', skin: 'Howl', price: 280000, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Poseidon', price: 36000, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'The Emperor', price: 4320, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Asiimov', price: 3180, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Neo-Noir', price: 3450, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Hellfire', price: 2950, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Royal Paladin', price: 4600, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Daybreak', price: 5800, rarity: 'ancient', type: 'Rifle' },

  { weapon: 'M4A1-S', skin: 'Welcome to the Jungle', price: 22000, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Knight', price: 26000, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Hyper Beast', price: 3700, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Player Two', price: 4400, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Printstream', price: 5800, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Blue Phosphor', price: 6100, rarity: 'ancient', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Imminent Danger', price: 3950, rarity: 'ancient', type: 'Rifle' },

  { weapon: 'Desert Eagle', skin: 'Blaze', price: 4450, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Hand Cannon', price: 4800, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Printstream', price: 5880, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Code Red', price: 3980, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Emerald Jörmungandr', price: 6800, rarity: 'ancient', type: 'Pistol' },

  { weapon: 'USP-S', skin: 'Printstream', price: 5400, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Kill Confirmed', price: 4380, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Whiteout', price: 3200, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'The Traitor', price: 3850, rarity: 'ancient', type: 'Pistol' },

  { weapon: 'Glock-18', skin: 'Fade', price: 3200, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Bullet Queen', price: 3540, rarity: 'ancient', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Neo-Noir', price: 2680, rarity: 'ancient', type: 'Pistol' },

  { weapon: 'Dual Berettas', skin: 'Cobra Strike', price: 4620, rarity: 'ancient', type: 'Pistol' },

  // ===== Legendary (pink / Classified) =====
  { weapon: 'AK-47', skin: 'Redline', price: 720, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Frontside Misty', price: 880, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Point Disarray', price: 1050, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Aquamarine Revenge', price: 1380, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Phantom Disruptor', price: 690, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Leet Museo', price: 920, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Asiimov', price: 1180, rarity: 'legendary', type: 'Rifle' }, // alt FT
  { weapon: 'M4A4', skin: 'Desolate Space', price: 740, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Buzz Kill', price: 980, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Tooth Fairy', price: 575, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'In Living Color', price: 850, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Decimator', price: 620, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Mecha Industries', price: 910, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Nightmare', price: 765, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Chantico\'s Fire', price: 1340, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Master Piece', price: 1480, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AWP', skin: 'Fever Dream', price: 1280, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Chromatic Aberration', price: 990, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Redline', price: 1510, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Mortis', price: 845, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Atheris', price: 580, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'AWP', skin: 'PAW', price: 920, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'Desert Eagle', skin: 'Kumicho Dragon', price: 685, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Mecha Industries', price: 530, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Ocean Drive', price: 495, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Orion', price: 1010, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Cortex', price: 465, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Neo-Noir', price: 620, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Water Elemental', price: 580, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Wasteland Rebel', price: 745, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Twilight Galaxy', price: 488, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'P250', skin: 'See Ya Later', price: 580, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'P250', skin: 'Asiimov', price: 410, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Hyper Beast', price: 395, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Case Hardened', price: 720, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'CZ75-Auto', skin: 'Xiangliu', price: 575, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'CZ75-Auto', skin: 'Emerald Quartz', price: 690, rarity: 'legendary', type: 'Pistol' },
  { weapon: 'SSG 08', skin: 'Dragonfire', price: 765, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'SSG 08', skin: 'Big Iron', price: 478, rarity: 'legendary', type: 'Sniper' },
  { weapon: 'SG 553', skin: 'Cyrex', price: 392, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'SG 553', skin: 'Integrale', price: 510, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AUG', skin: 'Akihabara Accept', price: 8200, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'AUG', skin: 'Wings', price: 690, rarity: 'legendary', type: 'Rifle' },
  { weapon: 'P90', skin: 'Asiimov', price: 488, rarity: 'legendary', type: 'SMG' },
  { weapon: 'P90', skin: 'Death by Kitty', price: 845, rarity: 'legendary', type: 'SMG' },
  { weapon: 'P90', skin: 'Trigon', price: 462, rarity: 'legendary', type: 'SMG' },
  { weapon: 'MP9', skin: 'Hot Rod', price: 895, rarity: 'legendary', type: 'SMG' },
  { weapon: 'UMP-45', skin: 'Primal Saber', price: 588, rarity: 'legendary', type: 'SMG' },
  { weapon: 'MAC-10', skin: 'Neon Rider', price: 745, rarity: 'legendary', type: 'SMG' },
  { weapon: 'Nova', skin: 'Hyper Beast', price: 475, rarity: 'legendary', type: 'Shotgun' },
  { weapon: 'XM1014', skin: 'Tranquility', price: 1010, rarity: 'legendary', type: 'Shotgun' },
  { weapon: 'XM1014', skin: 'Frost Borre', price: 492, rarity: 'legendary', type: 'Shotgun' },

  // ===== Mythical (purple / Restricted) =====
  { weapon: 'AK-47', skin: 'Jaguar', price: 215, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Cartel', price: 245, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'First Class Ticket', price: 198, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Evil Daimyo', price: 165, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Bullet Rain', price: 235, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Magnesium', price: 145, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Modern Hunter', price: 295, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Briefing', price: 178, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Atomic Alloy', price: 245, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Basilisk', price: 192, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'AWP', skin: 'Worm God', price: 158, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Pit Viper', price: 192, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'AWP', skin: 'POP AWP', price: 285, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Acheron', price: 168, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Phobos', price: 248, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'Desert Eagle', skin: 'Conspiracy', price: 178, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Bronze Deco', price: 122, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Light Rail', price: 138, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Caiman', price: 135, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Overgrowth', price: 168, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Steel Disruption', price: 128, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Off World', price: 145, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Brass', price: 165, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'P250', skin: 'Mehndi', price: 125, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'P250', skin: 'Visions', price: 145, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'P250', skin: 'Whiteout', price: 175, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Monkey Business', price: 122, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Fairy Tale', price: 165, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Tec-9', skin: 'Fuel Injector', price: 245, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'Tec-9', skin: 'Decimator', price: 188, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'CZ75-Auto', skin: 'Victoria', price: 145, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'CZ75-Auto', skin: 'Yellow Jacket', price: 165, rarity: 'mythical', type: 'Pistol' },
  { weapon: 'FAMAS', skin: 'Roll Cage', price: 138, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'FAMAS', skin: 'Afterimage', price: 215, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'FAMAS', skin: 'Mecha Industries', price: 145, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'Galil AR', skin: 'Cerberus', price: 178, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'Galil AR', skin: 'Eco', price: 122, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'AUG', skin: 'Chameleon', price: 235, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'AUG', skin: 'Bengal Tiger', price: 158, rarity: 'mythical', type: 'Rifle' },
  { weapon: 'SSG 08', skin: 'Blood in the Water', price: 295, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'SCAR-20', skin: 'Cardiac', price: 168, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'G3SG1', skin: 'Murky', price: 125, rarity: 'mythical', type: 'Sniper' },
  { weapon: 'P90', skin: 'Emerald Dragon', price: 285, rarity: 'mythical', type: 'SMG' },
  { weapon: 'MP9', skin: 'Rose Iron', price: 145, rarity: 'mythical', type: 'SMG' },
  { weapon: 'MP7', skin: 'Nemesis', price: 165, rarity: 'mythical', type: 'SMG' },
  { weapon: 'MAC-10', skin: 'Heat', price: 178, rarity: 'mythical', type: 'SMG' },
  { weapon: 'UMP-45', skin: 'Blaze', price: 295, rarity: 'mythical', type: 'SMG' },
  { weapon: 'PP-Bizon', skin: 'High Roller', price: 238, rarity: 'mythical', type: 'SMG' },
  { weapon: 'Nova', skin: 'Antique', price: 145, rarity: 'mythical', type: 'Shotgun' },
  { weapon: 'XM1014', skin: 'Heaven Guard', price: 168, rarity: 'mythical', type: 'Shotgun' },
  { weapon: 'MAG-7', skin: 'Bulldozer', price: 132, rarity: 'mythical', type: 'Shotgun' },
  { weapon: 'Sawed-Off', skin: 'The Kraken', price: 545, rarity: 'mythical', type: 'Shotgun' },

  // ===== Rare (blue / Mil-Spec) =====
  { weapon: 'AK-47', skin: 'Slate', price: 45, rarity: 'rare', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Blue Laminate', price: 38, rarity: 'rare', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Elite Build', price: 22, rarity: 'rare', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Uncharted', price: 32, rarity: 'rare', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Faded Zebra', price: 18, rarity: 'rare', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Converter', price: 32, rarity: 'rare', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Boreal Forest', price: 16, rarity: 'rare', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'VariCamo', price: 19, rarity: 'rare', type: 'Rifle' },
  { weapon: 'AWP', skin: 'Capillary', price: 28, rarity: 'rare', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Pink DDPAT', price: 32, rarity: 'rare', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Corticera', price: 38, rarity: 'rare', type: 'Sniper' },
  { weapon: 'Desert Eagle', skin: 'Mudder', price: 14, rarity: 'rare', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Night Heist', price: 38, rarity: 'rare', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Forest Leaves', price: 12, rarity: 'rare', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Stainless', price: 18, rarity: 'rare', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Blueprint', price: 32, rarity: 'rare', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Sand Dune', price: 11, rarity: 'rare', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Grinder', price: 22, rarity: 'rare', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Snack Attack', price: 42, rarity: 'rare', type: 'Pistol' },
  { weapon: 'P250', skin: 'Splash', price: 18, rarity: 'rare', type: 'Pistol' },
  { weapon: 'P250', skin: 'Hive', price: 28, rarity: 'rare', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Forest Night', price: 14, rarity: 'rare', type: 'Pistol' },
  { weapon: 'P2000', skin: 'Imperial', price: 22, rarity: 'rare', type: 'Pistol' },
  { weapon: 'P2000', skin: 'Pulse', price: 28, rarity: 'rare', type: 'Pistol' },
  { weapon: 'FAMAS', skin: 'Colony', price: 16, rarity: 'rare', type: 'Rifle' },
  { weapon: 'FAMAS', skin: 'Survivor Z', price: 32, rarity: 'rare', type: 'Rifle' },
  { weapon: 'Galil AR', skin: 'Sage Spray', price: 18, rarity: 'rare', type: 'Rifle' },
  { weapon: 'SG 553', skin: 'Pulse', price: 22, rarity: 'rare', type: 'Rifle' },
  { weapon: 'AUG', skin: 'Death by Puppy', price: 45, rarity: 'rare', type: 'Rifle' },
  { weapon: 'SSG 08', skin: 'Detour', price: 28, rarity: 'rare', type: 'Sniper' },
  { weapon: 'G3SG1', skin: 'Polar Camo', price: 18, rarity: 'rare', type: 'Sniper' },
  { weapon: 'SCAR-20', skin: 'Sand Mesh', price: 14, rarity: 'rare', type: 'Sniper' },
  { weapon: 'P90', skin: 'Sand Spray', price: 12, rarity: 'rare', type: 'SMG' },
  { weapon: 'P90', skin: 'Burning Flame', price: 38, rarity: 'rare', type: 'SMG' },
  { weapon: 'MP9', skin: 'Sand Dashed', price: 16, rarity: 'rare', type: 'SMG' },
  { weapon: 'MP7', skin: 'Powercore', price: 22, rarity: 'rare', type: 'SMG' },
  { weapon: 'MAC-10', skin: 'Indigo', price: 18, rarity: 'rare', type: 'SMG' },
  { weapon: 'UMP-45', skin: 'Mudder', price: 14, rarity: 'rare', type: 'SMG' },
  { weapon: 'PP-Bizon', skin: 'Osiris', price: 28, rarity: 'rare', type: 'SMG' },
  { weapon: 'Nova', skin: 'Forest Leaves', price: 16, rarity: 'rare', type: 'Shotgun' },
  { weapon: 'XM1014', skin: 'Blue Steel', price: 22, rarity: 'rare', type: 'Shotgun' },
  { weapon: 'MAG-7', skin: 'Sand Dune', price: 12, rarity: 'rare', type: 'Shotgun' },
  { weapon: 'M249', skin: 'Nebula Crusader', price: 22, rarity: 'rare', type: 'Heavy' },
  { weapon: 'Negev', skin: 'Loudmouth', price: 18, rarity: 'rare', type: 'Heavy' },

  // ===== Uncommon (lt blue / Industrial) =====
  { weapon: 'AK-47', skin: 'Safari Mesh', price: 6, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'AK-47', skin: 'Predator', price: 9, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'M4A4', skin: 'Mainframe', price: 7, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'M4A1-S', skin: 'Flashback', price: 8, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'AWP', skin: 'Snake Camo', price: 8, rarity: 'uncommon', type: 'Sniper' },
  { weapon: 'AWP', skin: 'Worm God', price: 9, rarity: 'uncommon', type: 'Sniper' },
  { weapon: 'Desert Eagle', skin: 'The Bronze', price: 5, rarity: 'uncommon', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Para Green', price: 5, rarity: 'uncommon', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Catacombs', price: 4, rarity: 'uncommon', type: 'Pistol' },
  { weapon: 'P250', skin: 'Iron Clad', price: 7, rarity: 'uncommon', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Coolant', price: 5, rarity: 'uncommon', type: 'Pistol' },
  { weapon: 'P2000', skin: 'Granite Marbleized', price: 5, rarity: 'uncommon', type: 'Pistol' },
  { weapon: 'FAMAS', skin: 'Doomkitty', price: 6, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'Galil AR', skin: 'Hunting Blind', price: 5, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'AUG', skin: 'Storm', price: 4, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'SG 553', skin: 'Damascus Steel', price: 8, rarity: 'uncommon', type: 'Rifle' },
  { weapon: 'SSG 08', skin: 'Slashed', price: 7, rarity: 'uncommon', type: 'Sniper' },
  { weapon: 'P90', skin: 'Glacier Mesh', price: 4, rarity: 'uncommon', type: 'SMG' },
  { weapon: 'MP9', skin: 'Setting Sun', price: 5, rarity: 'uncommon', type: 'SMG' },
  { weapon: 'MAC-10', skin: 'Curse', price: 6, rarity: 'uncommon', type: 'SMG' },
  { weapon: 'UMP-45', skin: 'Briefing', price: 4, rarity: 'uncommon', type: 'SMG' },
  { weapon: 'PP-Bizon', skin: 'Brass', price: 7, rarity: 'uncommon', type: 'SMG' },
  { weapon: 'Nova', skin: 'Walnut', price: 6, rarity: 'uncommon', type: 'Shotgun' },
  { weapon: 'XM1014', skin: 'Heaven Guard', price: 8, rarity: 'uncommon', type: 'Shotgun' },
  { weapon: 'MAG-7', skin: 'Heaven Guard', price: 5, rarity: 'uncommon', type: 'Shotgun' },
  { weapon: 'M249', skin: 'Contrast Spray', price: 5, rarity: 'uncommon', type: 'Heavy' },
  { weapon: 'Negev', skin: 'Army Sphinx', price: 4, rarity: 'uncommon', type: 'Heavy' },

  // ===== Common (grey / Consumer) =====
  { weapon: 'P250', skin: 'Sand Dune', price: 1.2, rarity: 'common', type: 'Pistol' },
  { weapon: 'Glock-18', skin: 'Night', price: 0.9, rarity: 'common', type: 'Pistol' },
  { weapon: 'USP-S', skin: 'Night Ops', price: 1.5, rarity: 'common', type: 'Pistol' },
  { weapon: 'Five-SeveN', skin: 'Anodized Gunmetal', price: 0.9, rarity: 'common', type: 'Pistol' },
  { weapon: 'Desert Eagle', skin: 'Urban DDPAT', price: 1.8, rarity: 'common', type: 'Pistol' },
  { weapon: 'P2000', skin: 'Silver', price: 1.1, rarity: 'common', type: 'Pistol' },
  { weapon: 'CZ75-Auto', skin: 'Crimson Web', price: 2.4, rarity: 'common', type: 'Pistol' },
  { weapon: 'Nova', skin: 'Sand Dune', price: 0.7, rarity: 'common', type: 'Shotgun' },
  { weapon: 'MAG-7', skin: 'Counter Terrace', price: 0.9, rarity: 'common', type: 'Shotgun' },
  { weapon: 'P90', skin: 'Storm', price: 1.3, rarity: 'common', type: 'SMG' },
  { weapon: 'MP9', skin: 'Storm', price: 0.8, rarity: 'common', type: 'SMG' },
  { weapon: 'MAC-10', skin: 'Urban DDPAT', price: 1.4, rarity: 'common', type: 'SMG' },
  { weapon: 'AK-47', skin: 'Steel Delta', price: 2.2, rarity: 'common', type: 'Rifle' },
  { weapon: 'AWP', skin: 'Safari Mesh', price: 2.1, rarity: 'common', type: 'Sniper' },
  { weapon: 'FAMAS', skin: 'Cyanospatter', price: 1.5, rarity: 'common', type: 'Rifle' },
  { weapon: 'Galil AR', skin: 'Tornado', price: 1.2, rarity: 'common', type: 'Rifle' },
];

// Build skin entries with stable IDs
export const SKINS: Skin[] = SEEDS.map((s, i) => {
  const id = `skin_${i.toString().padStart(4, '0')}`;
  const market_hash_name = `${s.weapon} | ${s.skin}`;
  return {
    id,
    name: s.weapon,
    skin_name: s.skin,
    market_hash_name,
    image_url: '', // resolved at runtime
    price: s.price,
    rarity: s.rarity,
    weapon_type: s.type,
    stattrak: !!s.st,
  };
});

export const SKIN_BY_ID = new Map(SKINS.map(s => [s.id, s]));

// Group by rarity for case generation
export const SKINS_BY_RARITY: Record<Rarity, Skin[]> = {
  common: SKINS.filter(s => s.rarity === 'common'),
  uncommon: SKINS.filter(s => s.rarity === 'uncommon'),
  rare: SKINS.filter(s => s.rarity === 'rare'),
  mythical: SKINS.filter(s => s.rarity === 'mythical'),
  legendary: SKINS.filter(s => s.rarity === 'legendary'),
  ancient: SKINS.filter(s => s.rarity === 'ancient'),
  immortal: SKINS.filter(s => s.rarity === 'immortal'),
};

export const RARITY_COLORS: Record<Rarity, { hex: string; glow: string; label: string; ru: string }> = {
  common:     { hex: '#b0c3d9', glow: 'shadow-[0_0_12px_rgba(176,195,217,0.5)]', label: 'Consumer',  ru: 'Ширпотреб' },
  uncommon:   { hex: '#5e98d9', glow: 'shadow-[0_0_12px_rgba(94,152,217,0.6)]',  label: 'Industrial',ru: 'Промышленное' },
  rare:       { hex: '#4b69ff', glow: 'shadow-[0_0_14px_rgba(75,105,255,0.7)]',  label: 'Mil-Spec',  ru: 'Армейское' },
  mythical:   { hex: '#8847ff', glow: 'shadow-[0_0_16px_rgba(136,71,255,0.8)]',  label: 'Restricted',ru: 'Запрещённое' },
  legendary:  { hex: '#d32ce6', glow: 'shadow-[0_0_18px_rgba(211,44,230,0.85)]', label: 'Classified',ru: 'Засекреченное' },
  ancient:    { hex: '#eb4b4b', glow: 'shadow-[0_0_22px_rgba(235,75,75,0.9)]',   label: 'Covert',    ru: 'Тайное' },
  immortal:   { hex: '#e4ae39', glow: 'shadow-[0_0_26px_rgba(228,174,57,1)]',    label: 'Exceedingly Rare', ru: 'Исключительно редкое' },
};

// ----------- Icon resolution (CSGO-API by bymykel) -----------
let ICON_MAP: Map<string, string> | null = null;
let ICON_NORM: Map<string, string> | null = null;
let ICON_PROMISE: Promise<Map<string, string>> | null = null;
let ICON_VERSION = 0;
const iconListeners = new Set<() => void>();

export function subscribeIcons(fn: () => void): () => void {
  iconListeners.add(fn);
  return () => { iconListeners.delete(fn); };
}
export function getIconVersion(): number { return ICON_VERSION; }
export function iconsReady(): boolean { return !!ICON_MAP; }

function normalize(s: string): string {
  return s
    .toLowerCase()
    .replace(/★/g, '')
    .replace(/™/g, '')
    .replace(/stattrak/g, '')
    .replace(/souvenir/g, '')
    .replace(/\s*\([^)]*\)\s*$/, '')
    .replace(/[^a-z0-9|]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

export async function loadIconMap(): Promise<Map<string, string>> {
  if (ICON_MAP) return ICON_MAP;
  if (ICON_PROMISE) return ICON_PROMISE;
  ICON_PROMISE = (async () => {
    const URLS = [
      'https://bymykel.github.io/CSGO-API/api/en/skins.json',
      'https://raw.githubusercontent.com/ByMykel/CSGO-API/main/public/api/en/skins.json',
    ];
    let data: any = null;
    for (const url of URLS) {
      try {
        const res = await fetch(url);
        if (!res.ok) continue;
        data = await res.json();
        if (Array.isArray(data) && data.length > 0) break;
      } catch { /* try next */ }
    }
    const map = new Map<string, string>();
    const norm = new Map<string, string>();
    if (Array.isArray(data)) {
      for (const item of data) {
        const name: string | undefined = item?.name;
        const image: string | undefined = item?.image;
        if (!name || !image) continue;
        map.set(name, image);
        const n = normalize(name);
        if (n && !norm.has(n)) norm.set(n, image);
      }
    }
    ICON_MAP = map;
    ICON_NORM = norm;
    ICON_VERSION += 1;
    iconListeners.forEach(l => { try { l(); } catch {} });
    return map;
  })();
  return ICON_PROMISE;
}

export function resolveSkinIcon(skin: Skin): string {
  if (!ICON_MAP) return fallbackIcon(skin);
  const direct = ICON_MAP.get(skin.market_hash_name);
  if (direct) return direct;
  const direct2 = ICON_MAP.get(`${skin.name} | ${skin.skin_name}`);
  if (direct2) return direct2;
  if (ICON_NORM) {
    const n = normalize(skin.market_hash_name);
    const hit = ICON_NORM.get(n);
    if (hit) return hit;
    const n2 = normalize(skin.name);
    const hit2 = ICON_NORM.get(n2);
    if (hit2) return hit2;
  }
  return fallbackIcon(skin);
}

export function fallbackIcon(skin: Skin): string {
  const color = RARITY_COLORS[skin.rarity].hex;
  const initial = skin.name.charAt(skin.name.startsWith('★') ? 2 : 0);
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 150'>
    <defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>
      <stop offset='0' stop-color='${color}' stop-opacity='0.35'/>
      <stop offset='1' stop-color='${color}' stop-opacity='0.05'/>
    </linearGradient></defs>
    <rect width='200' height='150' fill='url(#g)'/>
    <text x='100' y='90' font-family='Arial' font-size='64' font-weight='900'
      fill='${color}' text-anchor='middle' opacity='0.7'>${initial}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
