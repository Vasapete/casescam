import { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useT } from '../lib/useT';
import { getCases, rollFromCase } from '../lib/cases';
import { addItemToInventory, addToBalance, getSkin, progressQuest, pushDropFeed, updateUser, useStore } from '../lib/store';
import type { Battle, BattlePlayer, CaseDef } from '../lib/types';
import { SkinIcon } from '../components/SkinIcon';
import { RARITY_COLORS } from '../lib/skinData';
import { clickSound, dropSound, errorSound, successSound, tickSound } from '../lib/sound';

const MODES: { id: Battle['mode']; label: string; slots: number; teams: number[] }[] = [
  { id: '1v1',   label: '1 vs 1',      slots: 2, teams: [0,1] },
  { id: '1v1v1', label: '1 vs 1 vs 1', slots: 3, teams: [0,1,2] },
  { id: '2v2',   label: '2 vs 2',      slots: 4, teams: [0,0,1,1] },
  { id: 'ffa4',  label: '4 FFA',       slots: 4, teams: [0,1,2,3] },
];

const BOT_NAMES = ['BotKira','BotZver','BotRex','BotLuna','BotShadow','BotZ3ro','BotKappa'];
const BOT_AV = ['🤖','👾','🐺','🦊','🦁','🐯'];

export function BattlesPage({ onLogin }: { onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const allCases = useMemo(() => getCases().filter(c => c.price > 0 && c.price <= 5000).sort((a,b) => a.price - b.price), []);
  const [mode, setMode] = useState<Battle['mode']>('2v2');
  const [pickedCases, setPickedCases] = useState<string[]>([]);
  const [crazy, setCrazy] = useState(false);
  const [bots, setBots] = useState(true);
  const [fast, setFast] = useState(false);
  const [active, setActive] = useState<Battle | null>(null);
  const [currentRound, setCurrentRound] = useState(0);
  const [winnerIds, setWinnerIds] = useState<string[] | null>(null);
  const [rolling, setRolling] = useState(false);
  const [search, setSearch] = useState('');

  if (!user) {
    return (
      <div className="px-6 py-16 text-center">
        <div className="text-5xl mb-4">⚔️</div>
        <div className="text-white/60 mb-4">{t('auth_required')}</div>
        <button onClick={onLogin} className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">{t('login')}</button>
      </div>
    );
  }

  const cost = pickedCases.reduce((a, cid) => a + (allCases.find(c => c.id === cid)?.price ?? 0), 0);
  const filtered = allCases.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()));

  function addCase(cid: string) {
    setPickedCases(arr => arr.length >= 20 ? arr : [...arr, cid]);
  }
  function removeAt(idx: number) {
    setPickedCases(arr => arr.filter((_, i) => i !== idx));
  }
  function clearAll() { setPickedCases([]); }

  function startBattle() {
    if (pickedCases.length === 0) { errorSound(); return; }
    if (user!.balance < cost) { errorSound(); return; }
    const m = MODES.find(m => m.id === mode)!;
    addToBalance(user!.id, -cost, 'battle', `Battle ${mode}`);

    const players: BattlePlayer[] = [];
    players.push({ userId: user!.id, username: user!.username, avatar: user!.avatar, team: m.teams[0], isBot: false, rolls: [], total: 0 });
    if (bots) {
      for (let i = 1; i < m.slots; i++) {
        players.push({
          userId: 'bot_' + i + '_' + Math.random().toString(36).slice(2,6),
          username: BOT_NAMES[(i*3) % BOT_NAMES.length] + '#' + (100 + i),
          avatar: BOT_AV[i % BOT_AV.length],
          team: m.teams[i], isBot: true, rolls: [], total: 0,
        });
      }
    }
    const b: Battle = {
      id: 'b_' + Math.random().toString(36).slice(2,8),
      mode, crazy, cases: pickedCases, status: 'rolling', players,
      created_by: user!.id, created_at: Date.now(),
    };
    setActive(b);
    setWinnerIds(null);
    setCurrentRound(0);
    setRolling(true);
    runRolls(b);
  }

  function runRolls(b: Battle) {
    const caseDefs = b.cases.map(cid => allCases.find(c => c.id === cid)!).filter(Boolean);
    let idx = 0;
    let currentBattle = b;
    const stride = fast ? 250 : 1100;

    const doRound = () => {
      if (idx >= caseDefs.length) {
        // finalize: group by team and sum
        const grouped = new Map<number, BattlePlayer[]>();
        currentBattle.players.forEach(p => {
          const arr = grouped.get(p.team) ?? [];
          arr.push(p); grouped.set(p.team, arr);
        });
        const teamTotals: { team: number; total: number }[] = [];
        grouped.forEach((arr, team) => {
          teamTotals.push({ team, total: arr.reduce((a, p) => a + p.total, 0) });
        });
        teamTotals.sort((a, b2) => currentBattle.crazy ? a.total - b2.total : b2.total - a.total);
        const winningTeam = teamTotals[0].team;
        const winners = currentBattle.players.filter(p => p.team === winningTeam);
        setWinnerIds(winners.map(p => p.userId));

        const userWon = winners.some(w => w.userId === user!.id);
        if (userWon) {
          for (const p of currentBattle.players) {
            for (const r of p.rolls) {
              addItemToInventory(user!.id, r.skinId);
              if (r.value >= 1000) progressQuest(user!.id, 'big_drop', 1);
              pushDropFeed({ username: user!.username, avatar: user!.avatar, skinId: r.skinId, caseName: 'Battle ' + currentBattle.mode });
            }
          }
          updateUser(user!.id, u => ({
            stats: { ...u.stats, battlesWon: u.stats.battlesWon + 1, casesOpened: u.stats.casesOpened + currentBattle.cases.length }
          }));
          progressQuest(user!.id, 'win_battle', 1);
          successSound();
        } else {
          updateUser(user!.id, u => ({
            stats: { ...u.stats, casesOpened: u.stats.casesOpened + currentBattle.cases.length }
          }));
        }
        setRolling(false);
        return;
      }
      const cdef = caseDefs[idx];
      tickSound();
      const updatedPlayers = currentBattle.players.map(p => {
        const skinId = rollFromCase(cdef);
        const skin = getSkin(skinId)!;
        return {
          ...p,
          rolls: [...p.rolls, { skinId, value: skin.price }],
          total: p.total + skin.price,
        };
      });
      currentBattle = { ...currentBattle, players: updatedPlayers };
      setActive(currentBattle);
      setCurrentRound(idx + 1);
      // play loudest drop sound
      const topRoll = updatedPlayers.reduce((a, p) => {
        const last = p.rolls[p.rolls.length - 1];
        const s = getSkin(last.skinId)!;
        return s.price > a.price ? s : a;
      }, getSkin(updatedPlayers[0].rolls[updatedPlayers[0].rolls.length - 1].skinId)!);
      if (topRoll.rarity === 'ancient' || topRoll.rarity === 'immortal' || topRoll.rarity === 'legendary') {
        dropSound(topRoll.rarity);
      }
      idx += 1;
      setTimeout(doRound, stride);
    };
    setTimeout(doRound, 350);
  }

  function reset() {
    setActive(null);
    setWinnerIds(null);
    setPickedCases([]);
    setCurrentRound(0);
    setRolling(false);
  }

  return (
    <div className="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
      <div className="text-center mb-5">
        <div className="text-white font-black text-2xl">{t('battles')}</div>
        <div className="text-[11px] text-white/45">Создайте баттл, откройте кейсы одновременно</div>
      </div>

      {!active ? (
        <>
          <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4 mb-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <div className="text-[11px] uppercase tracking-wider text-white/55 font-bold mb-2">{t('mode')}</div>
                <div className="grid grid-cols-2 gap-2">
                  {MODES.map(m => (
                    <button key={m.id} onClick={() => { clickSound(); setMode(m.id); }}
                      className={['px-3 py-2 rounded text-sm font-bold border',
                        mode === m.id ? 'bg-[#FF6B1A] text-white border-[#FF6B1A]' : 'bg-[#0F1923] border-[#22324a] text-white/70 hover:border-[#FF6B1A]/50'].join(' ')}>
                      {m.label}
                    </button>
                  ))}
                </div>
                <div className="flex flex-wrap gap-3 mt-3 text-sm">
                  <label className="flex items-center gap-2 text-white/70 cursor-pointer">
                    <input type="checkbox" checked={crazy} onChange={e => setCrazy(e.target.checked)} className="accent-[#FF6B1A]" />
                    {t('crazy')}
                  </label>
                  <label className="flex items-center gap-2 text-white/70 cursor-pointer">
                    <input type="checkbox" checked={bots} onChange={e => setBots(e.target.checked)} className="accent-[#FF6B1A]" />
                    {t('add_bots')}
                  </label>
                  <label className="flex items-center gap-2 text-white/70 cursor-pointer">
                    <input type="checkbox" checked={fast} onChange={e => setFast(e.target.checked)} className="accent-[#FF6B1A]" />
                    ⚡ Быстрый режим
                  </label>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[11px] uppercase tracking-wider text-white/55 font-bold">Выбрано кейсов: {pickedCases.length}/20</div>
                  {pickedCases.length > 0 && (
                    <button onClick={clearAll} className="text-[11px] text-white/45 hover:text-red-400">Очистить</button>
                  )}
                </div>
                <div className="bg-[#0F1923] border border-[#22324a] rounded p-2 min-h-[80px] flex flex-wrap gap-1.5 max-h-[120px] overflow-y-auto">
                  {pickedCases.length === 0 && <div className="text-white/30 text-sm m-auto">{t('pick_cases')} (можно повторять)</div>}
                  {pickedCases.map((cid, i) => {
                    const c = allCases.find(c => c.id === cid)!;
                    return (
                      <button key={i} onClick={() => removeAt(i)}
                        className={`group relative w-12 h-12 rounded bg-gradient-to-br ${c.accent} flex items-center justify-center text-xl hover:scale-110 transition-transform`}
                        title={`${c.name} — нажмите чтобы убрать`}>
                        <span>{c.image}</span>
                        <span className="absolute inset-0 bg-red-500/80 text-white text-xs font-black flex items-center justify-center rounded opacity-0 group-hover:opacity-100">✕</span>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <div className="text-sm text-white/55">Стоимость: <span className="text-[#FF6B1A] font-bold">{cost.toLocaleString('ru-RU')} ₽</span></div>
                  <button onClick={startBattle}
                    disabled={pickedCases.length === 0 || user.balance < cost}
                    className={['px-5 py-2 rounded font-bold',
                      pickedCases.length === 0 || user.balance < cost
                        ? 'bg-[#152030] border border-[#22324a] text-white/30'
                        : 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white shadow-lg shadow-[#FF6B1A]/30'].join(' ')}>
                    ▶ {t('start')}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Поиск кейсов..."
            className="w-full bg-[#152030] border border-[#22324a] rounded px-3 py-2 text-sm text-white mb-3 outline-none focus:border-[#FF6B1A]" />
          <div className="text-[10px] uppercase tracking-wider text-white/45 mb-2">Нажмите кейс чтобы добавить в баттл (можно несколько одинаковых)</div>
          <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 gap-2 max-h-[500px] overflow-y-auto">
            {filtered.map(c => {
              const countPicked = pickedCases.filter(p => p === c.id).length;
              return (
                <button key={c.id} onClick={() => { clickSound(); addCase(c.id); }}
                  className="relative bg-[#152030] border border-[#22324a] hover:border-[#FF6B1A] rounded p-2 flex flex-col items-center transition-colors">
                  {countPicked > 0 && (
                    <div className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#FF6B1A] text-white text-[10px] font-black flex items-center justify-center border-2 border-[#0F1923]">{countPicked}</div>
                  )}
                  <div className={`w-full h-14 rounded bg-gradient-to-br ${c.accent} flex items-center justify-center text-xl mb-1`}>{c.image}</div>
                  <div className="text-[10px] font-bold text-white/85 truncate w-full text-center">{c.name}</div>
                  <div className="text-[10px] text-[#FF6B1A] font-bold">{c.price} ₽</div>
                </button>
              );
            })}
          </div>
        </>
      ) : (
        <BattleRunner
          battle={active}
          rolling={rolling}
          currentRound={currentRound}
          totalRounds={active.cases.length}
          winnerIds={winnerIds}
          caseDefs={active.cases.map(cid => allCases.find(c => c.id === cid)!).filter(Boolean) as CaseDef[]}
          onReset={reset}
        />
      )}
    </div>
  );
}

function BattleRunner({ battle, caseDefs, rolling, currentRound, totalRounds, winnerIds, onReset }: {
  battle: Battle; caseDefs: CaseDef[]; rolling: boolean; currentRound: number; totalRounds: number; winnerIds: string[] | null; onReset: () => void;
}) {
  return (
    <div>
      {/* Top bar with case progress */}
      <div className="bg-[#152030] border border-[#22324a] rounded-lg p-3 mb-3">
        <div className="flex items-center justify-between mb-2">
          <div className="text-[11px] uppercase tracking-wider text-white/55 font-bold">
            Раунд {Math.min(currentRound, totalRounds)} / {totalRounds}
            {battle.crazy && <span className="ml-2 text-yellow-400">CRAZY MODE</span>}
          </div>
          <button onClick={onReset} className="px-3 py-1.5 rounded bg-[#0F1923] border border-[#22324a] hover:border-[#FF6B1A] text-white/70 text-sm">
            {rolling ? 'Пропустить' : '⟲ Новый баттл'}
          </button>
        </div>
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          {caseDefs.map((c, i) => (
            <div key={i} className={[
              'shrink-0 w-10 h-10 rounded bg-gradient-to-br flex items-center justify-center text-lg transition-all',
              c.accent,
              i < currentRound ? 'opacity-30' : i === currentRound - 1 ? 'ring-2 ring-[#FF6B1A] scale-110' : ''
            ].join(' ')}>{c.image}</div>
          ))}
        </div>
      </div>

      <div className={`grid gap-3 ${
        battle.players.length === 2 ? 'grid-cols-1 sm:grid-cols-2' :
        battle.players.length === 3 ? 'grid-cols-1 sm:grid-cols-3' :
        'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
      }`}>
        {battle.players.map(p => {
          const isWinner = winnerIds?.includes(p.userId);
          const isLoser = winnerIds && !isWinner;
          return (
            <div key={p.userId}
              className={['bg-[#152030] border rounded-lg p-3 transition-all',
                isWinner ? 'border-[#FF6B1A] shadow-[0_0_30px_rgba(255,107,26,0.4)]'
                : isLoser ? 'border-[#22324a] opacity-60'
                : 'border-[#22324a]'].join(' ')}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FF6B1A] to-[#8b3700] flex items-center justify-center text-lg">{p.avatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-bold text-sm truncate">{p.username}</div>
                  <div className="text-[10px] text-white/45">Team {p.team + 1}{p.isBot ? ' · BOT' : ''}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-white/45">Total</div>
                  <div className="text-[#FF6B1A] font-black text-sm">{p.total.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽</div>
                </div>
              </div>

              {/* Spinning slot for current round */}
              {rolling && p.rolls.length === currentRound && currentRound > 0 && (
                <CurrentRoundReveal key={`${p.userId}-${currentRound}`} skinId={p.rolls[p.rolls.length - 1].skinId} />
              )}

              <div className="space-y-1 mt-2 max-h-[260px] overflow-y-auto">
                <AnimatePresence>
                  {p.rolls.slice(0, currentRound).map((r, i) => {
                    const s = getSkin(r.skinId)!;
                    const col = RARITY_COLORS[s.rarity].hex;
                    // Skip the very last one if it's currently being revealed
                    if (rolling && i === currentRound - 1) return null;
                    return (
                      <motion.div key={i} initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }}
                        className="flex items-center gap-2 bg-[#0F1923] rounded p-1.5"
                        style={{ borderLeft: `3px solid ${col}` }}>
                        <SkinIcon skin={s} className="w-10 h-8" />
                        <div className="flex-1 min-w-0 text-[10px]">
                          <div className="text-white truncate">{s.name}</div>
                          <div className="text-white/45 truncate">{s.skin_name}</div>
                        </div>
                        <div className="text-[10px] font-bold" style={{ color: col }}>{r.value.toFixed(0)}</div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>

              {isWinner && !rolling && (
                <motion.div initial={{ scale: 0.8 }} animate={{ scale: 1 }}
                  className="mt-2 text-center py-1.5 rounded bg-[#FF6B1A] text-white font-black text-sm">
                  👑 ПОБЕДА
                </motion.div>
              )}
              {isLoser && (
                <div className="mt-2 text-center py-1 rounded bg-[#0F1923] border border-[#22324a] text-white/40 font-bold text-xs">
                  Поражение
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// Quick "spinning" reveal for the current round (lightweight, not full reel)
function CurrentRoundReveal({ skinId }: { skinId: string }) {
  const skin = getSkin(skinId)!;
  const col = RARITY_COLORS[skin.rarity].hex;
  const [phase, setPhase] = useState<'spin' | 'reveal'>('spin');
  const tickRef = useRef<number | null>(null);

  useEffect(() => {
    const id = setTimeout(() => {
      setPhase('reveal');
      dropSound(skin.rarity);
    }, 600);
    return () => { clearTimeout(id); if (tickRef.current) clearTimeout(tickRef.current); };
  }, [skinId]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.85 }} animate={{ opacity: 1, scale: 1 }}
      className="relative h-[80px] rounded overflow-hidden bg-[#0F1923] border border-[#22324a]"
      style={{ borderBottom: `3px solid ${col}`, boxShadow: phase === 'reveal' ? `0 0 20px ${col}88` : 'none' }}
    >
      {phase === 'spin' ? (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="flex animate-pulse">
            <span className="text-white/40 text-xs">spinning…</span>
          </div>
        </div>
      ) : (
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
          className="absolute inset-0 flex items-center gap-3 px-3">
          <SkinIcon skin={skin} className="h-14" />
          <div className="flex-1 min-w-0">
            <div className="text-white text-xs font-bold truncate">{skin.name}</div>
            <div className="text-[10px] text-white/55 truncate">{skin.skin_name}</div>
            <div className="text-sm font-black" style={{ color: col }}>{skin.price.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽</div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
