import { useMemo, useState } from 'react';
import { motion, useAnimationControls } from 'framer-motion';
import { useT } from '../lib/useT';
import { addItemToInventory, addToBalance, getSkin, progressQuest, removeItemsFromInventory, updateUser, useStore } from '../lib/store';
import { SKINS, RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from '../components/SkinIcon';
import { clickSound, errorSound, failSound, successSound } from '../lib/sound';

const HOUSE_EDGE = 0.75;

export function UpgradePage({ onLogin }: { onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [selectedUids, setSelectedUids] = useState<string[]>([]);
  const [balanceUsage, setBalanceUsage] = useState(0);
  const [targetId, setTargetId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [spinning, setSpinning] = useState(false);
  const [outcome, setOutcome] = useState<'success' | 'fail' | null>(null);
  const [multFilter, setMultFilter] = useState<number | null>(null);
  const controls = useAnimationControls();

  if (!user) {
    return (
      <div className="px-6 py-16 text-center">
        <div className="text-5xl mb-4">⬆️</div>
        <div className="text-white/60 mb-4">{t('auth_required')}</div>
        <button onClick={onLogin} className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">{t('login')}</button>
      </div>
    );
  }

  const inputValue = selectedUids.reduce((a, uid) => {
    const it = user.inventory.find(i => i.uid === uid); if (!it) return a;
    return a + (getSkin(it.skinId)?.price ?? 0);
  }, 0) + balanceUsage;

  const target = targetId ? SKINS.find(s => s.id === targetId) : null;
  const successChance = target && inputValue > 0
    ? Math.min(95, Math.max(1, (inputValue / target.price) * HOUSE_EDGE * 100))
    : 0;

  // Marketplace: filtered by multiplier OR by search/manual price range
  const filteredMarket = useMemo(() => {
    let pool = SKINS;
    if (multFilter && inputValue > 0) {
      // Show skins worth approximately inputValue * multFilter (±40% range)
      const targetPrice = inputValue * multFilter;
      const lo = targetPrice * 0.6;
      const hi = targetPrice * 1.4;
      pool = pool.filter(s => s.price >= lo && s.price <= hi);
    } else if (inputValue > 0 && !search) {
      // Default: show skins more expensive than input (upgrade targets)
      pool = pool.filter(s => s.price > inputValue * 0.8);
    }
    if (search) {
      pool = pool.filter(s => s.market_hash_name.toLowerCase().includes(search.toLowerCase()));
    }
    return pool.sort((a, b) => a.price - b.price).slice(0, 80);
  }, [search, inputValue, multFilter]);

  function selectMultiplier(mult: number) {
    setMultFilter(mult);
    setTargetId(null);
    clickSound();
  }

  function doUpgrade() {
    if (!target || successChance === 0 || spinning) { errorSound(); return; }
    if (balanceUsage > user!.balance) { errorSound(); return; }
    setOutcome(null);
    setSpinning(true);
    const success = Math.random() * 100 < successChance;
    const successArc = successChance * 3.6;
    const landing = success
      ? Math.random() * successArc
      : successArc + Math.random() * (360 - successArc);
    const totalRotation = 360 * 6 + landing;
    controls.start({ rotate: totalRotation, transition: { duration: 3.5, ease: [0.16, 0.93, 0.18, 1] } })
      .then(() => {
        progressQuest(user!.id, 'upgrade', 1);
        if (balanceUsage > 0) addToBalance(user!.id, -balanceUsage, 'upgrade', 'Upgrade balance');
        removeItemsFromInventory(user!.id, selectedUids);
        updateUser(user!.id, u => ({ stats: { ...u.stats, upgradesAttempted: u.stats.upgradesAttempted + 1 } }));
        if (success) {
          addItemToInventory(user!.id, target.id);
          updateUser(user!.id, u => ({ stats: { ...u.stats, upgradesWon: u.stats.upgradesWon + 1 } }));
          successSound();
          setOutcome('success');
        } else {
          failSound();
          setOutcome('fail');
        }
        setSpinning(false);
        setTimeout(() => {
          setOutcome(null);
          setSelectedUids([]);
          setBalanceUsage(0);
          setMultFilter(null);
          controls.set({ rotate: 0 });
        }, 2500);
      });
  }

  return (
    <div className="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
      <div className="text-center mb-5">
        <div className="text-white font-black text-2xl tracking-wide">{t('upgrade_title')}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-[1fr_260px_1fr] gap-4">
        {/* Left: input items */}
        <Panel title={t('upgrade_pick_input')}>
          {selectedUids.length === 0 ? (
            <div className="text-center text-white/20 py-8 text-4xl">🔫</div>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {selectedUids.map(uid => {
                const it = user.inventory.find(i => i.uid === uid); if (!it) return null;
                const s = getSkin(it.skinId)!;
                const col = RARITY_COLORS[s.rarity].hex;
                return (
                  <div key={uid} className="relative bg-[#0F1923] rounded p-2 flex flex-col items-center" style={{ borderBottom: `3px solid ${col}` }}>
                    <button onClick={() => setSelectedUids(arr => arr.filter(u => u !== uid))} className="absolute top-0.5 right-0.5 w-5 h-5 text-xs text-white/40 hover:text-red-400">✕</button>
                    <SkinIcon skin={s} className="h-12" />
                    <div className="text-[10px] mt-1 text-[#FF6B1A] font-bold">{s.price.toFixed(0)} ₽</div>
                  </div>
                );
              })}
            </div>
          )}
          {inputValue > 0 && <div className="text-center text-sm text-white/55 mt-2 pt-2 border-t border-[#22324a]">
            Ваш вклад: <span className="text-[#FF6B1A] font-bold">{inputValue.toFixed(0)} ₽</span>
          </div>}
        </Panel>

        {/* Center: wheel */}
        <div className="flex flex-col items-center">
          <div className="relative w-[220px] h-[220px]">
            <div className="absolute left-1/2 -translate-x-1/2 -top-2 z-20"
              style={{ borderLeft: '10px solid transparent', borderRight: '10px solid transparent', borderTop: '14px solid #FF6B1A' }} />
            <motion.svg viewBox="0 0 100 100" animate={controls} className="w-full h-full">
              <circle cx="50" cy="50" r="48" fill="#0F1923" stroke="#22324a" strokeWidth="1" />
              {target && inputValue > 0 && (() => {
                const angle = successChance * 3.6;
                const a = (angle - 90) * Math.PI / 180;
                const x = 50 + 48 * Math.cos(a);
                const y = 50 + 48 * Math.sin(a);
                const large = angle > 180 ? 1 : 0;
                return <path d={`M 50 50 L 50 2 A 48 48 0 ${large} 1 ${x.toFixed(2)} ${y.toFixed(2)} Z`} fill="#FF6B1A" opacity="0.85" />;
              })()}
              <circle cx="50" cy="50" r="28" fill="#152030" stroke="#22324a" />
              <text x="50" y="54" textAnchor="middle" fontSize="13" fill="#fff" fontWeight="900">{successChance.toFixed(0)}%</text>
            </motion.svg>
          </div>

          {/* Multiplier buttons — NOW they filter the marketplace */}
          <div className="text-[10px] uppercase tracking-wider text-white/45 text-center mt-3 mb-1">Показать цели по множителю:</div>
          <div className="grid grid-cols-6 gap-1 w-full">
            {[{ label: 'x2', v: 2 }, { label: 'x5', v: 5 }, { label: 'x10', v: 10 }, { label: '30%', v: 1 / 0.3 }, { label: '50%', v: 1 / 0.5 }, { label: '75%', v: 1 / 0.75 }].map(m => (
              <button key={m.label} onClick={() => selectMultiplier(m.v)}
                disabled={inputValue <= 0}
                className={[
                  'py-1.5 rounded text-[11px] font-bold border transition-colors',
                  multFilter === m.v
                    ? 'bg-[#FF6B1A] border-[#FF6B1A] text-white'
                    : 'bg-[#152030] border-[#22324a] text-white/65 hover:border-[#FF6B1A]/50',
                  inputValue <= 0 ? 'opacity-40' : '',
                ].join(' ')}>
                {m.label}
              </button>
            ))}
          </div>

          {/* Balance slider */}
          <div className="w-full mt-3 bg-[#0F1923] border border-[#22324a] rounded p-2">
            <div className="flex items-center justify-between text-[11px] text-white/55 mb-1">
              <span>{t('upgrade_add_balance')}</span>
              <span className="text-[#FF6B1A] font-bold">{balanceUsage.toFixed(0)} ₽</span>
            </div>
            <input type="range" min={0} max={user.balance} step={1} value={balanceUsage}
              onChange={e => setBalanceUsage(parseInt(e.target.value))} className="w-full accent-[#FF6B1A]" />
          </div>

          <button onClick={doUpgrade} disabled={spinning || !target || successChance === 0}
            className={[
              'w-full mt-3 px-4 py-3 rounded font-black text-sm tracking-wider',
              spinning || !target || successChance === 0
                ? 'bg-[#152030] border border-[#22324a] text-white/30'
                : 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white shadow-lg shadow-[#FF6B1A]/30'
            ].join(' ')}>
            ⚡ {spinning ? '...' : t('upgrade_btn')}
          </button>

          {outcome && (
            <div className={['mt-3 font-black text-xl px-4 py-2 rounded',
              outcome === 'success' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-red-500/20 text-red-300 border border-red-500/40'].join(' ')}>
              {outcome === 'success' ? t('success') : t('fail')}
            </div>
          )}
        </div>

        {/* Right: target */}
        <Panel title={t('upgrade_pick_target')}>
          {target ? (
            <div className="relative bg-[#0F1923] rounded p-3 flex flex-col items-center" style={{ borderBottom: `3px solid ${RARITY_COLORS[target.rarity].hex}` }}>
              <button onClick={() => setTargetId(null)} className="absolute top-1 right-1 w-6 h-6 text-white/40 hover:text-red-400">✕</button>
              <SkinIcon skin={target} className="h-20" />
              <div className="text-[12px] mt-2 text-white font-bold text-center">{target.market_hash_name}</div>
              <div className="text-sm font-black mt-1" style={{ color: RARITY_COLORS[target.rarity].hex }}>
                {target.price.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽
              </div>
              <div className="text-xs text-white/45 mt-1">Шанс: {successChance.toFixed(1)}%</div>
            </div>
          ) : (
            <div className="text-center text-white/30 py-10 text-sm">
              {inputValue > 0 ? '← Выберите цель из списка ниже' : 'Сначала выберите предметы слева'}
            </div>
          )}
        </Panel>
      </div>

      {/* Bottom: items + marketplace */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <Panel title={`Мои предметы (${user.inventory.length})`}>
          {user.inventory.length === 0 ? (
            <div className="text-center py-6 text-white/40 text-sm">{t('upgrade_no_items')}</div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[400px] overflow-y-auto">
              {user.inventory.map(it => {
                const s = getSkin(it.skinId)!;
                const col = RARITY_COLORS[s.rarity].hex;
                const sel = selectedUids.includes(it.uid);
                return (
                  <button key={it.uid}
                    onClick={() => { clickSound(); setSelectedUids(arr => sel ? arr.filter(u => u !== it.uid) : arr.length < 6 ? [...arr, it.uid] : arr); }}
                    className={['relative bg-[#0F1923] rounded p-2 flex flex-col items-center transition-colors',
                      sel ? 'ring-2 ring-[#FF6B1A]' : 'hover:bg-[#1a2638]'].join(' ')}
                    style={{ borderBottom: `3px solid ${col}` }}>
                    <SkinIcon skin={s} className="h-10" />
                    <div className="text-[9px] mt-1 text-white/85 truncate w-full text-center">{s.name}</div>
                    <div className="text-[10px] text-[#FF6B1A] font-bold">{s.price.toFixed(0)}</div>
                  </button>
                );
              })}
            </div>
          )}
        </Panel>

        <Panel title={`Цели для апгрейда ${multFilter ? '(фильтр активен)' : ''}`}>
          <div className="flex gap-2 mb-2">
            <input value={search} onChange={e => { setSearch(e.target.value); setMultFilter(null); }} placeholder="Поиск..."
              className="flex-1 bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-1.5 text-sm text-white" />
            {multFilter && <button onClick={() => setMultFilter(null)} className="px-2 py-1 text-xs text-white/50 hover:text-red-400">✕ фильтр</button>}
          </div>
          {filteredMarket.length === 0 ? (
            <div className="text-center py-6 text-white/40 text-sm">
              {inputValue > 0 ? 'Нет скинов в этом диапазоне' : 'Выберите предметы слева, чтобы увидеть цели'}
            </div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[400px] overflow-y-auto">
              {filteredMarket.map(s => {
                const col = RARITY_COLORS[s.rarity].hex;
                const sel = targetId === s.id;
                const chance = inputValue > 0 ? Math.min(95, Math.max(1, (inputValue / s.price) * HOUSE_EDGE * 100)) : 0;
                return (
                  <button key={s.id} onClick={() => { clickSound(); setTargetId(s.id); }}
                    className={['relative bg-[#0F1923] rounded p-2 flex flex-col items-center transition-colors',
                      sel ? 'ring-2 ring-[#FF6B1A]' : 'hover:bg-[#1a2638]'].join(' ')}
                    style={{ borderBottom: `3px solid ${col}` }}>
                    <SkinIcon skin={s} className="h-10" />
                    <div className="text-[9px] mt-1 text-white/85 truncate w-full text-center">{s.name}</div>
                    <div className="text-[10px] text-[#FF6B1A] font-bold">{s.price.toFixed(0)}</div>
                    {chance > 0 && <div className="text-[9px] text-white/45">{chance.toFixed(0)}%</div>}
                  </button>
                );
              })}
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-[#152030] border border-[#22324a] rounded-lg">
      <div className="px-3 py-2 border-b border-[#22324a] text-[11px] uppercase tracking-wider text-white/55 font-bold">{title}</div>
      <div className="p-3">{children}</div>
    </div>
  );
}
