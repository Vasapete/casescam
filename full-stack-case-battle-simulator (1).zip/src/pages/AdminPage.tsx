import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { addItemToInventory, addToBalance, removeItemsFromInventory, setSkinPriceOverride, setState, updateUser, useStore, getSkin } from '../lib/store';
import { SKINS, RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from '../components/SkinIcon';
import type { Rarity, User, Transaction } from '../lib/types';
import { clickSound, errorSound, successSound } from '../lib/sound';
import { getCases } from '../lib/cases';

type Tab = 'dashboard' | 'users' | 'promos' | 'skins' | 'cases' | 'transactions';

export function AdminPage({ onLogin }: { onLogin: () => void }) {
  const me = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [tab, setTab] = useState<Tab>('dashboard');

  if (!me || me.role !== 'admin') {
    return (
      <div className="px-6 py-20 text-center max-w-md mx-auto">
        <div className="text-5xl mb-4">🛡️</div>
        <div className="text-white font-black text-xl mb-2">Доступ запрещён</div>
        <div className="text-white/55 mb-6 text-sm">Войдите как администратор для доступа к панели</div>
        <button onClick={onLogin} className="px-6 py-2.5 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">Войти</button>
      </div>
    );
  }

  const navItems: { id: Tab; icon: string; label: string }[] = [
    { id: 'dashboard',    icon: '📊', label: 'Dashboard' },
    { id: 'users',        icon: '👥', label: 'Пользователи' },
    { id: 'promos',       icon: '🎟️', label: 'Промокоды' },
    { id: 'skins',        icon: '🔫', label: 'Скины' },
    { id: 'cases',        icon: '📦', label: 'Кейсы' },
    { id: 'transactions', icon: '💸', label: 'Транзакции' },
  ];

  return (
    <div className="flex min-h-[calc(100vh-70px)]">
      {/* Sidebar — relative so the footer at bottom works */}
      <aside className="relative w-[220px] shrink-0 bg-[#0c1521] border-r border-[#1f2a3d] flex flex-col">
        <div className="px-4 py-4 border-b border-[#1f2a3d]">
          <div className="flex items-center gap-2">
            <span className="text-[#FF6B1A] text-lg">🛡️</span>
            <div>
              <div className="text-white font-black text-sm leading-tight">ADMIN PANEL</div>
              <div className="text-[9px] text-white/40 leading-tight">CASE-BATTLE SIM</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 py-2 space-y-0.5 px-2 overflow-y-auto">
          {navItems.map(n => (
            <button key={n.id} onClick={() => { clickSound(); setTab(n.id); }}
              className={[
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-semibold transition-colors',
                tab === n.id
                  ? 'bg-[#FF6B1A]/15 text-[#FF6B1A]'
                  : 'text-white/50 hover:text-white hover:bg-white/5'
              ].join(' ')}>
              <span className="text-base w-5 text-center">{n.icon}</span>
              <span>{n.label}</span>
              {tab === n.id && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#FF6B1A]" />}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-[#1f2a3d]">
          <div className="flex items-center gap-2 bg-[#152030] rounded-md p-2.5">
            <div className="w-7 h-7 rounded-full bg-[#FF6B1A] flex items-center justify-center text-sm">{me.avatar}</div>
            <div className="flex-1 min-w-0">
              <div className="text-white text-xs font-bold truncate">{me.username}</div>
              <div className="text-[10px] text-emerald-400 font-semibold">● Online</div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 min-w-0 p-5 overflow-y-auto bg-[#0F1923]">
        {tab === 'dashboard' && <DashboardTab />}
        {tab === 'users' && <UsersTab />}
        {tab === 'promos' && <PromosTab />}
        {tab === 'skins' && <SkinsTab />}
        {tab === 'cases' && <CasesTab />}
        {tab === 'transactions' && <TransactionsTab />}
      </main>
    </div>
  );
}

/* =================== Reusable UI =================== */
function H({ title, sub, action }: { title: string; sub?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 mb-5 pb-3 border-b border-[#1f2a3d]">
      <div>
        <h1 className="text-white font-black text-xl">{title}</h1>
        {sub && <div className="text-xs text-white/45 mt-0.5">{sub}</div>}
      </div>
      {action}
    </div>
  );
}
function Card({ children, noPad, className = '' }: { children: React.ReactNode; noPad?: boolean; className?: string }) {
  return <div className={`bg-[#152030] border border-[#22324a] rounded-lg ${noPad ? '' : 'p-4'} ${className}`}>{children}</div>;
}
function Metric({ icon, label, value, delta }: { icon: string; label: string; value: any; delta?: string }) {
  return (
    <Card>
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-[10px] uppercase tracking-wider text-white/45">{label}</span>
        <span className="text-lg">{icon}</span>
      </div>
      <div className="text-white font-black text-lg">{value}</div>
      {delta && <div className="text-[11px] text-emerald-400 mt-0.5">{delta}</div>}
    </Card>
  );
}
function Badge({ children, tone, style }: { children: React.ReactNode; tone?: 'ok' | 'warn' | 'bad'; style?: React.CSSProperties }) {
  const c = tone === 'ok' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
    : tone === 'warn' ? 'bg-yellow-500/15 text-yellow-300 border-yellow-500/30'
    : tone === 'bad' ? 'bg-red-500/15 text-red-300 border-red-500/30'
    : 'bg-[#0F1923] text-white/70 border-[#22324a]';
  return <span style={style} className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase tracking-wider border inline-block ${c}`}>{children}</span>;
}
function Modal({ open, onClose, title, children, wide }: { open: boolean; onClose: () => void; title: string; children: React.ReactNode; wide?: boolean }) {
  return (
    <AnimatePresence>
      {open && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onClick={onClose} className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <motion.div initial={{ scale: 0.95, y: 12 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.96 }}
            onClick={e => e.stopPropagation()} className={`bg-[#152030] border border-[#22324a] rounded-lg shadow-2xl w-full ${wide ? 'max-w-2xl' : 'max-w-md'}`}>
            <div className="px-5 py-3 border-b border-[#22324a] flex items-center justify-between">
              <span className="text-white font-bold text-sm">{title}</span>
              <button onClick={onClose} className="w-7 h-7 rounded text-white/40 hover:text-white hover:bg-[#0F1923]">✕</button>
            </div>
            <div className="p-5">{children}</div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
function fmt(n: number) { return n.toLocaleString('ru-RU', { maximumFractionDigits: 2 }); }

/* =================== DASHBOARD =================== */
function DashboardTab() {
  const users = useStore(s => Object.values(s.users));
  const totalBal = users.reduce((a, u) => a + u.balance, 0);
  const totalItems = users.reduce((a, u) => a + u.inventory.length, 0);
  const totalCases = users.reduce((a, u) => a + u.stats.casesOpened, 0);
  const top = [...users].sort((a, b) => b.balance - a.balance).slice(0, 5);
  const rarityDist: Record<Rarity, number> = { common: 0, uncommon: 0, rare: 0, mythical: 0, legendary: 0, ancient: 0, immortal: 0 };
  users.forEach(u => u.inventory.forEach(i => { const s = getSkin(i.skinId); if (s) rarityDist[s.rarity]++; }));

  return (
    <div>
      <H title="Dashboard" sub="Обзор системы" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-5">
        <Metric icon="👥" label="Пользователи" value={users.length} />
        <Metric icon="💰" label="В экономике" value={`${fmt(totalBal)} ₽`} />
        <Metric icon="📦" label="Кейсов открыто" value={totalCases} />
        <Metric icon="🎒" label="Предметов" value={totalItems} />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <div className="text-xs uppercase tracking-wider text-white/45 font-bold mb-3">🏆 Топ по балансу</div>
          {top.map((u, i) => (
            <div key={u.id} className="flex items-center gap-2 bg-[#0F1923] rounded p-2 mb-1.5 border border-[#1c2740]">
              <div className={`w-6 h-6 rounded font-black flex items-center justify-center text-xs ${i === 0 ? 'bg-yellow-500 text-black' : i === 1 ? 'bg-zinc-400 text-black' : 'bg-[#152030] text-white/50'}`}>{i + 1}</div>
              <span className="text-lg">{u.avatar}</span>
              <div className="flex-1 min-w-0 text-sm font-bold text-white truncate">{u.username}</div>
              <div className="text-[#FF6B1A] font-bold text-sm">{fmt(u.balance)} ₽</div>
            </div>
          ))}
        </Card>
        <Card>
          <div className="text-xs uppercase tracking-wider text-white/45 font-bold mb-3">📊 Распределение редкостей</div>
          {(Object.keys(rarityDist) as Rarity[]).reverse().map(r => {
            const total = Object.values(rarityDist).reduce((a, b) => a + b, 0) || 1;
            const pct = (rarityDist[r] / total) * 100;
            return (
              <div key={r} className="mb-2">
                <div className="flex items-center justify-between text-[11px] mb-0.5">
                  <span style={{ color: RARITY_COLORS[r].hex }} className="font-bold">{RARITY_COLORS[r].ru}</span>
                  <span className="text-white/50 font-mono">{rarityDist[r]} · {pct.toFixed(1)}%</span>
                </div>
                <div className="h-1.5 bg-[#0F1923] rounded overflow-hidden">
                  <div className="h-full" style={{ width: `${pct}%`, background: RARITY_COLORS[r].hex }} />
                </div>
              </div>
            );
          })}
        </Card>
      </div>
    </div>
  );
}

/* =================== USERS =================== */
function UsersTab() {
  const users = useStore(s => Object.values(s.users));
  const [search, setSearch] = useState('');
  const [adj, setAdj] = useState<User | null>(null);
  const [adjVal, setAdjVal] = useState('');
  const [adjReason, setAdjReason] = useState('');
  const [viewing, setViewing] = useState<User | null>(null);
  const filtered = useMemo(() => users.filter(u => !search || u.username.toLowerCase().includes(search.toLowerCase()) || u.id.includes(search)).sort((a, b) => b.balance - a.balance), [users, search]);

  function doAdj() {
    if (!adj) return;
    const n = parseFloat(adjVal);
    if (isNaN(n)) { errorSound(); return; }
    addToBalance(adj.id, n, 'admin', adjReason || 'Admin adjust');
    successSound(); setAdj(null);
  }

  return (
    <div>
      <H title="Пользователи" sub={`Всего: ${users.length}`} action={
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Поиск..."
          className="w-60 bg-[#152030] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-sm text-white" />
      } />
      <Card noPad>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-[10px] uppercase tracking-wider text-white/45 border-b border-[#22324a]">
              <th className="text-left px-4 py-2">ID</th><th className="text-left px-4 py-2">Пользователь</th>
              <th className="text-right px-4 py-2">Баланс</th><th className="text-right px-4 py-2">Предметов</th>
              <th className="text-center px-4 py-2">Роль</th><th className="text-right px-4 py-2">Действия</th>
            </tr></thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id} className="border-b border-[#1a2638] hover:bg-[#152030]">
                  <td className="px-4 py-2 font-mono text-xs text-white/50">{u.id}</td>
                  <td className="px-4 py-2"><div className="flex items-center gap-2"><span className="text-lg">{u.avatar}</span><span className="text-white font-bold">{u.username}</span></div></td>
                  <td className="px-4 py-2 text-right text-[#FF6B1A] font-bold">{fmt(u.balance)} ₽</td>
                  <td className="px-4 py-2 text-right text-white/70">{u.inventory.length}</td>
                  <td className="px-4 py-2 text-center"><Badge tone={u.role === 'admin' ? 'ok' : undefined}>{u.role}</Badge></td>
                  <td className="px-4 py-2 text-right space-x-1">
                    <Btn onClick={() => { setAdj(u); setAdjVal(''); setAdjReason(''); }}>±₽</Btn>
                    <Btn onClick={() => setViewing(u)}>👁️</Btn>
                    <Btn onClick={() => { updateUser(u.id, { role: u.role === 'admin' ? 'user' : 'admin' }); successSound(); }}>🛡️</Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <Modal open={!!adj} onClose={() => setAdj(null)} title="Изменить баланс">
        {adj && <div className="space-y-3">
          <div className="bg-[#0F1923] rounded p-3 flex items-center gap-3"><span className="text-2xl">{adj.avatar}</span><div><div className="text-white font-bold">{adj.username}</div><div className="text-xs text-white/50">Текущий: <span className="text-[#FF6B1A] font-bold">{fmt(adj.balance)} ₽</span></div></div></div>
          <input type="number" value={adjVal} onChange={e => setAdjVal(e.target.value)} placeholder="1000 или -500" autoFocus className="w-full bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white" />
          <input value={adjReason} onChange={e => setAdjReason(e.target.value)} placeholder="Причина" className="w-full bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white" />
          <div className="flex justify-end gap-2"><button onClick={() => setAdj(null)} className="px-4 py-2 rounded bg-[#0F1923] border border-[#22324a] text-white/80 text-sm font-bold">Отмена</button><button onClick={doAdj} className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-sm font-bold">Применить</button></div>
        </div>}
      </Modal>
      <Modal open={!!viewing} onClose={() => setViewing(null)} title="Профиль" wide>
        {viewing && <UserDetail user={viewing} onClose={() => setViewing(null)} />}
      </Modal>
    </div>
  );
}

function UserDetail({ user: initUser, onClose }: { user: User; onClose: () => void }) {
  const u = useStore(s => s.users[initUser.id]) ?? initUser;
  const [grantSearch, setGrantSearch] = useState('');
  const grantList = SKINS.filter(s => !grantSearch || s.market_hash_name.toLowerCase().includes(grantSearch.toLowerCase())).sort((a, b) => b.price - a.price).slice(0, 30);
  return (
    <div>
      <div className="flex items-center gap-3 mb-4 pb-3 border-b border-[#22324a]">
        <span className="text-3xl">{u.avatar}</span>
        <div className="flex-1"><div className="text-white font-black">{u.username}</div><div className="text-xs text-white/50 font-mono">{u.id} · {u.role}</div></div>
        <div className="text-right"><div className="text-[#FF6B1A] font-black text-lg">{fmt(u.balance)} ₽</div><div className="text-xs text-white/50">{u.inventory.length} предметов</div></div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
        <StatBox l="Кейсов" v={u.stats.casesOpened} /><StatBox l="Баттлов выиграно" v={u.stats.battlesWon} />
        <StatBox l="Апгрейдов" v={`${u.stats.upgradesWon}/${u.stats.upgradesAttempted}`} /><StatBox l="Streak" v={`${u.daily_streak}д`} />
      </div>
      <div className="text-xs uppercase tracking-wider text-white/45 font-bold mb-2">Инвентарь</div>
      <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5 max-h-[200px] overflow-y-auto mb-4">
        {u.inventory.slice(0, 60).map(it => { const s = getSkin(it.skinId); if (!s) return null;
          return (<div key={it.uid} className="relative bg-[#0F1923] rounded p-1 flex flex-col items-center" style={{ borderBottom: `2px solid ${RARITY_COLORS[s.rarity].hex}` }}>
            <button onClick={() => { removeItemsFromInventory(u.id, [it.uid]); successSound(); }} className="absolute top-0 right-0 w-4 h-4 text-[10px] text-white/30 hover:text-red-400">✕</button>
            <SkinIcon skin={s} className="h-8" /><div className="text-[8px] text-[#FF6B1A] font-bold">{fmt(s.price)}</div>
          </div>);
        })}
        {u.inventory.length === 0 && <div className="col-span-6 text-center text-white/40 text-xs py-4">Пусто</div>}
      </div>
      <div className="text-xs uppercase tracking-wider text-white/45 font-bold mb-2">Выдать скин</div>
      <input value={grantSearch} onChange={e => setGrantSearch(e.target.value)} placeholder="🔍 Поиск скина..." className="w-full bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-1.5 text-sm text-white mb-2" />
      <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5 max-h-[200px] overflow-y-auto">
        {grantList.map(s => (<button key={s.id} onClick={() => { addItemToInventory(u.id, s.id); successSound(); }}
          className="bg-[#0F1923] rounded p-1 flex flex-col items-center hover:bg-[#1a2638]" style={{ borderBottom: `2px solid ${RARITY_COLORS[s.rarity].hex}` }}>
          <SkinIcon skin={s} className="h-8" /><div className="text-[8px] text-white/80 truncate w-full text-center">{s.name}</div><div className="text-[8px] text-[#FF6B1A] font-bold">{fmt(s.price)}</div>
        </button>))}
      </div>
      <div className="flex justify-end mt-3"><button onClick={onClose} className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-sm font-bold">Готово</button></div>
    </div>
  );
}

/* =================== PROMOS =================== */
function PromosTab() {
  const promos = useStore(s => s.promoCodes);
  const [open, setOpen] = useState(false);
  const [code, setCode] = useState('');
  const [amount, setAmount] = useState('500');
  const [maxUses, setMaxUses] = useState('100');
  const [days, setDays] = useState('30');

  function create() {
    if (!code.trim()) { errorSound(); return; }
    setState(s => ({ ...s, promoCodes: [{ id: 'pc_' + Math.random().toString(36).slice(2, 8), code: code.trim().toUpperCase(), amount: parseFloat(amount) || 0, max_uses: parseInt(maxUses) || 100, used_count: 0, expires_at: Date.now() + (parseInt(days) || 30) * 86400000, redeemedBy: [] }, ...s.promoCodes] }));
    setCode(''); setOpen(false); successSound();
  }

  return (
    <div>
      <H title="Промокоды" sub={`${promos.length} кодов`} action={<button onClick={() => setOpen(true)} className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-sm font-bold">+ Создать</button>} />
      <Card noPad>
        <table className="w-full text-sm"><thead><tr className="text-[10px] uppercase tracking-wider text-white/45 border-b border-[#22324a]">
          <th className="text-left px-4 py-2">Код</th><th className="text-right px-4 py-2">Награда</th><th className="text-right px-4 py-2">Исп.</th><th className="text-center px-4 py-2">Статус</th><th className="text-right px-4 py-2"></th>
        </tr></thead><tbody>{promos.map(p => {
          const expired = p.expires_at < Date.now(); const maxed = p.used_count >= p.max_uses;
          return (<tr key={p.id} className="border-b border-[#1a2638] hover:bg-[#152030]">
            <td className="px-4 py-2 font-mono font-bold text-white">{p.code}</td>
            <td className="px-4 py-2 text-right text-[#FF6B1A] font-bold">+{fmt(p.amount)} ₽</td>
            <td className="px-4 py-2 text-right text-white/70">{p.used_count}/{p.max_uses}</td>
            <td className="px-4 py-2 text-center">{expired ? <Badge tone="bad">Истёк</Badge> : maxed ? <Badge tone="warn">Макс</Badge> : <Badge tone="ok">Актив</Badge>}</td>
            <td className="px-4 py-2 text-right"><Btn onClick={() => { setState(s => ({ ...s, promoCodes: s.promoCodes.filter(x => x.id !== p.id) })); successSound(); }}>🗑️</Btn></td>
          </tr>);
        })}</tbody></table>
      </Card>
      <Modal open={open} onClose={() => setOpen(false)} title="Новый промокод">
        <div className="space-y-3">
          <input value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="WELCOME500" autoFocus className="w-full bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white font-mono uppercase" />
          <div className="grid grid-cols-3 gap-2">
            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} placeholder="₽" className="bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white" />
            <input type="number" value={maxUses} onChange={e => setMaxUses(e.target.value)} placeholder="Лимит" className="bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white" />
            <input type="number" value={days} onChange={e => setDays(e.target.value)} placeholder="Дней" className="bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white" />
          </div>
          <div className="flex justify-end gap-2"><button onClick={() => setOpen(false)} className="px-4 py-2 rounded bg-[#0F1923] border border-[#22324a] text-white/80 text-sm font-bold">Отмена</button><button onClick={create} className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-sm font-bold">Создать</button></div>
        </div>
      </Modal>
    </div>
  );
}

/* =================== SKINS =================== */
function SkinsTab() {
  const [search, setSearch] = useState('');
  const [rarity, setRarity] = useState<Rarity | ''>('');
  const [editing, setEditing] = useState<typeof SKINS[0] | null>(null);
  const [newPrice, setNewPrice] = useState('');
  const [, force] = useState(0);
  const filtered = useMemo(() => SKINS.filter(s => (!rarity || s.rarity === rarity) && (!search || s.market_hash_name.toLowerCase().includes(search.toLowerCase()))).sort((a, b) => b.price - a.price).slice(0, 100), [search, rarity]);

  function save() { if (!editing) return; const n = parseFloat(newPrice); if (isNaN(n) || n < 0) { errorSound(); return; } setSkinPriceOverride(editing.id, n); successSound(); setEditing(null); force(x => x + 1); }

  return (
    <div>
      <H title="Скины" sub={`${SKINS.length} в базе`} action={
        <div className="flex gap-2">
          <select value={rarity} onChange={e => setRarity(e.target.value as any)} className="bg-[#152030] border border-[#22324a] rounded px-3 py-2 text-sm text-white">
            <option value="">Все</option>{(Object.keys(RARITY_COLORS) as Rarity[]).map(r => <option key={r} value={r}>{RARITY_COLORS[r].ru}</option>)}</select>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Поиск..." className="w-52 bg-[#152030] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-sm text-white" />
        </div>
      } />
      <Card noPad>
        <table className="w-full text-sm"><thead><tr className="text-[10px] uppercase tracking-wider text-white/45 border-b border-[#22324a]">
          <th className="text-left px-4 py-2">Скин</th><th className="text-left px-4 py-2">Тип</th><th className="px-4 py-2">Редкость</th><th className="text-right px-4 py-2">Цена</th><th className="text-right px-4 py-2"></th>
        </tr></thead><tbody>{filtered.map(s => {
          const col = RARITY_COLORS[s.rarity].hex;
          return (<tr key={s.id} className="border-b border-[#1a2638] hover:bg-[#152030]">
            <td className="px-4 py-2"><div className="flex items-center gap-2"><div className="w-12 h-9 bg-[#0F1923] rounded flex items-center justify-center"><SkinIcon skin={s} className="max-h-8 max-w-10" /></div><div><div className="text-white font-bold text-xs">{s.name}</div><div className="text-[10px] text-white/50">{s.skin_name}</div></div></div></td>
            <td className="px-4 py-2 text-white/50 text-xs">{s.weapon_type}</td>
            <td className="px-4 py-2 text-center"><Badge style={{ background: col + '22', color: col, border: `1px solid ${col}55` }}>{RARITY_COLORS[s.rarity].ru}</Badge></td>
            <td className="px-4 py-2 text-right text-[#FF6B1A] font-bold">{fmt(s.price)} ₽</td>
            <td className="px-4 py-2 text-right"><Btn onClick={() => { setEditing(s); setNewPrice(String(s.price)); }}>💰</Btn></td>
          </tr>);
        })}</tbody></table>
      </Card>
      <Modal open={!!editing} onClose={() => setEditing(null)} title="Изменить цену">
        {editing && <div className="space-y-3">
          <div className="bg-[#0F1923] rounded p-3 flex items-center gap-3" style={{ borderBottom: `3px solid ${RARITY_COLORS[editing.rarity].hex}` }}>
            <SkinIcon skin={editing} className="h-12" /><div><div className="text-white font-bold text-xs">{editing.market_hash_name}</div><div className="text-xs text-white/50">Текущая: {fmt(editing.price)} ₽</div></div></div>
          <input type="number" value={newPrice} onChange={e => setNewPrice(e.target.value)} autoFocus className="w-full bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white" />
          <div className="flex justify-end gap-2"><button onClick={() => setEditing(null)} className="px-4 py-2 rounded bg-[#0F1923] border border-[#22324a] text-white/80 text-sm font-bold">Отмена</button><button onClick={save} className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-sm font-bold">Сохранить</button></div>
        </div>}
      </Modal>
    </div>
  );
}

/* =================== CASES =================== */
function CasesTab() {
  const cases = useMemo(() => getCases(), []);
  const [search, setSearch] = useState('');
  const filtered = cases.filter(c => !search || c.name.toLowerCase().includes(search.toLowerCase()));
  return (
    <div>
      <H title="Кейсы" sub={`${cases.length} кейсов`} action={<input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍" className="w-52 bg-[#152030] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-sm text-white" />} />
      <Card noPad>
        <table className="w-full text-sm"><thead><tr className="text-[10px] uppercase tracking-wider text-white/45 border-b border-[#22324a]">
          <th className="text-left px-4 py-2">Кейс</th><th className="px-4 py-2">Кат.</th><th className="text-right px-4 py-2">Предметов</th><th className="text-right px-4 py-2">Цена</th><th className="text-center px-4 py-2">Флаги</th>
        </tr></thead><tbody>{filtered.map(c => (
          <tr key={c.id} className="border-b border-[#1a2638] hover:bg-[#152030]">
            <td className="px-4 py-2"><div className="flex items-center gap-2"><span className="text-xl">{c.image}</span><div><div className="text-white font-bold text-xs">{c.name}</div><div className="text-[10px] text-white/40 font-mono">{c.id}</div></div></div></td>
            <td className="px-4 py-2 text-center"><Badge>{c.category}</Badge></td>
            <td className="px-4 py-2 text-right text-white/70">{c.items.length}</td>
            <td className="px-4 py-2 text-right text-[#FF6B1A] font-bold">{c.price === 0 ? 'FREE' : `${fmt(c.price)} ₽`}</td>
            <td className="px-4 py-2 text-center">{c.is_new && <Badge tone="ok">NEW</Badge>}</td>
          </tr>
        ))}</tbody></table>
      </Card>
    </div>
  );
}

/* =================== TRANSACTIONS =================== */
function TransactionsTab() {
  const txs = useStore(s => s.transactions);
  const users = useStore(s => s.users);
  const [typeF, setTypeF] = useState('');
  const filtered = txs.filter(t => !typeF || t.type === typeF);

  return (
    <div>
      <H title="Транзакции" sub={`${txs.length} записей`} action={
        <select value={typeF} onChange={e => setTypeF(e.target.value)} className="bg-[#152030] border border-[#22324a] rounded px-3 py-2 text-sm text-white">
          <option value="">Все типы</option>{['bonus','daily','promo','open','sell','upgrade','battle','admin','contract'].map(t => <option key={t} value={t}>{t}</option>)}
        </select>
      } />
      <Card noPad>
        {filtered.length === 0 ? <div className="text-center py-12 text-white/40 text-sm">Нет транзакций</div> :
        <div className="max-h-[600px] overflow-y-auto"><table className="w-full text-sm"><thead><tr className="text-[10px] uppercase tracking-wider text-white/45 border-b border-[#22324a] sticky top-0 bg-[#152030]">
          <th className="text-left px-4 py-2">Время</th><th className="text-left px-4 py-2">Пользователь</th><th className="text-left px-4 py-2">Тип</th><th className="text-right px-4 py-2">Сумма</th><th className="text-left px-4 py-2">Описание</th>
        </tr></thead><tbody>{filtered.slice(0, 200).map((t: Transaction) => {
          const u = users[t.userId];
          return (<tr key={t.id} className="border-b border-[#1a2638] hover:bg-[#152030]">
            <td className="px-4 py-2 text-white/50 text-xs font-mono whitespace-nowrap">{new Date(t.created_at).toLocaleString('ru-RU')}</td>
            <td className="px-4 py-2"><div className="flex items-center gap-1.5"><span className="text-sm">{u?.avatar ?? '👤'}</span><span className="text-white text-xs font-bold">{u?.username ?? t.userId}</span></div></td>
            <td className="px-4 py-2"><Badge>{t.type}</Badge></td>
            <td className={`px-4 py-2 text-right font-bold font-mono ${t.amount >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{t.amount >= 0 ? '+' : ''}{t.amount.toFixed(2)} ₽</td>
            <td className="px-4 py-2 text-white/50 text-xs">{t.description}</td>
          </tr>);
        })}</tbody></table></div>}
      </Card>
    </div>
  );
}

function StatBox({ l, v }: { l: string; v: any }) {
  return <div className="bg-[#0F1923] rounded p-2 border border-[#1c2740]"><div className="text-[9px] uppercase text-white/40 tracking-wider">{l}</div><div className="text-white font-bold text-sm">{v}</div></div>;
}
function Btn({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return <button onClick={onClick} className="w-7 h-7 inline-flex items-center justify-center rounded bg-[#0F1923] border border-[#22324a] hover:border-[#FF6B1A] hover:text-[#FF6B1A] text-white/60 text-xs">{children}</button>;
}
