import { useEffect, useState } from 'react';
import { useT } from '../lib/useT';
import { SKINS, RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from '../components/SkinIcon';
import { clickSound, successSound } from '../lib/sound';
import { useStore } from '../lib/store';

type GiveawayKind = 'hourly' | 'daily' | 'weekly';
type Giveaway = {
  id: string;
  kind: GiveawayKind;
  prizeSkinId: string;
  endsAt: number;
  minDeposit: number;
  joined: boolean;
};

const FAKE_WINNERS = [
  { user: 'FireFly',          av: '🦊' },
  { user: 'Salamandra#peek',  av: '🦎' },
  { user: 'kvas sex excort',  av: '🐱' },
  { user: 'xD',               av: '😎' },
  { user: 'глоточек пива',    av: '🍺' },
  { user: 'how i want to',    av: '💀' },
  { user: '__zLoY__',         av: '😈' },
  { user: 'NoMercy',          av: '⚔️' },
  { user: '7 X 7 = 49',       av: '🤖' },
  { user: 'БамБолдик',        av: '🐻' },
];

function pickPrize(min: number, max: number) {
  const pool = SKINS.filter(s => s.price >= min && s.price <= max);
  return pool[Math.floor(Math.random() * pool.length)] ?? SKINS[0];
}

function makeInitialGiveaways(): Giveaway[] {
  const now = Date.now();
  return [
    { id: 'g_h', kind: 'hourly', prizeSkinId: pickPrize(100, 800).id, endsAt: now + 27 * 60 * 1000, minDeposit: 50, joined: false },
    { id: 'g_d', kind: 'daily',  prizeSkinId: pickPrize(1500, 4000).id, endsAt: now + 12 * 60 * 60 * 1000 + 58 * 60 * 1000, minDeposit: 500, joined: false },
    { id: 'g_w', kind: 'weekly', prizeSkinId: pickPrize(8000, 20000).id, endsAt: now + 14 * 24 * 60 * 60 * 1000, minDeposit: 1500, joined: false },
  ];
}

export function GiveawaysPage({ onLogin }: { onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [giveaways, setGiveaways] = useState<Giveaway[]>(() => makeInitialGiveaways());
  const [, force] = useState(0);

  if (!user) {
    return (
      <div className="px-6 py-16 text-center">
        <div className="text-5xl mb-4">🎁</div>
        <div className="text-white/60 mb-4">Войдите, чтобы участвовать в розыгрышах</div>
        <button onClick={onLogin} className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">{t('login')}</button>
      </div>
    );
  }

  useEffect(() => {
    const id = setInterval(() => force(x => x + 1), 1000);
    return () => clearInterval(id);
  }, []);

  function join(g: Giveaway) {
    setGiveaways(gs => gs.map(x => x.id === g.id ? { ...x, joined: true } : x));
    successSound();
  }

  return (
    <div className="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm text-white/55 flex items-center gap-2">ℹ️ Правила участия</div>
        <div className="text-center flex-1">
          <div className="text-white font-black text-2xl">{t('giveaways')}</div>
        </div>
        <div className="w-[140px]" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {giveaways.map(g => <GiveawayCard key={g.id} g={g} onJoin={() => join(g)} />)}
      </div>
    </div>
  );
}

function GiveawayCard({ g, onJoin }: { g: Giveaway; onJoin: () => void }) {
  const skin = SKINS.find(s => s.id === g.prizeSkinId)!;
  const col = RARITY_COLORS[skin.rarity].hex;
  const remain = Math.max(0, g.endsAt - Date.now());
  const h = Math.floor(remain / 3600000);
  const m = Math.floor((remain % 3600000) / 60000);
  const s = Math.floor((remain % 60000) / 1000);
  const total = g.kind === 'hourly' ? 60*60*1000 : g.kind === 'daily' ? 24*60*60*1000 : 7*24*60*60*1000;
  const pct = (1 - remain / total) * 100;

  const headerColor = g.kind === 'hourly' ? '#34d399' : g.kind === 'daily' ? '#a78bfa' : '#f87171';
  const headerLabel = g.kind === 'hourly' ? 'Розыгрыш каждый час' : g.kind === 'daily' ? 'Розыгрыш каждый день' : 'Розыгрыш каждую неделю';

  return (
    <div className="bg-[#152030] border border-[#22324a] rounded-lg overflow-hidden">
      <div className="px-4 py-2 flex items-center justify-between border-b border-[#22324a]"
        style={{ background: `linear-gradient(90deg, ${headerColor}33, transparent)` }}>
        <div className="text-[11px] font-bold text-white/85 flex items-center gap-2">
          <span className="text-[10px] text-white/40">#H{Math.floor(Math.random()*99999)}</span>
          <span style={{ color: headerColor }}>{headerLabel}</span>
        </div>
        <div className="text-[#FF6B1A] font-black text-sm">{skin.price.toLocaleString('ru-RU', { maximumFractionDigits: 0 })} ₽</div>
      </div>

      <div className="p-4 flex items-center gap-4">
        <div className="flex-1">
          <div className="text-white font-bold text-sm">{skin.name}</div>
          <div className="text-[12px] text-white/45 mb-2">{skin.skin_name}</div>
          <div className="text-[11px] text-white/55">При пополнении от: <span className="text-[#FF6B1A] font-bold">{g.minDeposit} ₽</span></div>
          <div className="text-[11px] text-white/55">Осталось: <span className="text-white font-bold">{h ? `${h} ч ` : ''}{m} мин {s} сек</span></div>
        </div>
        <div className="w-24 h-20 flex items-center justify-center" style={{ filter: `drop-shadow(0 0 12px ${col}88)` }}>
          <SkinIcon skin={skin} className="max-h-full max-w-full" />
        </div>
      </div>

      <div className="px-4">
        <div className="h-1.5 bg-[#0F1923] rounded overflow-hidden mb-3">
          <div className="h-full" style={{ width: `${pct}%`, background: headerColor }} />
        </div>
        <button onClick={() => { clickSound(); onJoin(); }}
          disabled={g.joined}
          className={['w-full py-2 rounded font-bold text-sm mb-3',
            g.joined ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white'].join(' ')}>
          {g.joined ? '✓ Вы участвуете' : 'Участвовать'}
        </button>
      </div>

      <div className="px-4 pb-4">
        <div className="text-center text-[11px] uppercase tracking-wider text-white/55 mb-2 flex items-center justify-center gap-1">🏆 Победители</div>
        <div className="bg-[#0F1923] rounded p-2 space-y-1.5 max-h-[260px] overflow-y-auto">
          {Array.from({ length: 8 }).map((_, i) => {
            const w = FAKE_WINNERS[(i * 3 + g.id.length) % FAKE_WINNERS.length];
            const prize = SKINS.filter(x => x.price < skin.price * 1.1 && x.price > skin.price * 0.4)[i % 4] ?? skin;
            return (
              <div key={i} className="flex items-center gap-2 text-[11px]">
                <div className="w-6 h-6 rounded-full bg-[#1a2638] flex items-center justify-center text-sm shrink-0">{w.av}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-white font-bold truncate">{w.user}</div>
                  <div className="text-white/45 truncate text-[10px]">{prize.market_hash_name}</div>
                </div>
                <div className="text-[#FF6B1A] font-bold text-[11px] whitespace-nowrap">{prize.price.toFixed(0)} ₽</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
