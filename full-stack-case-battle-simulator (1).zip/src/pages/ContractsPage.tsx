import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useT } from '../lib/useT';
import { addItemToInventory, addToBalance, getSkin, removeItemsFromInventory, useStore } from '../lib/store';
import { SKINS, RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from '../components/SkinIcon';
import { clickSound, errorSound, successSound } from '../lib/sound';

const HOUSE_EDGE = 0.78;

export function ContractsPage({ onLogin }: { onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [selectedUids, setSelectedUids] = useState<string[]>([]);
  const [balanceUsage, setBalanceUsage] = useState(0);
  const [targetColor, setTargetColor] = useState<string | null>(null);
  const [result, setResult] = useState<{ skinId: string } | null>(null);
  const [signing, setSigning] = useState(false);

  if (!user) {
    return (
      <div className="px-6 py-16 text-center">
        <div className="text-white/60 mb-4">{t('auth_required')}</div>
        <button onClick={onLogin} className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">{t('login')}</button>
      </div>
    );
  }

  const value = selectedUids.reduce((a, uid) => {
    const it = user.inventory.find(i => i.uid === uid); if (!it) return a;
    return a + (getSkin(it.skinId)?.price ?? 0);
  }, 0) + balanceUsage;

  const expected = value * HOUSE_EDGE;
  const min = expected * 0.7;
  const max = expected * 1.3;
  const need = Math.max(0, 3 - selectedUids.length);

  function rollOutput(): string {
    // pick skins within range; optionally bias by color (rarity hex)
    let pool = SKINS.filter(s => s.price >= min && s.price <= max);
    if (targetColor) {
      const filtered = pool.filter(s => RARITY_COLORS[s.rarity].hex.toLowerCase() === targetColor.toLowerCase());
      if (filtered.length > 0) pool = filtered;
    }
    if (pool.length === 0) {
      pool = SKINS.filter(s => Math.abs(s.price - expected) < expected * 0.5);
    }
    if (pool.length === 0) pool = SKINS;
    return pool[Math.floor(Math.random() * pool.length)].id;
  }

  function sign() {
    if (need > 0 || signing) { errorSound(); return; }
    if (balanceUsage > user!.balance) { errorSound(); return; }
    setSigning(true);
    setResult(null);
    setTimeout(() => {
      if (balanceUsage > 0) addToBalance(user!.id, -balanceUsage, 'contract', 'Contract balance');
      removeItemsFromInventory(user!.id, selectedUids);
      const sid = rollOutput();
      addItemToInventory(user!.id, sid);
      successSound();
      setResult({ skinId: sid });
      setSigning(false);
      setSelectedUids([]);
      setBalanceUsage(0);
    }, 1800);
  }

  const rainbow = ['#b0c3d9','#5e98d9','#4b69ff','#8847ff','#d32ce6','#eb4b4b','#e4ae39'];

  return (
    <div className="px-4 sm:px-6 py-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <div className="text-sm text-white/55 flex items-center gap-2">📜 {t('rules')}</div>
        <div className="text-center flex-1">
          <div className="text-white font-black text-2xl">{t('contracts')}</div>
        </div>
        <div className="w-[80px]" />
      </div>

      {/* Slots strip */}
      <div className="bg-[#152030] border border-[#22324a] rounded-lg p-3 mb-4">
        <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
          {Array.from({ length: 10 }).map((_, i) => {
            const uid = selectedUids[i];
            const it = uid ? user.inventory.find(x => x.uid === uid) : undefined;
            const s = it ? getSkin(it.skinId) : undefined;
            return (
              <div key={i} className="aspect-square bg-[#0F1923] border border-[#1c2740] rounded flex items-center justify-center">
                {s ? <SkinIcon skin={s} className="max-h-[80%] max-w-[80%]" /> : <div className="text-white/10 text-2xl">🔫</div>}
              </div>
            );
          })}
        </div>
      </div>

      {/* Status bar */}
      <div className="bg-[#152030] border border-[#22324a] rounded-lg px-4 py-3 mb-4 flex flex-wrap items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="text-[11px] text-white/45">💼 Ваш баланс:</div>
          <div className="text-white font-bold">{user.balance.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
        </div>
        <div className="flex-1 text-center text-[12px] text-white/55 uppercase tracking-wider">
          {need > 0 ? `${t('contract_min')} ${need} ${t('items')}` : 'Готово!'}
        </div>
        <div className="text-[11px] text-white/55 uppercase tracking-wider">
          {t('contract_sum')}: <span className="text-[#FF6B1A] font-bold">{value.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: my items */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4">
          <div className="text-[11px] uppercase tracking-wider text-white/55 font-bold mb-3">МОИ ПРЕДМЕТЫ</div>
          {user.inventory.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-white/40 text-sm mb-2">У вас нет предметов</div>
              <div className="text-5xl my-3">🔫</div>
              <button className="px-4 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold text-sm">{t('open_any_case')}</button>
            </div>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-[400px] overflow-y-auto">
              {user.inventory.map(it => {
                const s = getSkin(it.skinId)!;
                const col = RARITY_COLORS[s.rarity].hex;
                const sel = selectedUids.includes(it.uid);
                return (
                  <button key={it.uid}
                    onClick={() => { clickSound(); setSelectedUids(arr => sel ? arr.filter(u => u !== it.uid) : arr.length < 10 ? [...arr, it.uid] : arr); }}
                    className={['relative bg-[#0F1923] rounded p-2 flex flex-col items-center',
                      sel ? 'ring-2 ring-[#FF6B1A]' : 'hover:bg-[#1a2638]'].join(' ')}
                    style={{ borderBottom: `3px solid ${col}` }}>
                    <SkinIcon skin={s} className="h-10" />
                    <div className="text-[9px] mt-1 text-white/85 truncate w-full text-center">{s.name}</div>
                    <div className="text-[10px] text-[#FF6B1A] font-bold">{s.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })}</div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Right: contract result */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4 flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <div className="text-[11px] text-white/55 uppercase">{t('use_balance')}:</div>
            <input type="range" min={0} max={user.balance} value={balanceUsage}
              onChange={e => setBalanceUsage(parseInt(e.target.value))}
              className="flex-1 accent-[#FF6B1A]" />
            <div className="text-sm font-bold text-[#FF6B1A] w-16 text-right">{balanceUsage.toFixed(0)} ₽</div>
          </div>

          <div className="text-center text-[11px] text-white/55 mb-1">{t('contract_will_get')}</div>
          <div className="text-center text-white font-bold mb-3">
            {t('contract_from')} <span className="text-[#FF6B1A]">{min.toFixed(0)} ₽</span>{' '}
            {t('contract_to')} <span className="text-[#FF6B1A]">{max.toFixed(0)} ₽</span>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <div className="text-[12px] text-white/55">Цель:</div>
            <select className="bg-[#0F1923] border border-[#22324a] rounded px-2 py-1 text-sm text-white">
              <option>🔀 случайная</option>
            </select>
          </div>

          {/* Color picker */}
          <div className="flex gap-3 mb-4">
            <div className="w-4 rainbow-bar rounded" />
            <div className="flex-1 flex flex-wrap gap-1.5">
              {rainbow.map(c => (
                <button key={c} onClick={() => { clickSound(); setTargetColor(t => t === c ? null : c); }}
                  className={['w-6 h-6 rounded border-2', targetColor === c ? 'border-white' : 'border-transparent'].join(' ')}
                  style={{ background: c }} />
              ))}
              <button onClick={() => setTargetColor(null)} className="ml-1 px-2 h-6 text-[10px] text-white/45 hover:text-white">очистить</button>
            </div>
          </div>

          <div className="min-h-[120px] flex items-center justify-center">
            <AnimatePresence>
              {signing && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                  className="text-white/40 text-sm">Подписание контракта...</motion.div>
              )}
              {result && !signing && (() => {
                const s = getSkin(result.skinId)!;
                const col = RARITY_COLORS[s.rarity].hex;
                return (
                  <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                    className="bg-[#0F1923] rounded p-3 flex flex-col items-center" style={{ borderBottom: `3px solid ${col}`, boxShadow: `0 0 24px ${col}55` }}>
                    <SkinIcon skin={s} className="h-16" />
                    <div className="text-sm font-bold text-white mt-2">{s.market_hash_name}</div>
                    <div className="text-base font-black mt-1" style={{ color: col }}>{s.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
                  </motion.div>
                );
              })()}
            </AnimatePresence>
          </div>

          <button onClick={sign} disabled={signing || need > 0}
            className={['mt-3 w-full py-2.5 rounded font-black tracking-wider',
              signing || need > 0
                ? 'bg-[#152030] border border-[#22324a] text-white/30'
                : 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white'
            ].join(' ')}>
            🤝 {t('contract_sign')}
          </button>
        </div>
      </div>
    </div>
  );
}
