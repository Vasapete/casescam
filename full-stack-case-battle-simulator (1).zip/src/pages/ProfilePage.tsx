import { useEffect, useState } from 'react';
import { BONUS_AMOUNT, BONUS_INTERVAL, FREE_CASE_INTERVAL, addItemToInventory, claimBonus, claimDaily, claimQuest, getSkin, questsRefreshIfNeeded, redeemPromo, sellItems, toggleFavorite, updateUser, useStore } from '../lib/store';
import { useT } from '../lib/useT';
import { RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from '../components/SkinIcon';
import { clickSound, errorSound, successSound } from '../lib/sound';
import type { Rarity } from '../lib/types';
import { getCases, rollFromCase } from '../lib/cases';

const RARITY_ORDER: Record<Rarity, number> = { common: 0, uncommon: 1, rare: 2, mythical: 3, legendary: 4, ancient: 5, immortal: 6 };

export function ProfilePage({ onLogin }: { onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [sort, setSort] = useState<'price'|'date'|'name'|'rarity'>('price');
  const [favOnly, setFavOnly] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [promo, setPromo] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const [, force] = useState(0);

  useEffect(() => {
    if (user) questsRefreshIfNeeded(user.id);
    const id = setInterval(() => force(x => x + 1), 1000);
    return () => clearInterval(id);
  }, [user?.id]);

  if (!user) {
    return (
      <div className="px-6 py-16 text-center">
        <div className="text-white/60 mb-4">{t('auth_required')}</div>
        <button onClick={onLogin} className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">{t('login')}</button>
      </div>
    );
  }

  const sorted = [...user.inventory]
    .filter(i => !favOnly || i.is_favorited)
    .sort((a, b) => {
      const sa = getSkin(a.skinId)!; const sb = getSkin(b.skinId)!;
      if (sort === 'price') return sb.price - sa.price;
      if (sort === 'date') return b.acquired_at - a.acquired_at;
      if (sort === 'name') return sa.market_hash_name.localeCompare(sb.market_hash_name);
      return RARITY_ORDER[sb.rarity] - RARITY_ORDER[sa.rarity];
    });

  const invValue = user.inventory.reduce((acc, i) => acc + (getSkin(i.skinId)?.price ?? 0), 0);
  const bestDrop = user.inventory.reduce((best, i) => {
    const s = getSkin(i.skinId)!;
    return !best || s.price > best.price ? s : best;
  }, null as ReturnType<typeof getSkin> | null);

  const nextBonus = Math.max(0, BONUS_INTERVAL - (Date.now() - user.last_bonus_claim));
  const bonusReady = nextBonus === 0;
  const freeReady = (Date.now() - user.last_free_case) >= FREE_CASE_INTERVAL;
  const todayUTC = new Date();
  const last = new Date(user.last_daily_claim);
  const dailyReady = !user.last_daily_claim ||
    last.getUTCDate() !== todayUTC.getUTCDate() || last.getUTCMonth() !== todayUTC.getUTCMonth() ||
    last.getUTCFullYear() !== todayUTC.getUTCFullYear();

  function fmt(ms: number) {
    const s = Math.floor(ms / 1000);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const ss = s % 60;
    if (h) return `${h}ч ${m}м`;
    return `${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`;
  }

  function doBonus() {
    const r = claimBonus(user!.id);
    if (r.ok) { successSound(); setMsg(`+${r.amount} ₽`); setTimeout(() => setMsg(null), 1500); }
    else errorSound();
  }
  function doDaily() {
    const r = claimDaily(user!.id);
    if (r.ok) { successSound(); setMsg(`+${r.amount} ₽ (streak ${r.streak})`); setTimeout(() => setMsg(null), 1800); }
    else errorSound();
  }
  function doFreeCase() {
    const cases = getCases();
    const freeCases = cases.filter(c => c.category === 'free');
    const c = freeCases[Math.floor(Math.random() * freeCases.length)];
    const sid = rollFromCase(c);
    addItemToInventory(user!.id, sid);
    updateUser(user!.id, { last_free_case: Date.now() });
    successSound();
    setMsg('Бесплатный кейс открыт!');
    setTimeout(() => setMsg(null), 2000);
  }

  function applyPromo() {
    if (!promo) return;
    const r = redeemPromo(user!.id, promo);
    if (r.ok) { successSound(); setMsg(`+${r.amount} ₽`); setPromo(''); }
    else { errorSound(); setMsg(r.error || 'Ошибка'); }
    setTimeout(() => setMsg(null), 2200);
  }

  function doSell(uids: string[]) {
    const amt = sellItems(user!.id, uids);
    successSound();
    setMsg(`Продано на ${amt.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽`);
    setTimeout(() => setMsg(null), 1800);
    setSelected(new Set());
  }

  return (
    <div className="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
      <div className="text-center mb-5">
        <div className="text-[12px] uppercase tracking-[0.3em] text-white/40">{t('profile')}</div>
        <div className="text-white font-black text-2xl">ПРОФИЛЬ</div>
      </div>

      {msg && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 font-bold px-4 py-2 rounded">
          {msg}
        </div>
      )}

      {/* Three top cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        {/* Bonuses */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="text-red-400 text-lg">⚠️</div>
            <div>
              <div className="text-white font-bold text-sm">BONUSES</div>
              <div className="text-[11px] text-white/45">Заберите свои бонусы</div>
            </div>
          </div>
          <button disabled={!bonusReady} onClick={doBonus}
            className={['w-full mb-2 px-3 py-2 rounded text-sm font-bold flex items-center justify-between',
              bonusReady ? 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white' : 'bg-[#0F1923] text-white/40 border border-[#22324a]'].join(' ')}>
            <span>+{BONUS_AMOUNT} ₽ / 30 мин</span>
            <span className="text-xs">{bonusReady ? t('bonus_claim') : fmt(nextBonus)}</span>
          </button>
          <button disabled={!dailyReady} onClick={doDaily}
            className={['w-full mb-2 px-3 py-2 rounded text-sm font-bold flex items-center justify-between',
              dailyReady ? 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white' : 'bg-[#0F1923] text-white/40 border border-[#22324a]'].join(' ')}>
            <span>+500 ₽ ежедневно</span>
            <span className="text-xs">streak: {user.daily_streak}</span>
          </button>
          <button disabled={!freeReady} onClick={doFreeCase}
            className={['w-full px-3 py-2 rounded text-sm font-bold flex items-center justify-between',
              freeReady ? 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white' : 'bg-[#0F1923] text-white/40 border border-[#22324a]'].join(' ')}>
            <span>🎁 Бесплатный кейс / 4ч</span>
            <span className="text-xs">{freeReady ? '→' : fmt(FREE_CASE_INTERVAL - (Date.now() - user.last_free_case))}</span>
          </button>
        </div>

        {/* Profile */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4 flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-[#FF6B1A] to-[#8b3700] flex items-center justify-center text-4xl border-2 border-[#FF6B1A]/40 mb-2">
            {user.avatar}
          </div>
          <div className="text-white font-bold">{user.username}</div>
          <div className="text-[10px] text-white/40">ID: {user.id}</div>
          <div className="text-2xl font-black text-white mt-3">{user.balance.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} <span className="text-[#FF6B1A]">₽</span></div>
          <div className="text-[10px] text-white/40 mt-1">{user.role.toUpperCase()}</div>
        </div>

        {/* Promo */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="text-[#FF6B1A] text-lg">%</div>
            <div>
              <div className="text-white font-bold text-sm">Персональный купон</div>
              <div className="text-[11px] text-white/45">Введите код</div>
            </div>
          </div>
          <div className="flex gap-2 mb-3">
            <input value={promo} onChange={e => setPromo(e.target.value)} placeholder="WELCOME500"
              className="flex-1 bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-sm text-white" />
            <button onClick={applyPromo} className="px-4 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-xs font-bold uppercase">{t('promo_apply')}</button>
          </div>
          <div className="text-[10px] text-white/45">Активные коды: WELCOME500, COMET-14</div>
        </div>
      </div>

      {/* Stats + best drop row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="text-[#FF6B1A] text-lg">📊</div>
            <div className="text-white font-bold text-sm">СТАТИСТИКА</div>
            <div className="text-[11px] text-white/45">Аккаунта</div>
          </div>
          <div className="grid grid-cols-4 gap-2 text-center mb-3">
            <Stat icon="📦" value={user.stats.casesOpened} />
            <Stat icon="⚔️" value={user.stats.battlesWon} />
            <Stat icon="⬆️" value={user.stats.upgradesWon} />
            <Stat icon="⭐" value={user.inventory.filter(i => i.is_favorited).length} />
          </div>
          <div className="text-[11px] text-white/55 uppercase tracking-wider">Инвентарь</div>
          <div className="flex items-baseline gap-2">
            <div className="text-white font-black text-xl">{invValue.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
            <div className="text-[11px] text-white/40">· {user.inventory.length} предметов</div>
          </div>
        </div>

        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4">
          <div className="flex items-center gap-2 mb-3">
            <div className="text-yellow-400 text-lg">🏆</div>
            <div className="text-white font-bold text-sm">ЛУЧШИЙ ДРОП</div>
          </div>
          {bestDrop ? (
            <div className="flex items-center gap-3">
              <SkinIcon skin={bestDrop} className="h-16 w-24 object-contain" />
              <div className="flex-1">
                <div className="text-white font-bold text-sm">{bestDrop.market_hash_name}</div>
                <div className="text-[11px] text-white/45 mb-1">{RARITY_COLORS[bestDrop.rarity].ru}</div>
                <div className="text-[#FF6B1A] font-black">{bestDrop.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
              </div>
            </div>
          ) : (
            <div className="text-white/40 text-sm">Откройте первый кейс</div>
          )}
        </div>
      </div>

      {/* Quests */}
      <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4 mb-5">
        <div className="flex items-center gap-2 mb-3">
          <div className="text-[#FF6B1A] text-lg">🎯</div>
          <div className="text-white font-bold text-sm">{t('quests').toUpperCase()}</div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
          {user.quests.map(q => {
            const label = q.type === 'open_cases' ? t('quest_open5')
                        : q.type === 'win_battle' ? t('quest_winbattle')
                        : q.type === 'upgrade' ? t('quest_upgrade')
                        : t('quest_bigdrop');
            const ready = q.progress >= q.target && !q.claimed;
            return (
              <div key={q.id} className="bg-[#0F1923] border border-[#1c2740] rounded p-3">
                <div className="text-[11px] text-white/85 font-bold mb-1">{label}</div>
                <div className="text-[10px] text-white/40 mb-2">+{q.reward} ₽</div>
                <div className="h-1.5 bg-[#1c2740] rounded overflow-hidden mb-2">
                  <div className="h-full bg-[#FF6B1A]" style={{ width: `${Math.min(100, q.progress / q.target * 100)}%` }} />
                </div>
                <div className="text-[10px] text-white/40 mb-2">{q.progress}/{q.target}</div>
                {q.claimed ? (
                  <div className="text-emerald-400 text-[11px] font-bold">✔ Получено</div>
                ) : ready ? (
                  <button onClick={() => { const r = claimQuest(user.id, q.id); if (r.ok) { successSound(); setMsg(`+${r.amount} ₽`); setTimeout(()=>setMsg(null),1500); } }}
                    className="w-full py-1 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-[11px] font-bold">
                    {t('claim')}
                  </button>
                ) : (
                  <div className="text-white/30 text-[11px]">{t('in_progress')}</div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Inventory */}
      <div className="text-center my-4">
        <div className="text-[13px] uppercase tracking-[0.4em] text-white/55 font-bold">
          ВАШИ ПРЕДМЕТЫ
        </div>
        <div className="mx-auto mt-1 w-24 h-[2px] bg-gradient-to-r from-transparent via-[#FF6B1A] to-transparent" />
      </div>

      <div className="flex flex-wrap items-center gap-3 mb-3">
        <select value={sort} onChange={e => setSort(e.target.value as any)}
          className="bg-[#152030] border border-[#22324a] rounded px-3 py-1.5 text-sm text-white">
          <option value="price">{t('by_price')}</option>
          <option value="date">{t('by_date')}</option>
          <option value="name">{t('by_name')}</option>
          <option value="rarity">{t('by_rarity')}</option>
        </select>
        <label className="flex items-center gap-2 text-sm text-white/55 cursor-pointer">
          <input type="checkbox" checked={favOnly} onChange={e => setFavOnly(e.target.checked)} className="accent-[#FF6B1A]" />
          Только избранные
        </label>
        <div className="flex-1" />
        {selected.size > 0 && (
          <button onClick={() => doSell([...selected])}
            className="px-3 py-1.5 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-sm font-bold">
            {t('sell_selected')} ({selected.size})
          </button>
        )}
        {user.inventory.length > 0 && (
          <button onClick={() => doSell(user.inventory.map(i => i.uid))}
            className="px-3 py-1.5 rounded bg-[#152030] border border-[#22324a] hover:border-[#FF6B1A] text-white/85 text-sm font-bold">
            {t('sell_all')}
          </button>
        )}
      </div>

      {sorted.length === 0 ? (
        <div className="text-center py-12 text-white/40">{t('no_items')}</div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {sorted.map(it => {
            const s = getSkin(it.skinId)!;
            const col = RARITY_COLORS[s.rarity].hex;
            const sel = selected.has(it.uid);
            return (
              <div key={it.uid}
                className={['relative bg-[#0F1923] rounded-md overflow-hidden border', sel ? 'border-[#FF6B1A]' : 'border-[#1a2638]'].join(' ')}
                style={{ borderBottom: `3px solid ${col}` }}
              >
                <button
                  onClick={() => { clickSound(); setSelected(s => { const n = new Set(s); n.has(it.uid) ? n.delete(it.uid) : n.add(it.uid); return n; }); }}
                  className="absolute top-1.5 right-1.5 w-5 h-5 rounded bg-black/60 text-white/85 text-[12px] z-10">
                  {sel ? '✓' : ''}
                </button>
                <button onClick={() => toggleFavorite(user.id, it.uid)}
                  className={['absolute top-1.5 left-1.5 text-[14px] z-10', it.is_favorited ? 'text-yellow-400' : 'text-white/30 hover:text-white/80'].join(' ')}>
                  ★
                </button>
                <div className="px-2 pt-2 pb-1 text-center">
                  <div className="text-[11px] font-bold text-[#FF6B1A]">{s.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
                </div>
                <div className="h-[80px] flex items-center justify-center px-2">
                  <SkinIcon skin={s} className="max-h-[75px] max-w-full" />
                </div>
                <div className="px-2 py-2 text-center">
                  <div className="text-[11px] font-bold text-white/85 truncate">{s.name}</div>
                  <div className="text-[10px] text-white/45 truncate">{s.skin_name}</div>
                </div>
                <div className="grid grid-cols-2 border-t border-[#1a2638]">
                  <button onClick={() => doSell([it.uid])}
                    className="py-1.5 text-[10px] font-bold text-white/70 hover:text-[#FF6B1A] hover:bg-[#FF6B1A]/10">
                    {t('sell')}
                  </button>
                  <button onClick={() => toggleFavorite(user.id, it.uid)}
                    className="py-1.5 text-[10px] font-bold text-white/70 hover:text-yellow-400 hover:bg-yellow-400/10 border-l border-[#1a2638]">
                    ★ Fav
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function Stat({ icon, value }: { icon: string; value: number }) {
  return (
    <div className="bg-[#0F1923] rounded py-2">
      <div className="text-lg">{icon}</div>
      <div className="text-white font-bold text-sm">{value}</div>
    </div>
  );
}
