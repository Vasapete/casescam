import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { addToBalance, useStore } from '../lib/store';
import { useT } from '../lib/useT';
import { clickSound, coinSound, errorSound, explodeSound, revealSound, successSound } from '../lib/sound';

type Cell = { revealed: boolean; isMine: boolean };

const GRID = 5; // 5x5
const TOTAL = GRID * GRID;

// Multiplier per safe reveal, given total mines (k) and revealed (n)
// Fair multiplier ≈ C(N, n) / C(N - k, n). We apply ~92% RTP.
function multiplier(mines: number, revealed: number): number {
  if (revealed === 0) return 1;
  let m = 1;
  for (let i = 0; i < revealed; i++) {
    m *= (TOTAL - i) / (TOTAL - mines - i);
  }
  return Math.max(1, m * 0.92);
}

export function MinesPage({ onLogin }: { onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [bet, setBet] = useState<number>(100);
  const [mines, setMines] = useState<number>(3);
  const [grid, setGrid] = useState<Cell[]>(() => Array.from({ length: TOTAL }, () => ({ revealed: false, isMine: false })));
  const [active, setActive] = useState(false);
  const [revealedCount, setRevealedCount] = useState(0);
  const [busted, setBusted] = useState(false);
  const [lastWin, setLastWin] = useState<number | null>(null);

  const currentMult = useMemo(() => multiplier(mines, revealedCount), [mines, revealedCount]);
  const currentPayout = bet * currentMult;
  const nextMult = useMemo(() => multiplier(mines, revealedCount + 1), [mines, revealedCount]);
  const nextPayout = bet * nextMult;

  if (!user) {
    return (
      <div className="px-6 py-16 text-center">
        <div className="text-5xl mb-4">💣</div>
        <div className="text-white/60 mb-4">Войдите, чтобы играть в Mines</div>
        <button onClick={onLogin} className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold">{t('login')}</button>
      </div>
    );
  }

  function start() {
    if (active) return;
    if (bet < 10) { errorSound(); return; }
    if (bet > user!.balance) { errorSound(); return; }
    if (mines < 1 || mines > 24) { errorSound(); return; }
    addToBalance(user!.id, -bet, 'admin', `Mines bet (${mines} mines)`);
    // place mines
    const indices = new Set<number>();
    while (indices.size < mines) indices.add(Math.floor(Math.random() * TOTAL));
    setGrid(Array.from({ length: TOTAL }, (_, i) => ({ revealed: false, isMine: indices.has(i) })));
    setActive(true);
    setRevealedCount(0);
    setBusted(false);
    setLastWin(null);
    clickSound();
  }

  function reveal(idx: number) {
    if (!active || busted) return;
    const cell = grid[idx];
    if (cell.revealed) return;
    const next = grid.slice();
    next[idx] = { ...cell, revealed: true };
    setGrid(next);
    if (cell.isMine) {
      // game over — reveal all mines
      explodeSound();
      setBusted(true);
      setActive(false);
      // reveal all mines for the dramatic reveal
      setTimeout(() => {
        setGrid(g => g.map(c => c.isMine ? { ...c, revealed: true } : c));
      }, 200);
      return;
    }
    revealSound();
    setRevealedCount(n => n + 1);
  }

  function cashOut() {
    if (!active || revealedCount === 0) return;
    addToBalance(user!.id, currentPayout, 'admin', `Mines win x${currentMult.toFixed(2)}`);
    setLastWin(currentPayout);
    setActive(false);
    successSound(); coinSound();
  }

  function newRound() {
    setGrid(Array.from({ length: TOTAL }, () => ({ revealed: false, isMine: false })));
    setActive(false); setBusted(false); setRevealedCount(0); setLastWin(null);
  }

  // safe cells remaining
  const safeRemaining = TOTAL - mines - revealedCount;

  return (
    <div className="px-4 sm:px-6 py-6 max-w-5xl mx-auto">
      <div className="text-center mb-5">
        <div className="text-[12px] uppercase tracking-[0.3em] text-white/40">МИНИ-ИГРА</div>
        <div className="text-white font-black text-2xl">💣 MINES</div>
        <div className="text-[12px] text-white/45 mt-1">Открывай ячейки, не наткнись на мину. Чем больше открыл — тем выше выигрыш.</div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-4">
        {/* Grid */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4">
          <div className="grid grid-cols-5 gap-2 max-w-[480px] mx-auto">
            {grid.map((c, i) => (
              <Tile key={i} cell={c} disabled={!active || busted} onClick={() => reveal(i)} just={active && revealedCount > 0} />
            ))}
          </div>

          {/* Status */}
          <div className="mt-4 text-center">
            {!active && !lastWin && !busted && (
              <div className="text-white/55 text-sm">Сделайте ставку и нажмите «Начать»</div>
            )}
            {active && !busted && (
              <div className="text-emerald-400 text-sm font-bold">
                ✓ Открыто {revealedCount} · следующая открытая клетка → {nextMult.toFixed(2)}x ({nextPayout.toFixed(0)} ₽)
              </div>
            )}
            {busted && (
              <motion.div initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                className="text-red-400 text-xl font-black">
                💥 BUSTED! Ставка {bet} ₽ потеряна
              </motion.div>
            )}
            {lastWin !== null && !busted && (
              <motion.div initial={{ scale: 0.7, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
                className="text-emerald-400 text-xl font-black">
                🎉 +{lastWin.toFixed(0)} ₽ забрано!
              </motion.div>
            )}
          </div>
        </div>

        {/* Side panel */}
        <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4 space-y-4">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-white/55 font-bold mb-1">Ставка ₽</div>
            <div className="flex gap-1 mb-2">
              {[10, 50, 100, 500, 1000].map(v => (
                <button key={v} disabled={active}
                  onClick={() => { setBet(v); clickSound(); }}
                  className={['flex-1 py-1.5 rounded text-xs font-bold',
                    bet === v ? 'bg-[#FF6B1A] text-white' : 'bg-[#0F1923] border border-[#22324a] text-white/65 hover:border-[#FF6B1A]/50',
                    active ? 'opacity-50 cursor-not-allowed' : ''
                  ].join(' ')}>
                  {v}
                </button>
              ))}
            </div>
            <input type="number" min={10} max={user.balance} value={bet} disabled={active}
              onChange={e => setBet(Math.max(10, Math.min(user.balance, parseFloat(e.target.value) || 0)))}
              className="w-full bg-[#0F1923] border border-[#22324a] focus:border-[#FF6B1A] outline-none rounded px-3 py-2 text-white font-mono" />
            <div className="flex gap-1 mt-1">
              <button disabled={active} onClick={() => setBet(b => Math.max(10, Math.floor(b / 2)))}
                className="flex-1 py-1 rounded bg-[#0F1923] border border-[#22324a] text-white/65 text-xs font-bold hover:border-[#FF6B1A]/50 disabled:opacity-50">½</button>
              <button disabled={active} onClick={() => setBet(b => Math.min(user.balance, b * 2))}
                className="flex-1 py-1 rounded bg-[#0F1923] border border-[#22324a] text-white/65 text-xs font-bold hover:border-[#FF6B1A]/50 disabled:opacity-50">2×</button>
              <button disabled={active} onClick={() => setBet(user.balance)}
                className="flex-1 py-1 rounded bg-[#0F1923] border border-[#22324a] text-white/65 text-xs font-bold hover:border-[#FF6B1A]/50 disabled:opacity-50">Max</button>
            </div>
          </div>

          <div>
            <div className="text-[10px] uppercase tracking-wider text-white/55 font-bold mb-1">
              Мин: <span className="text-[#FF6B1A]">{mines}</span> / 24
            </div>
            <input type="range" min={1} max={24} value={mines} disabled={active}
              onChange={e => setMines(parseInt(e.target.value))}
              className="w-full accent-[#FF6B1A]" />
            <div className="flex gap-1 mt-1">
              {[1, 3, 5, 10].map(v => (
                <button key={v} disabled={active}
                  onClick={() => { setMines(v); clickSound(); }}
                  className={['flex-1 py-1 rounded text-[11px] font-bold',
                    mines === v ? 'bg-[#FF6B1A] text-white' : 'bg-[#0F1923] border border-[#22324a] text-white/65 hover:border-[#FF6B1A]/50',
                    active ? 'opacity-50 cursor-not-allowed' : ''
                  ].join(' ')}>
                  {v}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-[#0F1923] rounded p-3 space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-white/55">Множитель</span><span className="text-white font-bold">{currentMult.toFixed(2)}x</span></div>
            <div className="flex justify-between"><span className="text-white/55">Текущий выигрыш</span><span className="text-[#FF6B1A] font-bold">{currentPayout.toFixed(0)} ₽</span></div>
            <div className="flex justify-between"><span className="text-white/55">Безопасных осталось</span><span className="text-white font-bold">{safeRemaining}</span></div>
          </div>

          {!active ? (
            <button onClick={start} disabled={bet > user.balance || bet < 10}
              className={['w-full py-3 rounded font-black tracking-wider',
                bet > user.balance || bet < 10
                  ? 'bg-[#152030] border border-[#22324a] text-white/30'
                  : 'bg-[#FF6B1A] hover:bg-[#ff8438] text-white shadow-lg shadow-[#FF6B1A]/30'
              ].join(' ')}>
              ▶ НАЧАТЬ
            </button>
          ) : (
            <button onClick={cashOut} disabled={revealedCount === 0}
              className={['w-full py-3 rounded font-black tracking-wider',
                revealedCount === 0
                  ? 'bg-[#152030] border border-[#22324a] text-white/30'
                  : 'bg-emerald-500 hover:bg-emerald-400 text-black shadow-lg shadow-emerald-500/30'
              ].join(' ')}>
              💰 ЗАБРАТЬ {currentPayout.toFixed(0)} ₽
            </button>
          )}

          {(busted || lastWin !== null) && (
            <button onClick={newRound}
              className="w-full py-2 rounded bg-[#0F1923] border border-[#22324a] hover:border-[#FF6B1A] text-white/85 text-sm font-bold">
              Новый раунд
            </button>
          )}
        </div>
      </div>

      {/* Payout preview */}
      <div className="bg-[#152030] border border-[#22324a] rounded-lg p-4 mt-4">
        <div className="text-[10px] uppercase tracking-wider text-white/55 font-bold mb-2">Таблица выплат для {mines} мин</div>
        <div className="overflow-x-auto">
          <div className="flex gap-1 min-w-max">
            {Array.from({ length: Math.min(15, TOTAL - mines) }, (_, i) => i + 1).map(n => {
              const m = multiplier(mines, n);
              const cur = revealedCount + 1 === n;
              return (
                <div key={n} className={['px-2.5 py-2 rounded text-center min-w-[58px]',
                  cur ? 'bg-[#FF6B1A] text-white' : 'bg-[#0F1923] border border-[#22324a]'
                ].join(' ')}>
                  <div className="text-[10px] text-white/55">#{n}</div>
                  <div className="text-xs font-black">{m.toFixed(2)}x</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

function Tile({ cell, onClick, disabled, just }: { cell: Cell; onClick: () => void; disabled: boolean; just: boolean }) {
  return (
    <button onClick={onClick} disabled={disabled || cell.revealed}
      className={[
        'aspect-square rounded-lg flex items-center justify-center text-2xl font-black transition-all relative overflow-hidden',
        cell.revealed
          ? cell.isMine
            ? 'bg-red-500/20 border-2 border-red-500/60'
            : 'bg-emerald-500/20 border-2 border-emerald-500/60'
          : disabled
            ? 'bg-[#0F1923] border-2 border-[#1c2740] cursor-default'
            : 'bg-[#1a2638] border-2 border-[#22324a] hover:border-[#FF6B1A] hover:bg-[#22324a] cursor-pointer active:scale-95'
      ].join(' ')}>
      <AnimatePresence>
        {cell.revealed && (
          <motion.span
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 18 }}
          >
            {cell.isMine ? '💣' : '💎'}
          </motion.span>
        )}
        {!cell.revealed && just && (
          <span className="text-white/15">?</span>
        )}
      </AnimatePresence>
    </button>
  );
}
