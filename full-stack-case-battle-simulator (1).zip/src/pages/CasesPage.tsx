import { useMemo, useState, useEffect } from 'react';
import { CaseCard } from '../components/CaseCard';
import { getCases } from '../lib/cases';
import type { CaseDef, CaseCategory } from '../lib/types';
import { useT } from '../lib/useT';
import { isLuckyHour, redeemPromo, useStore } from '../lib/store';
import { clickSound, errorSound, successSound } from '../lib/sound';

export function CasesPage({ onPick }: { onPick: (c: CaseDef) => void }) {
  const t = useT();
  const cases = useMemo(() => getCases(), []);
  const [filter, setFilter] = useState('');
  const [onlyNew, setOnlyNew] = useState(false);
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [promo, setPromo] = useState('');
  const [promoMsg, setPromoMsg] = useState<{ text: string; ok: boolean } | null>(null);

  // Countdown for limited promo
  const [endsIn, setEndsIn] = useState(() => 19 * 60);
  useEffect(() => {
    const id = setInterval(() => setEndsIn(v => Math.max(0, v - 1)), 1000);
    return () => clearInterval(id);
  }, []);

  const cats: { key: CaseCategory; label: string }[] = [
    { key: 'serial',  label: t('cat_serial') },
    { key: 'brand',   label: t('cat_brand') },
    { key: 'premium', label: t('cat_premium') },
    { key: 'free',    label: t('cat_free') },
  ];

  const grouped: Record<CaseCategory, CaseDef[]> = {
    serial: [], brand: [], premium: [], event: [], free: [],
  };
  for (const c of cases) {
    if (filter && !c.name.toLowerCase().includes(filter.toLowerCase())) continue;
    if (onlyNew && !c.is_new) continue;
    grouped[c.category].push(c);
  }

  const lucky = isLuckyHour();

  function applyPromo() {
    if (!user) { errorSound(); setPromoMsg({ text: 'Войдите в аккаунт', ok: false }); return; }
    const r = redeemPromo(user.id, promo);
    if (r.ok) { successSound(); setPromoMsg({ text: `+${r.amount} ₽ зачислено!`, ok: true }); setPromo(''); }
    else { errorSound(); setPromoMsg({ text: r.error || 'Ошибка', ok: false }); }
    setTimeout(() => setPromoMsg(null), 3000);
  }

  const mm = String(Math.floor(endsIn / 60)).padStart(2, '0');
  const ss = String(endsIn % 60).padStart(2, '0');

  return (
    <div className="px-4 sm:px-6 py-4 max-w-[1400px] mx-auto">
      {/* Top banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-5">
        <div className="bg-gradient-to-r from-[#FF6B1A] to-[#e23b00] rounded-lg px-4 py-3 flex items-center gap-3 shadow-lg shadow-[#FF6B1A]/20">
          <div className="text-3xl">🎟️</div>
          <div>
            <div className="text-white font-black text-xl leading-none">+14%</div>
            <div className="text-white/85 text-[10px] uppercase tracking-wider font-bold">на следующий клейм</div>
          </div>
        </div>
        <div className="bg-[#152030] border border-[#22324a] rounded-lg px-4 py-3 flex items-center gap-3">
          <div className="text-[11px] uppercase tracking-wider text-white/45 leading-tight">Осталось<br/>времени:</div>
          <div className="text-white font-black text-xl font-mono">{mm}:{ss}</div>
          <div className="text-2xl">⏰</div>
        </div>
        <div className="bg-[#152030] border border-[#22324a] rounded-lg px-3 py-2 flex items-center gap-3">
          <div className="text-[11px] uppercase tracking-wider text-white/45 leading-tight font-bold">
            {t('promo_label')}:
          </div>
          <div className="flex-1 flex items-center bg-[#0F1923] rounded overflow-hidden border border-[#22324a]">
            <input
              value={promo} onChange={e => setPromo(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') applyPromo(); }}
              placeholder="COMET-14"
              className="flex-1 bg-transparent px-3 py-2 text-sm text-white outline-none placeholder:text-white/30"
            />
            <button onClick={applyPromo}
              className="px-3 h-9 bg-[#FF6B1A] hover:bg-[#ff8438] text-white text-[11px] font-bold uppercase">
              {t('promo_apply')}
            </button>
          </div>
        </div>
      </div>
      {promoMsg && (
        <div className={['text-sm font-bold px-3 py-2 rounded mb-3 text-center',
          promoMsg.ok ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-red-500/10 text-red-400 border border-red-500/30'].join(' ')}>
          {promoMsg.text}
        </div>
      )}

      {lucky && (
        <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/40 rounded-lg px-4 py-2 mb-4 text-center text-yellow-300 font-bold animate-pulse">
          {t('lucky_hour')}
        </div>
      )}

      {/* Filter bar */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        <div className="text-[11px] uppercase tracking-widest text-white/45">Быстрый Фильтр:</div>
        <input value={filter} onChange={e => setFilter(e.target.value)}
          placeholder="Что ищем?"
          className="bg-[#152030] border border-[#22324a] rounded px-3 py-1.5 text-sm text-white outline-none focus:border-[#FF6B1A] w-48"
        />
        <label className="flex items-center gap-2 text-sm text-white/55 cursor-pointer">
          <input type="checkbox" checked={onlyNew} onChange={e => { clickSound(); setOnlyNew(e.target.checked); }}
            className="accent-[#FF6B1A]"
          />
          Только новые
        </label>
      </div>

      {/* Categories */}
      {cats.map(c => grouped[c.key].length > 0 && (
        <section key={c.key} className="mb-8">
          <div className="text-center my-4">
            <div className="text-[13px] uppercase tracking-[0.4em] text-white/55 font-bold relative inline-block">
              <span className="relative z-10 bg-[#0F1923] px-4">{c.label}</span>
              <span className="absolute left-1/2 -translate-x-1/2 top-1/2 w-[400px] h-px bg-[#22324a] -z-0" />
            </div>
            <div className="mx-auto mt-1 w-24 h-[2px] bg-gradient-to-r from-transparent via-[#FF6B1A] to-transparent" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
            {grouped[c.key].map(cd => (
              <CaseCard key={cd.id} def={cd} onClick={() => onPick(cd)} />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}
