import { useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { CaseDef, Skin } from '../lib/types';
import { addItemToInventory, addToBalance, getCurrentUser, progressQuest, pushDropFeed, sellItems, updateUser, useStore } from '../lib/store';
import { RARITY_COLORS } from '../lib/skinData';
import { SkinIcon } from '../components/SkinIcon';
import { CaseOpener, type OpenResult } from '../components/CaseOpener';
import { useT } from '../lib/useT';
import { clickSound, errorSound, successSound } from '../lib/sound';
import { getSkin } from '../lib/store';
import { generateCaseArt } from '../lib/caseArt';

export function CaseDetailPage({ caseDef, onBack, onLogin }: { caseDef: CaseDef; onBack: () => void; onLogin: () => void }) {
  const t = useT();
  const user = useStore(s => s.currentUserId ? s.users[s.currentUserId] : null);
  const [opening, setOpening] = useState<{ count: number; quick: boolean } | null>(null);
  const [resultModal, setResultModal] = useState<OpenResult[] | null>(null);

  const items = useMemo(() => {
    return caseDef.items.map(it => {
      const s = getSkin(it.skinId)!;
      const totalW = caseDef.items.reduce((a, b) => a + b.weight, 0);
      return { skin: s, chance: (it.weight / totalW) * 100 };
    }).sort((a, b) => b.skin.price - a.skin.price);
  }, [caseDef]);

  const [quickMode, setQuickMode] = useState(false);

  function startOpen(count: number, quick: boolean) {
    if (!user) { errorSound(); onLogin(); return; }
    const total = caseDef.price * count;
    if (user.balance < total) { errorSound(); return; }
    addToBalance(user.id, -total, 'open', `Open ${count}x ${caseDef.name}`);
    setOpening({ count, quick });
  }

  function finishOpen(results: OpenResult[]) {
    if (!user) return;
    const cur = getCurrentUser();
    if (!cur) return;
    results.forEach(r => {
      addItemToInventory(cur.id, r.skin.id);
      pushDropFeed({ username: cur.username, avatar: cur.avatar, skinId: r.skin.id, caseName: caseDef.name });
      if (r.skin.price >= 1000) progressQuest(cur.id, 'big_drop', 1);
    });
    updateUser(cur.id, u => ({ stats: { ...u.stats, casesOpened: u.stats.casesOpened + results.length } }));
    progressQuest(cur.id, 'open_cases', results.length);
    successSound();
    setOpening(null);
    setResultModal(results);
  }

  function sellAllResults() {
    if (!user || !resultModal) return;
    // The items were added with random uids — find latest matching items in inventory
    const cur = getCurrentUser(); if (!cur) return;
    const wanted = resultModal.map(r => r.skin.id);
    const uids: string[] = [];
    const inv = [...cur.inventory];
    for (const sid of wanted) {
      const idx = inv.findIndex(i => i.skinId === sid && !uids.includes(i.uid));
      if (idx >= 0) uids.push(inv[idx].uid);
    }
    sellItems(cur.id, uids);
    successSound();
    setResultModal(null);
  }

  return (
    <div className="px-4 sm:px-6 py-6 max-w-6xl mx-auto">
      <button onClick={() => { clickSound(); onBack(); }} className="text-sm text-white/55 hover:text-[#FF6B1A] mb-3">← Назад к кейсам</button>

      <div className="text-center mb-2">
        <div className="text-[11px] tracking-[0.3em] uppercase text-white/40">Линейный кейс</div>
        <div className="text-white font-black text-3xl mt-1">«{caseDef.name}»</div>
      </div>

      {/* Big art */}
      <div className="relative w-[240px] h-[200px] mx-auto rounded-lg overflow-hidden mb-4">
        <img src={generateCaseArt(caseDef.name)} alt={caseDef.name} className="w-full h-full object-cover rounded-lg" draggable={false} />
      </div>

      {/* Open buttons + quick toggle */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-2">
        {[1, 2, 3, 5].map(c => (
          <button key={c}
            onClick={() => startOpen(c, quickMode)}
            className="px-5 py-2.5 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-[#FF6B1A]/20">
            <span>{c === 1 ? t('open_case') : `${t('multi_open')}${c}`}</span>
            <span className="text-white/80 text-xs">{(caseDef.price * c).toLocaleString('ru-RU')} ₽</span>
          </button>
        ))}
        <button onClick={() => { setQuickMode(v => !v); clickSound(); }}
          className={[
            'px-4 py-2.5 rounded font-bold text-sm border transition-colors',
            quickMode
              ? 'bg-[#FF6B1A] border-[#FF6B1A] text-white'
              : 'bg-[#152030] border-[#22324a] hover:border-[#FF6B1A] text-white/80'
          ].join(' ')}>
          ⚡ {t('quick_open')} {quickMode ? 'ON' : 'OFF'}
        </button>
      </div>

      <div className="text-center text-[11px] text-white/40 mb-6">Наведите на предмет, чтобы увидеть шанс</div>

      <div className="text-center text-[12px] uppercase tracking-[0.3em] text-white/45 mb-3">{t('contents')}</div>

      <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-6 gap-2">
        {items.map(({ skin, chance }) => <ItemTile key={skin.id} skin={skin} chance={chance} />)}
      </div>

      {opening && (
        <CaseOpener
          caseDef={caseDef}
          count={opening.count}
          quick={opening.quick}
          onDone={finishOpen}
          onClose={() => setOpening(null)}
        />
      )}

      <AnimatePresence>
        {resultModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setResultModal(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.95 }}
              onClick={e => e.stopPropagation()}
              className="bg-[#152030] border border-[#22324a] rounded-xl p-6 max-w-3xl w-full"
            >
              <div className="text-center text-[12px] uppercase tracking-[0.3em] text-white/45 mb-3">Ваш дроп</div>
              <div className={`grid gap-3 ${resultModal.length === 1 ? 'grid-cols-1 max-w-xs mx-auto' : resultModal.length === 2 ? 'grid-cols-2' : 'grid-cols-2 sm:grid-cols-3'}`}>
                {resultModal.map((r, i) => {
                  const col = RARITY_COLORS[r.skin.rarity].hex;
                  return (
                    <motion.div key={i}
                      initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: i * 0.07 }}
                      className="relative rounded-lg p-3 bg-[#0F1923] flex flex-col items-center"
                      style={{ borderBottom: `3px solid ${col}`, boxShadow: `0 0 24px ${col}55` }}
                    >
                      <SkinIcon skin={r.skin} className="h-[90px] my-2" />
                      <div className="text-[12px] font-bold text-white truncate w-full text-center">{r.skin.name}</div>
                      <div className="text-[11px] text-white/55 truncate w-full text-center">{r.skin.skin_name}</div>
                      <div className="text-[14px] font-black mt-1" style={{ color: col }}>{r.skin.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
                    </motion.div>
                  );
                })}
              </div>
              <div className="flex justify-center gap-3 mt-5">
                <button onClick={sellAllResults}
                  className="px-5 py-2 rounded bg-[#152030] border border-[#22324a] hover:border-[#FF6B1A] text-white font-bold text-sm">
                  Продать всё за {resultModal.reduce((a,b)=>a+b.skin.price,0).toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽
                </button>
                <button onClick={() => setResultModal(null)}
                  className="px-5 py-2 rounded bg-[#FF6B1A] hover:bg-[#ff8438] text-white font-bold text-sm">
                  Забрать в инвентарь
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ItemTile({ skin, chance }: { skin: Skin; chance: number }) {
  const [hover, setHover] = useState(false);
  const col = RARITY_COLORS[skin.rarity].hex;
  return (
    <div
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      className="relative bg-[#0F1923] rounded-md overflow-hidden border border-[#1a2638] hover:-translate-y-0.5 transition-transform"
      style={{ borderBottom: `3px solid ${col}` }}
    >
      <div className="px-2 pt-2 pb-1 text-center">
        <div className="text-[11px] font-bold text-[#FF6B1A]">{skin.price.toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ₽</div>
      </div>
      <div className="h-[60px] flex items-center justify-center px-1">
        <SkinIcon skin={skin} className="max-h-[55px] max-w-full" />
      </div>
      <div className="px-2 pb-2 text-center">
        <div className="text-[10px] font-bold text-white/85 truncate">{skin.name}</div>
        <div className="text-[9px] text-white/45 truncate">{skin.skin_name}</div>
      </div>
      {hover && (
        <div className="absolute top-1 left-1 text-[9px] px-1.5 py-0.5 bg-black/80 rounded text-white font-bold">
          {chance < 0.01 ? '<0.01' : chance.toFixed(2)}%
        </div>
      )}
    </div>
  );
}
